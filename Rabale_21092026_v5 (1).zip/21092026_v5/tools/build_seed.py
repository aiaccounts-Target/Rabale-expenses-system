import pandas as pd, re, json, math
d = pd.read_pickle('/home/claude/work/parsed.pkl')
d['date'] = pd.to_datetime(d['date'])

# ---- ledgers the app currently accepts (LEDGER_SYNC_COLUMN_MAP in Sheet utils.gs) ----
ACTIVE = set("""Birthday Cake & Chocolates|Conveyance - Others|Food Exp|House Keeping Material: Thane & Rabale|Lodging & Boarding Exp|Office Expenses|Packing Material|Pantry Material|Parking Charges|Postage & Courier Charges|Printing & Stationery|Repairs & Maintenance|Repairs & Maintainance|Repairs & Maintainance-MH03EG0225|Repairs & Maintenance - MH 04 NB 5087|Repairs & Maintenance - MH 43 BX 0252|Repairs & Maintenance - MH04MH4896|Repairs & Maintenance - MH43 AD 7803|Repairs & Maintenance - MH43 Bx 7803|Repairs & Maintenance - MH43 BX 7821|Repairs & Maintenance - Others|Repairs & Maintenance - Pinning Machine|Repairs & Maintenance - Shrink Machine|Repairs & Maintenance - Single Clamp Binding Mach.|Repairs & Maintenance - Single Clamp Machine ( Bindwell Bluechip)|Repairs & Maintenance - Single Knife Cutting Mach.|Repairs & Maintenance - Squaring Machine|Repairs & Maintenance - Three Knife Cutting Mach.|Repairs & Maintenance- Cutting Machine|Repairs & Maintenance -MH04LQ4014|Repairs & Maintenance- Strapping Machine|Repairs and Maintenance- Six Clamp Book Binding Mac|Staff Welfare|Tea & Coffee|Transportation Non - GST|Travelling Expenses|Vehicle Fastag|Vehicle Operating - Jakat/Toll|Vehicle Operating - Petrol""".split('|'))
# the mis-typed AD ledger and the two plain R&M ledgers are never suggested (see guide)
NEVER_SUGGEST = {'Repairs & Maintenance', 'Repairs & Maintainance', 'Repairs & Maintenance - MH43 AD 7803', 'Travelling Expenses'}

RETIRED_MAP = {
    'Loading & Unloading Charge': 'Transportation Non - GST',
    'Medicine': 'Office Expenses',
    'Diesel-MH03 EG 0225': 'Vehicle Operating - Petrol',
    'Diesel - MH43-BX-7803': 'Vehicle Operating - Petrol',
    'Petrol - Others': 'Vehicle Operating - Petrol',
    'Petrol Reimbursement': 'Conveyance - Others',
}
DROP_LEDGERS = {'Purchase for Project', 'Manpower Supply Expenses', 'Transportation - GST', 'Labour Charges'}

def desc(narr):
    t = re.sub(r'\s+', ' ', narr.lower()).strip()
    m = re.search(r"\bpaid to ([a-z\.' ]{2,40}?) for (.+)$", t)
    if m:
        body = m.group(2)
    else:
        body = re.sub(r"^being\s+(amt|amount)?\s*(of\s+)?(rs\.?\s*[\d,\.]+\s*(/-)?\s*)?(paid\s*)?(to\s+[a-z\. ]{2,30}\s+)?", '', t)
    body = re.sub(r'\brs\.?\s*[\d,\.]+\s*/?-?', ' ', body)
    body = re.sub(r'\d{1,2}[\.\-/]\d{1,2}[\.\-/]\d{2,4}', ' ', body)
    body = re.sub(r'\b(on|dt|dtd|dated|date)\b[:\.\s]*', ' ', body)
    body = re.sub(r'\s+', ' ', body).strip(' .,:;-()')
    return body[:160]

FOOD = re.compile(r'\b(lunch|breakfast|dinner)\b')
TRAVEL = re.compile(r'travel|traval|auto\b|train|petrol|pertol|fare|conveyance|rapido|uber|metro')
EVENT = re.compile(r'celebrat|cabin|festival|ceremon|diwali|christmas|pooja|fun friday|send ?off')
def guide_label(text, orig):
    """Weak supervision: align history to the rulings printed in the Ledger Guide. None = drop."""
    if orig in DROP_LEDGERS:
        if orig == 'Labour Charges' and 'dustbin' in text: return 'Office Expenses'
        return None
    lab = RETIRED_MAP.get(orig, orig)
    if orig == 'Loading & Unloading Charge' and re.search(r'return|parcel', text): return None
    if lab not in ACTIVE: return None
    if lab in NEVER_SUGGEST and lab != 'Travelling Expenses': return None
    if lab == 'Travelling Expenses': lab = 'Conveyance - Others'
    f, tr, ev = bool(FOOD.search(text)), bool(TRAVEL.search(text)), bool(EVENT.search(text))
    if f and tr: return None                       # mixed, ambiguous
    if f and not ev and lab in ('Conveyance - Others', 'Staff Welfare', 'Office Expenses'): return 'Food Exp'
    if re.search(r'pooja|puja|rangoli|decorat|diwali|kandil|dassera|dussehra', text) and not re.search(r'travel', text) and lab in ('Staff Welfare', 'Office Expenses'):
        return 'Office Expenses'
    if re.search(r'dustbin|garbage', text) and lab in ('Repairs & Maintenance - Others', 'Office Expenses'): return 'Office Expenses'
    if re.search(r'bandage|first aid|cipladine|dettol', text): return 'Office Expenses'
    if re.search(r'screening', text) and lab in ('Repairs & Maintenance - Others', 'Packing Material', 'Printing & Stationery'): return 'Packing Material'
    if re.search(r'drinking water|water jar|water bottle|jar', text) and lab in ('Staff Welfare', 'Office Expenses'): return 'Staff Welfare'
    if re.search(r'\bsugar\b', text): return 'Pantry Material'
    if re.search(r'thread bundle|sutli|suttli', text): return 'Packing Material'
    if re.search(r'fast ?tag|fasttag', text): return 'Vehicle Fastag'
    if re.search(r'\btoll\b', text) and lab in ('Vehicle Operating - Jakat/Toll', 'Repairs & Maintenance - MH43 BX 7821'): return 'Vehicle Operating - Jakat/Toll'
    return lab

rows = []
for _, r in d.iterrows():
    t = desc(r.narr)
    if len(re.findall(r'[a-z]{3,}', t)) < 2: continue
    g = guide_label(t, r.ledger)
    rows.append(dict(date=str(r.date)[:10], orig=r.ledger, guide=g, text=t))
df = pd.DataFrame(rows)
print('rows', len(df), 'kept for guide labels', df.guide.notna().sum())

# ---- eval set (all rows with an active original label, for honest testing) ----
ev = df[df.orig.isin(ACTIVE)].copy()
ev.to_json('/home/claude/work/eval_rows.json', orient='records')

# ---- shipping seed: dedupe, cap per ledger ----
STOP = set('being amount paid to for of on dt dtd dated rs charges charge exps exp expenses expense and the a an at in by from is was with no nos pc pcs'.split())
def key(t): return ' '.join(sorted(set(w for w in re.findall(r'[a-z]{3,}', t) if w not in STOP)))
keep = df[df.guide.notna()].copy()
keep['k'] = keep.text.map(key)
keep = keep.sort_values('date', ascending=False).drop_duplicates(['guide', 'k'])
CAP = 70
out = []
for lab, g in keep.groupby('guide'):
    g = g.sort_values('date', ascending=False)
    if len(g) > CAP:
        idx = [int(i * (len(g) - 1) / (CAP - 1)) for i in range(CAP)]
        g = g.iloc[sorted(set(idx))]
    out += [(lab, t) for t in g.text]
ledgers = sorted(set(l for l, _ in out))
li = {l: i for i, l in enumerate(ledgers)}
seed = [[li[l], t] for l, t in out]
print('seed examples', len(seed), 'ledgers', len(ledgers))
print(pd.Series([l for l, _ in out]).value_counts().to_string())

js = ["// ============================================================================",
      "// LEDGER SEED — starting examples for the ledger suggester (Ledger Suggest.gs).",
      "// Built from the Rabale Petty Expenses Register (Apr 2025 - Sep 2026): the DESCRIPTION",
      "// part of each narration only (payee names, amounts and dates removed), de-duplicated,",
      "// capped per ledger, and aligned to the rulings in the Ledger Guide (retired ledgers",
      "// mapped to their current home, ambiguous rows dropped). The suggester also learns from",
      "// live approved vouchers, so this file only needs regenerating if the guide's rulings change.",
      "// ============================================================================",
      "var LS_SEED_LEDGERS = " + json.dumps(ledgers, ensure_ascii=False) + ";",
      "var LS_SEED = [",
      ",\n".join(json.dumps(x, ensure_ascii=False) for x in seed),
      "];", ""]
open('/home/claude/work/Ledger Seed.gs', 'w', encoding='utf-8').write("\n".join(js))
print('seed bytes', len("\n".join(js).encode('utf-8')))
