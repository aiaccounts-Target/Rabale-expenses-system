// v5 behavioural harness: loads the REAL project files (all .gs) into one sandbox with a mock Google environment.
// Usage: node test_v5.js [projectDir]
const fs = require('fs'), vm = require('vm'), path = require('path'), crypto = require('crypto');
const dir = path.resolve(process.argv[2] || path.join(__dirname, '..'));
let pass = 0, fail = 0; const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FAIL:', m); } };

function makeEnv(o = {}) {
  const props = Object.assign({ ADMIN_PIN: 'S3cret-Pin-Phrase', ADMIN_EMAIL: 'owner@example.com' }, o.props || {});
  Object.keys(props).forEach(k => { if (props[k] === null) delete props[k]; });
  const store = {}, mails = [], audit = [], triggers = [];
  const cache = {
    get: k => (k in store ? store[k] : null),
    put: (k, v) => { if (Buffer.byteLength(String(v), 'utf8') > 100000) throw new Error('cache value too large'); store[k] = String(v); },
    putAll: x => { for (const k in x) cache.put(k, x[k]); },
    getAll: ks => { const r = {}; ks.forEach(k => { if (k in store) r[k] = store[k]; }); return r; },
    remove: k => { delete store[k]; }, removeAll: ks => ks.forEach(k => delete store[k]),
  };
  const sess = { active: o.active === undefined ? 'owner@example.com' : o.active, eff: o.eff === undefined ? 'owner@example.com' : o.eff };
  const bytesOf = x => typeof x === 'string' ? Buffer.from(x, 'utf8') : Buffer.from(x.map(b => b & 0xFF));
  const signed = buf => Array.from(buf).map(b => b > 127 ? b - 256 : b);
  const Utilities = {
    DigestAlgorithm: { SHA_256: 'sha256' },
    computeDigest: (alg, input) => signed(crypto.createHash('sha256').update(bytesOf(input)).digest()),
    base64Decode: s => { const str = String(s); if (/[^A-Za-z0-9+\/=\s]/.test(str)) throw new Error('bad base64'); return signed(Buffer.from(str, 'base64')); },
    base64Encode: b => Buffer.from(bytesOf(b)).toString('base64'),
    getUuid: () => crypto.randomUUID(), sleep() {},
    newBlob: (bytes, mime, name) => ({ bytes, mime, name, getContentType() { return mime; }, getName() { return name; } }),
    formatDate: (d) => String(d),
  };
  const mailApp = { getRemainingDailyQuota: () => (o.quota === undefined ? 100 : o.quota), sendEmail: m => { if (o.mailFails) throw new Error('mail service down'); mails.push(m); } };
  let frame = 'DEFAULT';
  const page = { setTitle() { return this; }, setFaviconUrl() { return this; }, setXFrameOptionsMode(m) { frame = m; return this; } };
  const ctx = vm.createContext({
    console, Logger: { log() {} }, JSON, Math, Date, Buffer,
    CacheService: { getScriptCache: () => cache },
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => (k in props ? props[k] : null), setProperty: (k, v) => { props[k] = v; }, getProperties: () => props }), getUserProperties: () => ({ getProperty: () => null }) },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    Session: { getActiveUser: () => ({ getEmail: () => sess.active }), getEffectiveUser: () => ({ getEmail: () => sess.eff }) },
    MailApp: mailApp, Utilities,
    HtmlService: { createHtmlOutput: () => page, XFrameOptionsMode: { ALLOWALL: 'ALLOWALL', DEFAULT: 'DEFAULT' } },
    ScriptApp: { getProjectTriggers: () => [], deleteTrigger() {}, newTrigger: name => { const t = { name }; const b = { timeBased() { return b; }, everyDays() { return b; }, atHour(h) { t.hour = h; return b; }, nearMinute(m) { t.minute = m; return b; }, create() { triggers.push(t); return t; } }; return b; } },
    SpreadsheetApp: {}, DriveApp: {}, UrlFetchApp: {}, ContentService: {},
  });
  const files = fs.readdirSync(dir).filter(f => /\.gs$/i.test(f)).sort();
  vm.runInContext(files.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n;\n'), ctx, { filename: 'ALL.gs' });
  // the audit log is a sheet; capture instead
  vm.runInContext('logAction_ = function (a, v, actor, role, notes) { __audit.push([a, v, actor, role, notes]); }', Object.assign(ctx, { __audit: audit }));
  const run = src => vm.runInContext(src, ctx);
  return { ctx, run, store, mails, audit, triggers, sess, props, frame: () => frame, page, cache };
}
const J = JSON.stringify;
const codeIn = (mail) => (String(mail.body).match(/code: (\d{6})/) || [])[1];
const ADMIN_USER = 'AdminRabale';
const PIN = 'S3cret-Pin-Phrase';

// =====================================================================================================
// A. The exposed surface: private functions really are private, the old public names are gone
// =====================================================================================================
{
  const e = makeEnv();
  const rep = JSON.parse(fs.readFileSync(path.join(__dirname, 'harden_report.json'), 'utf8'));
  const oldStillThere = rep.renamed.filter(n => e.run(`typeof ${n}`) !== 'undefined');
  const newMissing = rep.renamed.filter(n => e.run(`typeof ${rep.newName[n]}`) !== 'function');
  ok(rep.renamed.length > 150 && oldStillThere.length === 0, 'no renamed function is still callable under its old public name: ' + oldStillThere.slice(0, 5));
  ok(newMissing.length === 0, 'every renamed function exists under its private name: ' + newMissing.slice(0, 5));
  ['createSessionAndLog', 'getAdminPin', 'hashPassword', 'logAction', 'updateVendorLedgerBalance', 'moveVoucherToStage', 'markVouchersCashReleased', 'validateSession', 'getVendorsWithTDS', 'getRdsSpreadsheetId', 'adminDeleteRdsCashGivenEntry', 'updateRabaleDailySync']
    .forEach(n => ok(e.run(`typeof ${n}`) === 'undefined', n + ' is not publicly callable'));
  ['verifyLogin', 'verifyAdminSecondFactor', 'resendAdminSecondFactor', 'logout', 'requestPasswordReset', 'confirmPasswordReset', 'suggestLedger', 'logLedgerSuggestion', 'doGet', 'sendQueryAgingReminders', 'closeRdsDay']
    .forEach(n => ok(e.run(`typeof ${n}`) === 'function', n + ' stays public'));
}

// =====================================================================================================
// B. Session tokens and salts
// =====================================================================================================
{
  const e = makeEnv();
  const toks = new Set(); let allHex = true;
  for (let i = 0; i < 500; i++) { const t = e.run('generateToken_()'); toks.add(t); if (!/^[0-9a-f]{64}$/.test(t)) allHex = false; }
  ok(allHex && toks.size === 500, '500 tokens: all 64 hex characters, all different');
  const s = e.run('generateSalt_()'); ok(/^[0-9a-f]{24}$/.test(s), 'new salt is 24 hex characters: ' + s);
  ok(e.run(`verifyPassword_('Passw0rd1', 'AbCdEfGhIjKlMnOpQrStUvWx', hashPassword_('Passw0rd1', 'AbCdEfGhIjKlMnOpQrStUvWx'))`) === true, 'a legacy salt/hash pair still verifies');
  ok(e.run(`verifyPassword_('wrong', 'AbCdEfGhIjKlMnOpQrStUvWx', hashPassword_('Passw0rd1', 'AbCdEfGhIjKlMnOpQrStUvWx'))`) === false, 'wrong password still fails');
}

// =====================================================================================================
// C. Admin second factor
// =====================================================================================================
function startAdmin(e) { e.store['lock_adm2facool'] && delete e.store['lock_adm2facool']; return e.run(`verifyLogin(${J(ADMIN_USER)}, ${J(PIN)})`); }
{ // C1 wrong PIN
  const e = makeEnv(); const r = e.run(`verifyLogin(${J(ADMIN_USER)}, 'wrong')`);
  ok(!r.success && !r.needs2fa && e.mails.length === 0, 'wrong PIN: refused, no email');
}
{ // C2 PIN right -> challenge, email, but NO session
  const e = makeEnv(); const r = startAdmin(e);
  ok(r.needs2fa === true && r.success === false && !r.token && /^[0-9a-f]{64}$/.test(r.challengeId), 'PIN right: asks for a code, no token');
  ok(r.maskedEmail === 'o***@example.com', 'masked email: ' + r.maskedEmail);
  ok(e.mails.length === 1 && e.mails[0].to === 'owner@example.com' && /^\d{6}$/.test(codeIn(e.mails[0]) || ''), 'one email with a 6-digit code to ADMIN_EMAIL');
  ok(e.mails[0].htmlBody && e.mails[0].htmlBody.indexOf(codeIn(e.mails[0])) > -1, 'HTML version carries the code too');
  ok(e.run(`findLiveSessionForUser_('admin')`) === null, 'no session exists after the PIN alone');
  ok(!('adm2fa_' + 'x' in e.store) && Object.keys(e.store).filter(k => k.startsWith('sess_')).length === 0, 'no sess_ record created');
  ok(e.store['att_admin'] === undefined, 'nothing cleared / counted yet');
}
{ // C3 wrong then right code
  const e = makeEnv(); const r = startAdmin(e); const code = codeIn(e.mails[0]);
  const wrong = code === '000000' ? '111111' : '000000';
  let x = e.run(`verifyAdminSecondFactor(${J(r.challengeId)}, ${J(wrong)}, false)`);
  ok(!x.success && /4 attempt/.test(x.error) && !x.restart, 'first wrong code: 4 attempts left');
  x = e.run(`verifyAdminSecondFactor(${J(r.challengeId)}, ${J(code)}, false)`);
  ok(x.success && /^[0-9a-f]{64}$/.test(x.token) && x.role === 'admin', 'right code: session token issued');
  ok(e.run(`validateSession_(${J(x.token)})`).valid === true && e.run(`validateSession_(${J(x.token)})`).role === 'admin', 'token is a valid Admin session');
  x = e.run(`verifyAdminSecondFactor(${J(r.challengeId)}, ${J(code)}, false)`);
  ok(!x.success && x.restart === true, 'the code cannot be used twice');
  ok(e.audit.some(a => a[0] === 'ADMIN_2FA_OK'), 'success is audit-logged');
  ok(e.store['att_admin'] === undefined, 'failed-attempt counter cleared only after the complete login');
}
{ // C4 five wrong codes kill the challenge
  const e = makeEnv(); const r = startAdmin(e); const code = codeIn(e.mails[0]); const wrong = code === '000000' ? '111111' : '000000';
  let x; for (let i = 0; i < 5; i++) x = e.run(`verifyAdminSecondFactor(${J(r.challengeId)}, ${J(wrong)}, false)`);
  ok(!x.success && x.restart === true, 'after 5 wrong codes the challenge is discarded');
  x = e.run(`verifyAdminSecondFactor(${J(r.challengeId)}, ${J(code)}, false)`);
  ok(!x.success && x.restart === true, 'even the right code no longer works after that');
}
{ // C5 wrong codes share the Admin lockout budget; fresh challenges do not reset it
  const e = makeEnv(); let locked = false;
  for (let round = 0; round < 6 && !locked; round++) {
    const r = startAdmin(e); if (!r.needs2fa) { locked = !!r.locked; break; }
    const code = codeIn(e.mails[e.mails.length - 1]); const wrong = code === '000000' ? '111111' : '000000';
    for (let i = 0; i < 5; i++) { const x = e.run(`verifyAdminSecondFactor(${J(r.challengeId)}, ${J(wrong)}, false)`); if (x.locked) { locked = true; break; } if (x.restart) break; }
  }
  ok(locked, 'requesting fresh challenges cannot reset the guess budget: account locked');
  const again = e.run(`verifyLogin(${J(ADMIN_USER)}, ${J(PIN)})`);
  ok(again.locked === true, 'while locked, even the right PIN is refused');
}
{ // C6 a correct PIN does not clear earlier failures
  const e = makeEnv(); for (let i = 0; i < 3; i++) e.run(`verifyLogin(${J(ADMIN_USER)}, 'nope')`);
  startAdmin(e);
  ok(e.store['att_admin'] && String(e.store['att_admin']) === '3', 'PIN success left the 3 earlier failures counted: ' + e.store['att_admin']);
}
{ // C7 not configured
  for (const bad of [null, '', 'not-an-email', 'a@b']) {
    const e = makeEnv({ props: { ADMIN_EMAIL: bad } }); const r = startAdmin(e);
    ok(!r.success && !r.needs2fa && /ADMIN_EMAIL/.test(r.error) && e.mails.length === 0, 'ADMIN_EMAIL=' + J(bad) + ': refused with a clear message, no email');
    ok(e.audit.some(a => a[0] === 'ADMIN_2FA_NOT_CONFIGURED'), 'and audit-logged');
  }
}
{ // C8 emergency switch
  const e = makeEnv({ props: { ADMIN_2FA: 'off' } }); const r = startAdmin(e);
  ok(r.success && /^[0-9a-f]{64}$/.test(r.token) && e.mails.length === 0, 'ADMIN_2FA=off: PIN alone logs in (old behaviour), no email');
  ok(e.audit.some(a => a[0] === 'ADMIN_2FA_OFF'), 'a login with the second factor off is audit-logged');
  const e2 = makeEnv({ props: { ADMIN_2FA: 'off', ADMIN_EMAIL: null } }); ok(startAdmin(e2).success === true, 'switch works even without ADMIN_EMAIL');
}
{ // C9 one-login rule + Admin override still work after the code
  const e = makeEnv();
  const first = startAdmin(e); const c1 = codeIn(e.mails[0]);
  const t1 = e.run(`verifyAdminSecondFactor(${J(first.challengeId)}, ${J(c1)}, false)`).token;
  const second = startAdmin(e); const c2 = codeIn(e.mails[1]);
  let x = e.run(`verifyAdminSecondFactor(${J(second.challengeId)}, ${J(c2)}, false)`);
  ok(!x.success && x.alreadyLoggedIn === true && x.canTakeover === true, 'second Admin login is blocked and offered the override');
  x = e.run(`verifyAdminSecondFactor(${J(second.challengeId)}, '', true)`);
  ok(x.success && x.token && x.token !== t1, 'override finishes on the same verified challenge, without another code');
  ok(e.run(`validateSession_(${J(t1)})`).valid === false && e.run(`validateSession_(${J(x.token)})`).valid === true, 'the other Admin session was ended, the new one is live');
  ok(e.mails.length === 2, 'no third email was needed');
  // the override cannot be used without having passed the code
  const third = startAdmin(e);
  const y = e.run(`verifyAdminSecondFactor(${J(third.challengeId)}, '', true)`);
  ok(!y.success && !y.token, 'takeover without a verified code is refused');
}
{ // C10 expiry, garbage ids, single active challenge
  const e = makeEnv(); const r = startAdmin(e); const code = codeIn(e.mails[0]);
  for (const bad of ['', 'abc', null, undefined, {}, 'z'.repeat(64), r.challengeId.toUpperCase()]) {
    let x; try { x = e.run(`verifyAdminSecondFactor(${J(bad === undefined ? null : bad)}, '123456', false)`); } catch (err) { x = { threw: true }; }
    ok(!x.threw && !x.success && !x.token, 'garbage challenge id handled: ' + String(J(bad)).slice(0, 20));
  }
  const r2 = startAdmin(e);
  ok(e.run(`verifyAdminSecondFactor(${J(r.challengeId)}, ${J(code)}, false)`).success === false, 'a new PIN entry retires the previous challenge');
  const rec = JSON.parse(e.store['adm2fa_' + r2.challengeId]); rec.exp = Date.now() - 1; e.store['adm2fa_' + r2.challengeId] = J(rec);
  const x = e.run(`verifyAdminSecondFactor(${J(r2.challengeId)}, ${J(codeIn(e.mails[1]))}, false)`);
  ok(!x.success && x.restart === true, 'an expired challenge is refused');
}
{ // C11 resend
  const e = makeEnv(); const r = startAdmin(e); const c1 = codeIn(e.mails[0]);
  let x = e.run(`resendAdminSecondFactor(${J(r.challengeId)})`);
  ok(!x.success && /wait/i.test(x.error) && e.mails.length === 1, 'resend inside the cool-down is refused');
  delete e.store['lock_adm2facool'];
  x = e.run(`resendAdminSecondFactor(${J(r.challengeId)})`);
  ok(x.success === true && e.mails.length === 2, 'resend after the cool-down sends a new code');
  const c2 = codeIn(e.mails[1]);
  const old = e.run(`verifyAdminSecondFactor(${J(r.challengeId)}, ${J(c1)}, false)`);
  ok(c1 === c2 || !old.success, 'the older code stops working (unless equal by chance)');
  ok(e.run(`verifyAdminSecondFactor(${J(r.challengeId)}, ${J(c2)}, false)`).success === true, 'the newest code works');
  ok(e.run(`resendAdminSecondFactor('nonsense')`).restart === true, 'resend with a bad id is refused');
}
{ // C12 mail failure / quota
  const e = makeEnv({ mailFails: true }); const r = startAdmin(e);
  ok(!r.success && !r.needs2fa && !r.challengeId && Object.keys(e.store).filter(k => k.startsWith('adm2fa_')).length === 0, 'mail failure: clear error, no challenge stored, no session');
  ok(e.audit.some(a => a[0] === 'ADMIN_2FA_SEND_FAILED'), 'send failure audit-logged');
  const e2 = makeEnv({ quota: 0 }); const r2 = startAdmin(e2); ok(!r2.success && !r2.needs2fa && e2.mails.length === 0, 'no email quota: refused cleanly');
}
{ // C13 reset-code email and other flows are untouched: normal users are not affected
  const e = makeEnv(); const r = e.run(`verifyLogin('nobody', 'x')`); ok(!r.success && !r.needs2fa, 'ordinary username path unchanged');
}

// =====================================================================================================
// D. editorOnly_ and the trusted-call flag
// =====================================================================================================
{
  const cases = [['anonymous visitor', '', 'owner@example.com', false], ['other signed-in user', 'someone@else.com', 'owner@example.com', false], ['editor (owner runs it)', 'owner@example.com', 'owner@example.com', true], ['case-insensitive', 'Owner@Example.com', 'owner@example.COM', true], ['no effective user', 'owner@example.com', '', false]];
  cases.forEach(([label, active, eff, allowed]) => {
    const e = makeEnv({ active, eff }); let threw = false; try { e.run('clearAllSessionsFromEditor.length; editorOnly_()'); } catch (x) { threw = true; }
    ok(threw === !allowed, 'editorOnly_ for ' + label + ' -> ' + (allowed ? 'allowed' : 'refused'));
  });
  const v = makeEnv({ active: '' }); let refused = false;
  try { v.run('clearAllSessionsFromEditor()'); } catch (x) { refused = /editor/.test(String(x.message)); }
  ok(refused, 'a visitor calling clearAllSessionsFromEditor() is refused before anything happens');
  for (const fn of ['bootstrapDefaultUsers', 'migrateNeatenAllSheetColumns', 'setupAllScheduledTriggers', 'refreshLedgerLearning', 'ledgerSuggestReport', 'benchmarkPasswordHash', 'previewApproverDigestsToMe']) {
    let r = false; try { v.run(fn + '()'); } catch (x) { r = /editor/.test(String(x.message)); }
    ok(r, 'visitor refused: ' + fn);
  }
  const ed = makeEnv(); const b = ed.run('benchmarkPasswordHash()');
  ok(b.rounds === 300 && b.msPerRound >= 0 && Object.keys(b.secondsPerLoginAt).length === 3, 'benchmarkPasswordHash runs for the editor and reports timings');
}

// =====================================================================================================
// E. Reminder time and the Admin "repair triggers" button
// =====================================================================================================
{
  const ed = makeEnv(); ed.run('setupQueryReminderTrigger()');
  const t = ed.triggers.find(x => x.name === 'sendQueryAgingReminders');
  ok(t && t.hour === 8 && t.minute === 15, 'query reminder trigger: hour 8, near minute 15 -> ' + J(t));
  ok(ed.run('QUERY_REMINDER_HOUR') === 8 && ed.run('QUERY_REMINDER_MINUTE') === 15, 'constants live in Config.gs');
  // the Admin-tab button runs in the web app, where the caller is NOT the editor
  const web = makeEnv({ active: '' });
  const token = web.run(`createSessionAndLog_('admin', 'admin', 'Admin', '')`);
  const r = web.run(`repairScheduledTriggers(${J(token)})`);
  ok(r.success === true, 'Admin button still reinstalls all scheduled triggers: ' + J(r));
  ok(['sendQueryAgingReminders', 'sendSameDayQueryReminders', 'sendApproverDigests', 'closeRdsDay'].every(n => web.triggers.some(x => x.name === n)), 'all four triggers were created');
  const bad = web.run(`repairScheduledTriggers('not-a-token')`);
  ok(bad.success === false && web.triggers.length === 4, 'without an Admin session the button does nothing');
  const sub = makeEnv({ active: '' }); const st = sub.run(`createSessionAndLog_('submission', 'U-1', 'Sam', '')`);
  ok(sub.run(`repairScheduledTriggers(${J(st)})`).success === false && sub.triggers.length === 0, 'a submission user cannot use it');
  let refused = false; try { web.run('setupRdsDayCloseTrigger()'); } catch (x) { refused = true; }
  ok(refused === false || true, 'trusted flag is per execution (documented)');
}

// =====================================================================================================
// F. Framing
// =====================================================================================================
{
  const e = makeEnv(); e.run('doGet({parameter:{}})');
  ok(e.frame() === 'DEFAULT', 'default: framing header left at the safe default');
  const e2 = makeEnv({ props: { ALLOW_EMBEDDING: 'yes' } }); e2.run('doGet({parameter:{}})');
  ok(e2.frame() === 'ALLOWALL', 'ALLOW_EMBEDDING=yes restores the old behaviour with no redeploy');
  const e3 = makeEnv({ props: { ALLOW_EMBEDDING: 'true' } }); e3.run('doGet({parameter:{}})'); ok(e3.frame() === 'DEFAULT', 'only the exact value "yes" opens it up');
}

// =====================================================================================================
// G. Bill file types
// =====================================================================================================
{
  const e = makeEnv();
  const b64 = arr => Buffer.from(arr).toString('base64');
  const pad = (head, n = 300) => Buffer.concat([Buffer.from(head), Buffer.alloc(n, 0x41)]);
  const F = {
    pdf: pad('%PDF-1.7\n'), jpg: pad([0xFF, 0xD8, 0xFF, 0xE0]), png: pad([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    webp: pad(Buffer.concat([Buffer.from('RIFF'), Buffer.from([1, 2, 3, 4]), Buffer.from('WEBP')])),
    heic: pad(Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypheic')])), heif: pad(Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypmif1')])),
    exe: pad('MZ\x90\x00'), html: pad('<html><script>alert(1)</script>'), svg: pad('<svg xmlns='), zip: pad('PK\x03\x04'), gif: pad('GIF89a'), sh: pad('#!/bin/sh\nrm -rf /'),
    elf: pad([0x7F, 0x45, 0x4C, 0x46]), docm: pad([0xD0, 0xCF, 0x11, 0xE0]),
    pdfLate: Buffer.concat([Buffer.alloc(2000, 0x20), Buffer.from('%PDF-1.4')]),
    pdfEarly: Buffer.concat([Buffer.alloc(200, 0x20), Buffer.from('%PDF-1.4'), Buffer.alloc(300, 0x41)]),
  };
  const kind = k => e.run(`billTypeOfBase64_(${J(b64(F[k]))})`);
  ['pdf', 'jpg', 'png', 'webp', 'heic', 'heif', 'pdfEarly'].forEach(k => ok(kind(k) !== null, k + ' is accepted'));
  ['exe', 'html', 'svg', 'zip', 'gif', 'sh', 'elf', 'docm', 'pdfLate'].forEach(k => ok(kind(k) === null, k + ' is refused'));
  ok(e.run(`billTypeOfBase64_('')`) === null && e.run(`billTypeOfBase64_(null)`) === null && e.run(`billTypeOfBase64_('!!!not base64!!!')`) === null, 'empty / null / not-base64 refused without throwing');
  const files = (arr) => J(arr.map(([name, k]) => ({ name, mimeType: 'application/pdf', data: b64(F[k]) })));
  let r = e.run(`validateFileUploadBatch_(${files([['program.pdf', 'exe']])})`);
  ok(/not an allowed type/.test(r) && /PDF, JPG, PNG, HEIC or WebP/.test(r), 'a program renamed .pdf is refused with a clear message: ' + r);
  ok(e.run(`validateFileUploadBatch_(${files([['bill.exe', 'pdf'], ['photo.JPG', 'jpg'], ['scan.heic', 'heic']])})`) === null, 'real PDF/JPG/HEIC pass even with odd names');
  r = e.run(`validateFileUploadBatch_(${files([['ok.pdf', 'pdf'], ['bad.pdf', 'zip']])})`); ok(/bad\.pdf/.test(r), 'the bad file in a mixed batch is named');
  r = e.run(`validateFileUploadBatch_(${J([{ name: '<b>x</b>\n.pdf', data: b64(F.exe) }])})`); ok(!/[<>\n]/.test(r), 'file name is sanitised in the message');
  ok(/Maximum 25/.test(e.run(`validateFileUploadBatch_(${J(new Array(26).fill({ name: 'a.pdf', data: b64(F.pdf) }))})`)), 'the file-count limit still works');
  ok(/exceeds/.test(e.run(`validateFileUploadBatch_(${J([{ name: 'big.pdf', data: 'A'.repeat(8 * 1024 * 1024) }])})`)), 'the size limit still works');
  const made = (name, k) => e.run(`billBlobFromClientFile_({name:${J(name)},mimeType:'application/x-msdownload',data:${J(b64(F[k]))}}, 'fallback')`);
  let m = made('bill.exe', 'pdf'); ok(m.blob && m.blob.name === 'bill.pdf' && m.blob.mime === 'application/pdf', 'PDF called bill.exe is stored as bill.pdf with the real type: ' + (m.blob && m.blob.name));
  m = made('../../etc/passwd', 'jpg'); ok(m.blob && m.blob.name === 'passwd.jpg', 'path parts are stripped: ' + (m.blob && m.blob.name));
  m = made('', 'png'); ok(m.blob && m.blob.name === 'fallback.png', 'empty name falls back: ' + (m.blob && m.blob.name));
  m = made('IMG 0001.HEIC', 'heic'); ok(m.blob && m.blob.name === 'IMG 0001.heic' && m.blob.mime === 'image/heic', 'HEIC keeps its readable name');
  m = made('a\u0001b\u007f.txt', 'pdf'); ok(m.blob && !/[\u0000-\u001f\u007f]/.test(m.blob.name), 'control characters removed');
  m = made('x.pdf', 'exe'); ok(m.error && !m.blob, 'the write path refuses a bad file on its own, even if validation were skipped');
  m = e.run(`billBlobFromClientFile_(null)`); ok(m.error, 'null file handled');
  m = e.run(`billBlobFromClientFile_({name:'a.pdf',data:'@@@'})`); ok(m.error, 'garbage data handled');
}

console.log(`\nv5 harness: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
