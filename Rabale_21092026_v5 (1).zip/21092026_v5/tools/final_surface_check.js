const fs=require('fs'),path=require('path');
const acorn=require(__dirname+'/node_modules/acorn');
const dir=path.resolve(__dirname,'..'); const files=fs.readdirSync(dir).filter(f=>/\.gs$/i.test(f));
const S=JSON.parse(fs.readFileSync(__dirname+'/surface.json','utf8'));
const called=new Set(S.called), handlers=new Set(S.handlers);
const rep=JSON.parse(fs.readFileSync(__dirname+'/harden_report.json','utf8')); const editor=new Set(rep.editorEntry);
let bad=[], counts={pages:0,handlers:0,doGet:0,editorGuarded:0}, unguardedEditor=[];
files.forEach(f=>{ const src=fs.readFileSync(path.join(dir,f),'utf8'); const ast=acorn.parse(src,{ecmaVersion:'latest',allowReturnOutsideFunction:true});
  ast.body.forEach(n=>{ if(n.type!=='FunctionDeclaration')return; const name=n.id.name; if(name.endsWith('_'))return;
    if(name==='doGet'){counts.doGet++;return;}
    if(called.has(name)){counts.pages++;return;}
    if(handlers.has(name)){counts.handlers++;return;}
    if(editor.has(name)){ counts.editorGuarded++; if(!/^\s*editorOnly_\(\)/.test(src.slice(n.body.start+1,n.body.start+120))) unguardedEditor.push(name); return; }
    bad.push(name+' ['+f+']'); }); });
console.log('public functions by group:',JSON.stringify(counts));
console.log('public functions outside every allowed group:',bad.length?bad:'NONE');
console.log('editor helpers missing their guard:',unguardedEditor.length?unguardedEditor:'NONE');
