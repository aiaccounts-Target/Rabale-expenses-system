// Maps the browser-callable surface of the Apps Script project: which top-level functions exist,
// which the pages really call, which are trigger handlers, which validate a session.
const fs=require('fs'),path=require('path'),vm=require('vm');
const acorn=require(__dirname+'/node_modules/acorn'), walk=require(__dirname+'/node_modules/acorn-walk');
const dir=path.resolve(process.argv[2]||path.join(__dirname,'..'));
const files=fs.readdirSync(dir).filter(f=>/\.gs$/i.test(f)).sort();
const src={}; files.forEach(f=>src[f]=fs.readFileSync(path.join(dir,f),'utf8'));
const asts={}; files.forEach(f=>{ asts[f]=acorn.parse(src[f],{ecmaVersion:'latest',allowReturnOutsideFunction:true}); });
const defs={};                       // name -> {file,node}
files.forEach(f=>asts[f].body.forEach(n=>{ if(n.type==='FunctionDeclaration'){ if(defs[n.id.name]) console.error('DUPLICATE top-level function',n.id.name); defs[n.id.name]={file:f,node:n}; }}));
const names=new Set(Object.keys(defs));
// client scripts: the app page + the email-confirm page
function clientScripts(){
  const ctx=vm.createContext({console,Logger:{log(){}},PropertiesService:{getScriptProperties:()=>({getProperty:()=>null,getProperties:()=>({})}),getUserProperties:()=>({getProperty:()=>null})},
    HtmlService:{createHtmlOutput:h=>({_h:h}),XFrameOptionsMode:{ALLOWALL:1}},CacheService:{getScriptCache:()=>({get:()=>null,put(){},putAll(){},getAll:()=>({}),remove(){},removeAll(){}})},
    Session:{getEffectiveUser:()=>({getEmail:()=>'x@y'}),getActiveUser:()=>({getEmail:()=>'x@y'})},SpreadsheetApp:{},LockService:{},UrlFetchApp:{},Utilities:{},MailApp:{},DriveApp:{},ScriptApp:{},ContentService:{}});
  vm.runInContext(files.map(f=>src[f]).join('\n;\n'),ctx);
  const pages=[vm.runInContext('typeof getAppHTML==="function"?getAppHTML():getAppHTML_()',ctx)];
  try{ pages.push(vm.runInContext("emailVerifyPageHtml_('x')",ctx)); }catch(e){ try{pages.push(vm.runInContext("emailVerifyPageHtml('x')",ctx));}catch(e2){ console.error('no verify page rendered',e2.message);} }
  const out=[]; pages.forEach(p=>{ p=typeof p==='string'?p:(p&&p._h)||''; const re=/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi; let m; while((m=re.exec(p))) out.push(m[1]); });
  return out;
}
const called=new Set();
clientScripts().forEach(js=>{ const ast=acorn.parse(js,{ecmaVersion:'latest',allowReturnOutsideFunction:true});
  walk.simple(ast,{CallExpression(n){ const c=n.callee; if(c.type==='MemberExpression'&&!c.computed&&names.has(c.property.name)) called.add(c.property.name); }}); });
const handlers=new Set(); files.forEach(f=>{ const re=/newTrigger\('([A-Za-z0-9_]+)'\)/g; let m; while((m=re.exec(src[f]))) handlers.add(m[1]); });
// session guards: a function is a guard if it calls validateSession; a function is guarded if it calls a guard (transitively 2 levels)
const calls={}; Object.keys(defs).forEach(n=>{ const s=new Set(); walk.simple(defs[n].node.body,{CallExpression(c){ if(c.callee.type==='Identifier') s.add(c.callee.name); }}); calls[n]=s; });
const guard=new Set(['validateSession','validateSession_']); for(let i=0;i<4;i++) Object.keys(calls).forEach(n=>{ if([...calls[n]].some(c=>guard.has(c))&&/token|session/i.test(defs[n].node.params.map(p=>p.name||'').join(',')+n)) guard.add(n); });
const out={defs:Object.keys(defs),called:[...called].sort(),handlers:[...handlers].sort(),guard:[...guard].sort()};
fs.writeFileSync(__dirname+'/surface.json',JSON.stringify(out,null,1));
const pub=Object.keys(defs).filter(n=>!n.endsWith('_'));
const guarded=pub.filter(n=>[...calls[n]].some(c=>guard.has(c)));
console.log('functions',Object.keys(defs).length,'| public',pub.length,'| called by pages',called.size,'| trigger handlers',handlers.size,'| guarded (validate a session)',guarded.length);
const rest=pub.filter(n=>!called.has(n)&&!handlers.has(n)&&!guarded.includes(n)&&n!=='doGet');
console.log('public, not called by any page, not a handler, no session check:',rest.length);
fs.writeFileSync(__dirname+'/surface_rest.txt',rest.join('\n'));
console.log('called by pages but with NO session check inside (must be intentional):');
called.forEach(n=>{ if(!guarded.includes(n)) console.log('  ',n,'['+defs[n].file+']'); });
