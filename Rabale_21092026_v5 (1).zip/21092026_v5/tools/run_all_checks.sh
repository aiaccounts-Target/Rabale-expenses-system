#!/usr/bin/env bash
# Runs every check for this release. Needs node 18+, python3 with beautifulsoup4, and network for the one-time npm install.
set -e; cd "$(dirname "$0")"
[ -d node_modules/acorn-walk ] && [ -d node_modules/eslint ] || npm install acorn@8 acorn-walk@8 eslint@8 --no-audit --no-fund >/dev/null 2>&1
T=$(mktemp -d); for f in ../*.gs ../*.GS; do b=$(basename "$f"); cp "$f" "$T/$(echo "$b" | tr ' ' '_').js"; done
echo "1. node --check on every server file"; for f in "$T"/*.js; do node --check "$f"; done; echo "   all $(ls "$T"/*.js | wc -l) files parse"
echo "2. render the app page";                  node render_app.js .. "$T/rendered.html"; echo "   rendered $(wc -c < "$T/rendered.html") characters"
echo "3-6. DOM ids, tag balance, client script, el() cross-reference"; python3 protocol_checks.py "$T/rendered.html" | sed 's/^/   /'
echo "6b. nothing is used without a definition"; node undef_check.js
echo "7. public surface: every public function is accounted for"; node surface.js .. >/dev/null; node final_surface_check.js | sed 's/^/   /'
echo "8. server behaviour (2FA, guards, bill types, triggers, framing)"; node test_v5.js | sed 's/^/   /'
echo "9. login / Admin code screen (real emitted code, fake DOM)"; node client_admin_test.js "$T/rendered.html" | sed 's/^/   /'
echo "10. ledger suggestion (server, client)"; node test_ledger_suggest.js | tail -1 | sed 's/^/   /'
python3 - "$T/rendered.html" <<'PY'
import re,sys; h=open(sys.argv[1],encoding='utf-8').read(); s=re.findall(r'<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)</script>',h); open(sys.argv[1]+'.js','w').write('\n'.join(s))
PY
node test_ledger_suggest_client.js "$T/rendered.html.js" | tail -1 | sed 's/^/   /'
echo; echo "ALL CHECKS PASSED"
