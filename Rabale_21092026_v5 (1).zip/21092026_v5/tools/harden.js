// Closes the "every public function is callable from the browser" hole.
//   In Apps Script every top-level function whose name does NOT end in "_" can be called by any visitor through
//   google.script.run. This keeps public ONLY: functions the pages really call, trigger handlers, doGet, and
//   editor-run helpers (which get an editorOnly_() guard). Everything else is renamed name -> name_ (private).
// Uses a real JavaScript parser (acorn): strings, comments and property names (Utilities.formatDate) are never touched.
const fs = require('fs'), path = require('path'), vm = require('vm');
const acorn = require(__dirname + '/node_modules/acorn');
const dir = path.resolve(process.argv[2] || path.join(__dirname, '..'));
const files = fs.readdirSync(dir).filter(f => /\.gs$/i.test(f)).sort();
const raw = {}; files.forEach(f => raw[f] = fs.readFileSync(path.join(dir, f), 'utf8'));
const ast = {}; files.forEach(f => ast[f] = acorn.parse(raw[f], { ecmaVersion: 'latest', allowReturnOutsideFunction: true }));

// ---- generic traversal (parent + key), independent of acorn-walk quirks ----
function traverse(node, fn, parent, key) {
  if (!node || typeof node.type !== 'string') return;
  if (fn(node, parent, key) === false) return;
  for (const k of Object.keys(node)) {
    const v = node[k];
    if (Array.isArray(v)) v.forEach(c => c && typeof c.type === 'string' && traverse(c, fn, node, k));
    else if (v && typeof v.type === 'string') traverse(v, fn, node, k);
  }
}
// ---- definitions ----
const defs = {};
files.forEach(f => ast[f].body.forEach(n => { if (n.type === 'FunctionDeclaration') { if (defs[n.id.name]) throw new Error('duplicate ' + n.id.name); defs[n.id.name] = { file: f, node: n }; } }));
const names = Object.keys(defs);
const pub = names.filter(n => !n.endsWith('_'));

// ---- what the pages call (rendered client scripts + email-confirm page) ----
function renderPages() {
  const ctx = vm.createContext({ console, Logger: { log() {} },
    PropertiesService: { getScriptProperties: () => ({ getProperty: () => null, getProperties: () => ({}) }), getUserProperties: () => ({ getProperty: () => null }) },
    HtmlService: { createHtmlOutput: h => ({ _h: h }), XFrameOptionsMode: { ALLOWALL: 1 } },
    CacheService: { getScriptCache: () => ({ get: () => null, put() {}, putAll() {}, getAll: () => ({}), remove() {}, removeAll() {} }) },
    Session: { getEffectiveUser: () => ({ getEmail: () => 'x@y' }), getActiveUser: () => ({ getEmail: () => 'x@y' }) },
    SpreadsheetApp: {}, LockService: {}, UrlFetchApp: {}, Utilities: {}, MailApp: {}, DriveApp: {}, ScriptApp: {}, ContentService: {} });
  vm.runInContext(files.map(f => raw[f]).join('\n;\n'), ctx);
  const pages = [vm.runInContext('typeof getAppHTML === "function" ? getAppHTML() : getAppHTML_()', ctx)];
  pages.push(vm.runInContext("emailVerifyPageHtml_('x')", ctx));
  const out = []; pages.forEach(p => { p = typeof p === 'string' ? p : (p && p._h) || ''; const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi; let m; while ((m = re.exec(p))) out.push(m[1]); });
  return out;
}
const called = new Set();
renderPages().forEach(js => traverse(acorn.parse(js, { ecmaVersion: 'latest', allowReturnOutsideFunction: true }), (n) => {
  if (n.type === 'CallExpression' && n.callee.type === 'MemberExpression' && !n.callee.computed && defs[n.callee.property.name]) called.add(n.callee.property.name);
}));
const handlers = new Set();
files.forEach(f => { const re = /newTrigger\('([A-Za-z0-9_]+)'\)/g; let m; while ((m = re.exec(raw[f]))) handlers.add(m[1]); });

// ---- who references whom (identifier references, not strings) ----
const refs = {}; names.forEach(n => refs[n] = new Set());
names.forEach(caller => traverse(defs[caller].node.body, (n, p, k) => {
  if (n.type === 'Identifier' && defs[n.name] && n.name !== caller) {
    if (p && p.type === 'MemberExpression' && k === 'property' && !p.computed) return;
    refs[n.name].add(caller);
  }
}));
// also references from top-level statements that are not function declarations (var initialisers etc.)
files.forEach(f => ast[f].body.forEach(st => { if (st.type !== 'FunctionDeclaration') traverse(st, (n, p, k) => {
  if (n.type === 'Identifier' && defs[n.name]) { if (p && p.type === 'MemberExpression' && k === 'property' && !p.computed) return; refs[n.name].add('<top-level>'); }
}); }));

// ---- editor-run helpers: named by the project's own comments/conventions, verified by the call graph ----
const editorCandidates = new Set(JSON.parse(fs.readFileSync(__dirname + '/editor_candidates.json', 'utf8')).concat(['benchmarkPasswordHash']));
// callers allowed to reach a guarded helper: other editor helpers, and the Admin-only wrapper that sets TRUSTED_SERVER_CALL_
const allowedCallers = new Set([...editorCandidates, 'repairScheduledTriggers']);
let entrySet = new Set([...editorCandidates].filter(n => defs[n]));
for (let changed = true; changed;) { changed = false; for (const n of [...entrySet]) if (![...refs[n]].every(c => entrySet.has(c) || c === 'repairScheduledTriggers')) { entrySet.delete(n); changed = true; } }
const editorEntry = [...entrySet];
const editorInternalToo = [...editorCandidates].filter(n => defs[n] && !editorEntry.includes(n)); // also used by normal app code -> must stay callable by the app, so private

const keepPublic = new Set([...called, ...handlers, 'doGet', ...editorEntry]);
const rename = pub.filter(n => !keepPublic.has(n));
const renameSet = new Set(rename);

// ---- safety checks before touching anything ----
const allIdent = new Set(); files.forEach(f => traverse(ast[f], n => { if (n.type === 'Identifier') allIdent.add(n.name); }));
const newName = {}; const used = new Set([...allIdent]);
rename.forEach(n => { let t = n + '_'; if (used.has(t)) t = n + 'Impl_'; if (used.has(t)) throw new Error('cannot find a free private name for ' + n); newName[n] = t; used.add(t); });
const collided = rename.filter(n => newName[n] !== n + '_');
if (collided.length) console.log('name already taken, using Impl_ suffix for:', collided.join(', '));
const notDefinedHandlers = [...handlers].filter(h => !defs[h]);
if (notDefinedHandlers.length) throw new Error('trigger handler missing: ' + notDefinedHandlers);

// ---- edits ----
let totalEdits = 0, guardsAdded = 0;
files.forEach(f => {
  const edits = []; const src = raw[f]; const nl = src.includes('\r\n') ? '\r\n' : '\n';
  traverse(ast[f], (n, p, k) => {
    if (n.type === 'Property' && n.shorthand && n.value.type === 'Identifier' && renameSet.has(n.value.name)) {
      edits.push([n.start, n.end, n.value.name + ': ' + newName[n.value.name]]); return false;
    }
    if (n.type === 'Identifier' && renameSet.has(n.name)) {
      if (p && p.type === 'MemberExpression' && k === 'property' && !p.computed) return;
      if (p && p.type === 'Property' && k === 'key' && !p.computed) return;
      if (p && (p.type === 'MethodDefinition' || p.type === 'PropertyDefinition') && k === 'key' && !p.computed) return;
      if (p && (p.type === 'LabeledStatement' || p.type === 'BreakStatement' || p.type === 'ContinueStatement') && k === 'label') return;
      edits.push([n.start, n.end, newName[n.name]]);
    }
  });
  ast[f].body.forEach(st => {
    if (st.type === 'FunctionDeclaration' && editorEntry.includes(st.id.name) && !/^\s*editorOnly_\(\)/.test(src.slice(st.body.start + 1, st.body.start + 80))) {
      edits.push([st.body.start + 1, st.body.start + 1, nl + '  editorOnly_(); // refuses anyone who is not running this from the Apps Script editor' ]); guardsAdded++;
    }
  });
  edits.sort((a, b) => b[0] - a[0] || b[1] - a[1]);
  let out = src; edits.forEach(([s, e, t]) => { out = out.slice(0, s) + t + out.slice(e); });
  totalEdits += edits.length;
  fs.writeFileSync(path.join(dir, f), out);
});

const report = { functions: names.length, publicBefore: pub.length, calledByPages: [...called].sort(), handlers: [...handlers].sort(), doGet: 'doGet',
  editorEntry: editorEntry.sort(), editorAlsoUsedByApp: editorInternalToo.sort(), renamedCount: rename.length, renamed: rename.sort(), newName, edits: totalEdits, guardsAdded };
fs.writeFileSync(__dirname + '/harden_report.json', JSON.stringify(report, null, 1));
console.log(`public before: ${pub.length} | kept public: ${keepPublic.size} (pages ${called.size}, handlers ${handlers.size}, doGet 1, editor ${editorEntry.length}) | renamed to private: ${rename.length} | identifier edits: ${totalEdits} | guards added: ${guardsAdded}`);
console.log('editor helpers that are ALSO used by normal app code (made private, not guarded):', editorInternalToo.join(', ') || 'none');
