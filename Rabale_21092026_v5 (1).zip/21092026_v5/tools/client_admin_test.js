// Runs the REAL emitted login-page code (extracted from the rendered app with a JS parser) against a fake DOM.
// Usage: node client_admin_test.js <rendered-app.html>
const fs = require('fs'), vm = require('vm');
const acorn = require(__dirname + '/node_modules/acorn');
const html = fs.readFileSync(process.argv[2], 'utf8');
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : (fail++, console.log('  FAIL:', m)); };
const scripts = []; { const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi; let m; while ((m = re.exec(html))) scripts.push(m[1]); }
const js = scripts.join('\n;\n'); const ast = acorn.parse(js, { ecmaVersion: 'latest', allowReturnOutsideFunction: true });
const WANT_FN = ['lgStore', 'lgFinePointer', 'lgAlert', 'lgFieldError', 'lgFlag', 'lgClearView', 'lgSetBusy', 'showLoginView', 'doLogin', 'admStartCooldown', 'openAdminCodeView', 'admBackToLogin', 'doAdminCode', 'doAdminResend'];
const WANT_VAR = ['LG_ICON', 'LG_VIEWS', 'LG_VIEW_ALERT', 'LG_REMEMBER_KEY', 'lgBusy'];
let body = ast.body; const iife = ast.body.length === 1 && ast.body[0].type === 'ExpressionStatement' && ast.body[0].expression.type === 'CallExpression' ? ast.body[0].expression.callee : null;
if (iife && iife.body && iife.body.body) body = iife.body.body;   // the whole client app is one IIFE: look inside it
const parts = []; body.forEach(n => {
  if (n.type === 'FunctionDeclaration' && WANT_FN.includes(n.id.name)) parts.push(js.slice(n.start, n.end));
  if (n.type === 'VariableDeclaration' && n.declarations.some(d => WANT_VAR.includes(d.id.name))) parts.push(js.slice(n.start, n.end));
});
const found = WANT_FN.filter(f => parts.some(p => p.startsWith('function ' + f + '(')));
ok(found.length === WANT_FN.length, 'all login functions found in the rendered page: missing ' + WANT_FN.filter(f => !found.includes(f)));
const code = parts.join('\n');

class El {
  constructor(id) { this.id = id; this.children = []; this._cl = new Set(); this.attrs = {}; this.listeners = {}; this._text = ''; this.value = ''; this.disabled = false; this.checked = false; this.style = {}; this.focused = 0; this._q = []; this._label = null; }
  get classList() { const s = this; return { add: c => s._cl.add(c), remove: c => s._cl.delete(c), contains: c => s._cl.has(c), toggle: (c, f) => { (f === undefined ? !s._cl.has(c) : f) ? s._cl.add(c) : s._cl.delete(c); } }; }
  set innerHTML(v) { this.children = []; } set textContent(v) { this._text = String(v); this.children = []; } get textContent() { return this._text + this.children.map(c => c.textContent).join(''); }
  appendChild(c) { this.children.push(c); return c; } setAttribute(k, v) { this.attrs[k] = String(v); } getAttribute(k) { return k in this.attrs ? this.attrs[k] : null; } removeAttribute(k) { delete this.attrs[k]; }
  querySelector(sel) { if (sel === '.lg-btn-label') return this._label || (this._label = new El('label')); return null; }
  querySelectorAll(sel) { return this._q; }
  focus() { this.focused++; }
}
function setup() {
  const ids = ['loginFormView', 'forgotView', 'resetView', 'adminCodeView', 'loginAlert', 'forgotAlert', 'resetAlert', 'adminCodeAlert', 'loginRecovery', 'loginTakeover', 'loginUsername', 'loginPassword', 'loginRemember',
    'loginBtn', 'loginTakeoverBtn', 'adminCode', 'adminCodeErr', 'adminCodeHint', 'adminCodeTakeover', 'adminCodeTakeoverBtn', 'adminCodeBtn', 'adminCodeResendBtn', 'adminCodeBackBtn', 'loginTitle', 'adminCodeTitle', 'loginUsernameErr', 'loginPasswordErr',
    'resetTitle', 'forgotTitle', 'resetUsername', 'resetCode'];
  const els = {}; ids.forEach(i => els[i] = new El(i));
  els.loginFormView._q = [els.loginUsername, els.loginPassword]; els.adminCodeView._q = [els.adminCode];
  ['loginTakeover', 'loginRecovery', 'adminCodeTakeover', 'forgotView', 'resetView', 'adminCodeView'].forEach(i => els[i]._cl.add('hidden'));
  els.loginUsername.value = 'AdminRabale'; els.loginPassword.value = 'pin-typed';
  const intervals = []; const calls = []; const q = [];
  const routed = [], store = {};
  const runObj = {
    withSuccessHandler(f) { this._s = f; return this; }, withFailureHandler(f) { this._f = f; return this; },
    verifyLogin(...a) { calls.push(['verifyLogin', ...a]); q.push({ s: this._s, f: this._f }); return this; },
    verifyAdminSecondFactor(...a) { calls.push(['verifyAdminSecondFactor', ...a]); q.push({ s: this._s, f: this._f }); return this; },
    resendAdminSecondFactor(...a) { calls.push(['resendAdminSecondFactor', ...a]); q.push({ s: this._s, f: this._f }); return this; },
  };
  const ctx = vm.createContext({ console, el: i => { if (!els[i]) throw new Error('el(' + i + ') not in fake DOM'); return els[i]; },
    document: { createElement: t => new El(t) }, google: { script: { get run() { return Object.assign(Object.create(runObj), {}); } } },
    setInterval: (f) => { intervals.push(f); return intervals.length; }, clearInterval: (id) => { if (id && intervals[id - 1]) intervals[id - 1] = null; },
    localStorage: { getItem: () => null, setItem() {}, removeItem() {} }, sessionStorage: { setItem: (k, v) => { store[k] = v; } },
    window: { matchMedia: () => ({ matches: false }) }, routeToRolePage: r => routed.push(r), appToken: '', appRole: '', appDisplayName: '', appDesignation: '' });
  vm.runInContext(code, ctx);
  return { els, ctx, calls, q, routed, store, intervals, tick() { intervals.slice().forEach(f => f && f()); }, run: s => vm.runInContext(s, ctx) };
}
const visible = (h, id) => !h.els[id].classList.contains('hidden');
const R2FA = { success: false, needs2fa: true, challengeId: 'c'.repeat(64), maskedEmail: 'o***@example.com', expiryMinutes: 10, resendSeconds: 30 };

// 1. first step: PIN accepted -> code screen (no login yet)
{
  const h = setup(); h.run('doLogin()');
  ok(h.calls.length === 1 && h.calls[0][0] === 'verifyLogin' && h.calls[0][1] === 'AdminRabale' && h.calls[0][2] === 'pin-typed' && h.calls[0][3] === false, 'doLogin sends username, PIN, takeover=false');
  h.q[0].s(R2FA);
  ok(visible(h, 'adminCodeView') && !visible(h, 'loginFormView'), 'the code screen replaces the login form');
  ok(/o\*\*\*@example\.com/.test(h.els.adminCodeHint.textContent) && /10 minutes/.test(h.els.adminCodeHint.textContent), 'hint shows the masked address and expiry');
  ok(h.els.loginPassword.value === '', 'the typed PIN is wiped from the form');
  ok(h.routed.length === 0 && h.run('appToken') === '', 'no session, nothing routed');
  ok(h.els.adminCodeResendBtn.disabled === true && /30s/.test(h.els.adminCodeResendBtn.textContent), 'resend is on a 30 s cool-down');
  for (let i = 0; i < 30; i++) h.tick(); ok(h.els.adminCodeResendBtn.disabled === false && h.els.adminCodeResendBtn.textContent === 'Send a new code', 'cool-down ends and resend is enabled');
  ok(h.els.adminCode.focused >= 0, 'code field present');
}
// 2. validation before any call
{
  const h = setup(); h.run('doLogin()'); h.q[0].s(R2FA); h.calls.length = 0;
  h.els.adminCode.value = '12'; h.run('doAdminCode(false)'); ok(h.calls.length === 0 && /6-digit/.test(h.els.adminCodeErr.textContent), 'short code: field error, no server call');
  h.els.adminCode.value = ''; h.run('doAdminCode(false)'); ok(h.calls.length === 0, 'empty code: no server call');
}
// 3. correct code -> logged in
{
  const h = setup(); h.run('doLogin()'); h.q[0].s(R2FA); h.els.loginRemember.checked = true;
  h.els.adminCode.value = '123 456'; h.run('doAdminCode(false)');
  const c = h.calls[h.calls.length - 1]; ok(c[0] === 'verifyAdminSecondFactor' && c[1] === R2FA.challengeId && c[2] === '123456' && c[3] === false, 'sends the challenge id and the digits only');
  ok(h.els.adminCodeBtn._label.attrs['data-idle'] === 'Log in' || h.run('lgBusy') === true, 'button shows busy while waiting');
  h.q[h.q.length - 1].s({ success: true, token: 't'.repeat(64), role: 'admin', displayName: 'Admin' });
  ok(h.routed[0] === 'admin' && h.run('appToken') === 't'.repeat(64) && h.store.appToken === 't'.repeat(64) && h.store.appRole === 'admin', 'session stored and the Admin page opened');
  ok(h.run('lgBusy') === false, 'busy state cleared');
}
// 4. wrong code -> message, stays on screen, field cleared
{
  const h = setup(); h.run('doLogin()'); h.q[0].s(R2FA); h.els.adminCode.value = '000000'; h.run('doAdminCode(false)');
  h.q[h.q.length - 1].s({ success: false, error: 'That code is incorrect or has expired. Check the latest email. 4 attempt(s) remaining.' });
  ok(visible(h, 'adminCodeView') && /4 attempt/.test(h.els.adminCodeAlert.textContent) && h.els.adminCodeAlert.attrs['data-kind'] === 'error', 'error shown on the code screen');
  ok(h.els.adminCode.value === '' && h.routed.length === 0, 'code cleared, not logged in');
}
// 5. restart (expired / too many wrong codes / locked) -> back to the login form with the reason
{
  const h = setup(); h.run('doLogin()'); h.q[0].s(R2FA); h.els.adminCode.value = '000000'; h.run('doAdminCode(false)');
  h.q[h.q.length - 1].s({ success: false, restart: true, error: 'Too many incorrect codes. Please log in again.' });
  ok(visible(h, 'loginFormView') && !visible(h, 'adminCodeView'), 'returned to the login form');
  ok(/Too many incorrect codes/.test(h.els.loginAlert.textContent) && h.run('_admChallenge') === '', 'reason shown, challenge forgotten');
  h.calls.length = 0; h.els.adminCode.value = '123456'; h.run('doAdminCode(false)');
  ok(h.calls[0][1] === '', 'a stale challenge id is never sent again');
}
// 6. already logged in elsewhere -> override button, then override uses the same challenge without a code
{
  const h = setup(); h.run('doLogin()'); h.q[0].s(R2FA); h.els.adminCode.value = '123456'; h.run('doAdminCode(false)');
  h.q[h.q.length - 1].s({ success: false, alreadyLoggedIn: true, canTakeover: true, retryAfterSeconds: 60, error: 'This account is already logged in on another device or browser.' });
  ok(visible(h, 'adminCodeTakeover') && /already logged in/.test(h.els.adminCodeAlert.textContent), 'override offered on the code screen');
  h.run('doAdminCode(true)'); const c = h.calls[h.calls.length - 1];
  ok(c[0] === 'verifyAdminSecondFactor' && c[1] === R2FA.challengeId && c[3] === true, 'override sends takeover=true on the same challenge');
  h.q[h.q.length - 1].s({ success: true, token: 'o'.repeat(64), role: 'admin' }); ok(h.routed[0] === 'admin', 'override completes the login');
}
// 7. resend
{
  const h = setup(); h.run('doLogin()'); h.q[0].s(R2FA); for (let i = 0; i < 30; i++) h.tick();
  h.run('doAdminResend()'); ok(h.calls[h.calls.length - 1][0] === 'resendAdminSecondFactor' && h.calls[h.calls.length - 1][1] === R2FA.challengeId, 'resend sends the challenge id');
  ok(h.els.adminCodeResendBtn.disabled === true, 'button disabled while sending');
  h.q[h.q.length - 1].s({ success: true, resendSeconds: 30 }); ok(/new code is on its way/.test(h.els.adminCodeAlert.textContent) && /30s/.test(h.els.adminCodeResendBtn.textContent), 'confirmation and a fresh cool-down');
  for (let i = 0; i < 30; i++) h.tick(); h.run('doAdminResend()'); h.q[h.q.length - 1].s({ success: false, error: 'The login code could not be sent.' });
  ok(/could not be sent/.test(h.els.adminCodeAlert.textContent) && h.els.adminCodeResendBtn.disabled === false, 'a send failure is shown and resend is re-enabled');
  h.run('doAdminResend()'); h.q[h.q.length - 1].s({ success: false, restart: true, error: 'That login has expired. Please log in again.' }); ok(visible(h, 'loginFormView'), 'an expired challenge on resend returns to the login form');
}
// 8. server error and back button
{
  const h = setup(); h.run('doLogin()'); h.q[0].s(R2FA); h.els.adminCode.value = '123456'; h.run('doAdminCode(false)');
  h.q[h.q.length - 1].f('network down'); ok(/Server error: network down/.test(h.els.adminCodeAlert.textContent) && h.run('lgBusy') === false, 'network failure shown, form usable again');
  h.run('admBackToLogin("")'); ok(visible(h, 'loginFormView') && h.run('_admChallenge') === '', 'Back to log in returns and forgets the challenge');
}
// 9. ordinary logins are unaffected
{
  const h = setup(); h.els.loginUsername.value = 'sam'; h.run('doLogin()');
  h.q[0].s({ success: true, token: 'u'.repeat(64), role: 'submission', displayName: 'Sam' }); ok(h.routed[0] === 'submission' && !visible(h, 'adminCodeView'), 'a normal user logs straight in, no code screen');
  const h2 = setup(); h2.run('doLogin()'); h2.q[0].s({ success: false, error: 'Incorrect username or password.' }); ok(!visible(h2, 'adminCodeView') && /Incorrect/.test(h2.els.loginAlert.textContent), 'a wrong PIN shows the usual error');
  const h3 = setup(); h3.run('doLogin()'); h3.q[0].s({ success: false, alreadyLoggedIn: true, canTakeover: true, error: 'x' }); ok(visible(h3, 'loginTakeover'), 'old override button still works when the second factor is switched off');
}
console.log(`\nadmin code screen harness: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
