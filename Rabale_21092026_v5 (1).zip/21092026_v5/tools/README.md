# tools (v5)
`./run_all_checks.sh` runs everything (node 18+, python3 + beautifulsoup4; the first run does `npm install acorn acorn-walk eslint` here).
- `harden.js`               the parser-based pass that made 172 internal functions private and guarded 23 editor helpers. ALREADY APPLIED to these files; re-running it changes nothing. Kept so the result can be audited.
- `surface.js`              maps which functions the pages call, which are trigger handlers, which validate a session (writes surface.json).
- `final_surface_check.js`  fails if any public function is outside: page-called / trigger handler / doGet / guarded editor helper.
- `undef_check.js`          fails if any identifier is used but not defined (catches a rename that missed a reference).
- `protocol_checks.py`      duplicate DOM ids, tag balance, client script syntax, el("id") cross-reference (vdQuerySlot is the known innerHTML false positive).
- `test_v5.js`              server behaviour against the real files with a mock Google environment.
- `client_admin_test.js`    the login / Admin code screen, real emitted code, fake DOM.
- `test_ledger_suggest*.js`, `eval_engine.js`, `build_seed.py`   the ledger-suggestion tests/tools from v4.
