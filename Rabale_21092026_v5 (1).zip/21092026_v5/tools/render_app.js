const fs=require('fs'),vm=require('vm'),path=require('path');
const dir=path.resolve(process.argv[2]||path.join(__dirname,'..'));
const files=fs.readdirSync(dir).filter(f=>/\.gs$/i.test(f));
const ctx=vm.createContext({console,Logger:{log(){}},
  PropertiesService:{getScriptProperties:()=>({getProperty:()=>null,setProperty(){},getProperties:()=>({})}),getUserProperties:()=>({getProperty:()=>null})},
  HtmlService:{createHtmlOutput:h=>({_h:h}),createTemplate:()=>({}),XFrameOptionsMode:{ALLOWALL:1}},
  CacheService:{getScriptCache:()=>({get:()=>null,put(){},putAll(){},getAll:()=>({}),remove(){},removeAll(){}})},
  Session:{getEffectiveUser:()=>({getEmail:()=>'x@y'}),getActiveUser:()=>({getEmail:()=>'x@y'})},
  SpreadsheetApp:{},LockService:{},UrlFetchApp:{},Utilities:{},MailApp:{},DriveApp:{},ScriptApp:{},ContentService:{}});
vm.runInContext(files.map(f=>fs.readFileSync(path.join(dir,f),'utf8')).join('\n;\n'),ctx,{filename:'ALL.gs'});
const out=vm.runInContext('typeof getAppHTML==="function"?getAppHTML():getAppHTML_()',ctx);
fs.writeFileSync(path.resolve(process.argv[3]||'rendered.html'),typeof out==='string'?out:out._h);
