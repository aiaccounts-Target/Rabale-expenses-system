const fs=require('fs'), vm=require('vm');
const ctx=vm.createContext({console,Logger:{log(){}}});
for (const f of ['Ledger Seed.gs','Ledger Suggest.gs']) vm.runInContext(fs.readFileSync(f,'utf8'),ctx,{filename:f});
const rows=JSON.parse(fs.readFileSync('eval_rows.json','utf8'));
const CUT=process.argv[2]||'2026-03-01';
const ACTIVE=[...new Set(rows.map(r=>r.orig))];
const run=(src)=>vm.runInContext(src,ctx);
ctx.rows=rows; ctx.CUT=CUT; ctx.ACTIVE=ACTIVE;
const out=run(`
(function(){
  var ex=[], seen={};
  rows.forEach(function(r){ if(r.date<CUT && r.guide){ var k=r.guide+'|'+r.text; if(seen[k])return; seen[k]=1; ex.push({t:r.text,l:r.guide,w:1}); }});
  for (var l in LS_HINTS) LS_HINTS[l].forEach(function(t){ ex.push({t:t,l:l,w:1.2}); });
  var model=lsBuildModel_(ex);
  var res=[];
  rows.filter(function(r){return r.date>=CUT;}).forEach(function(r){
    var o=lsSuggestCore_(model,r.text,ACTIVE);
    res.push({orig:r.orig,guide:r.guide,text:r.text,tier:o.tier,top:o.suggestions.length?o.suggestions[0].ledger:null,
              top3:o.suggestions.map(function(s){return s.ledger;}),share:o.topShare||0,sim:o.topSim||0});
  });
  return JSON.stringify({n:ex.length,res:res});
})()`);
const {n,res}=JSON.parse(out);
const pct=(a,b)=>b?(100*a/b).toFixed(1)+'%':'-';
console.log('train examples',n,'| test rows',res.length,'| cutoff',CUT);
for (const [name,key] of [['vs ORIGINAL extract label','orig'],['vs GUIDE-aligned label','guide']]){
  const t=res.filter(r=>r[key]);
  const h1=t.filter(r=>r.top===r[key]).length, h3=t.filter(r=>r.top3.includes(r[key])).length;
  console.log(`\n${name}: rows=${t.length} top1=${pct(h1,t.length)} top3=${pct(h3,t.length)}`);
  for (const tier of ['high','medium','low','none']){
    const g=t.filter(r=>r.tier===tier); if(!g.length) continue;
    console.log(`   tier ${tier.padEnd(6)} share of vouchers ${pct(g.length,t.length).padStart(6)}  top1 correct ${pct(g.filter(r=>r.top===r[key]).length,g.length).padStart(6)}  in top3 ${pct(g.filter(r=>r.top3.includes(r[key])).length,g.length).padStart(6)}`);
  }
}
if (process.argv[3]==='grid'){
  const t=res.filter(r=>r.guide);
  console.log('\nthreshold grid (guide labels): share>=S & sim>=M -> coverage / top1 accuracy');
  for (const S of [0.6,0.65,0.7,0.75,0.8]) for (const M of [0.3,0.4,0.5]){
    const g=t.filter(r=>r.share>=S&&r.sim>=M);
    console.log(`  S=${S} M=${M}  coverage ${pct(g.length,t.length).padStart(6)}  accuracy ${pct(g.filter(r=>r.top===r.guide).length,g.length).padStart(6)}`);
  }
}
if (process.argv[3]==='errors'){
  const t=res.filter(r=>r.guide&&r.top!==r.guide).slice(0,25);
  t.forEach(r=>console.log(`- [${r.tier}] want ${r.guide} | got ${r.top} | ${r.text.slice(0,90)}`));
}
