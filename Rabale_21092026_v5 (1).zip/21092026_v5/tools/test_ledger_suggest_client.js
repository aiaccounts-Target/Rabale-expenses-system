// Client-side harness for the ledger-suggestion UI. Runs the REAL emitted code from the rendered
// app (client script extracted by the verification step) against a minimal fake DOM.
// Usage: node client_test.js <path-to-extracted-client-script.js>
const fs = require('fs'), vm = require('vm');
const js = fs.readFileSync(process.argv[2] || (__dirname + '/chk/v4_client.js'), 'utf8');
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : (fail++, console.log('  FAIL:', m)); };
const start = js.indexOf('var _lsSeq='), e0 = js.indexOf('function lsOnDescInput(){');
const end = js.indexOf('\n}', e0) + 2; const code = js.slice(start, end);
ok(start > 0 && e0 > start, 'suggestion code found in rendered client script');

class El {
  constructor(t) { this.tag = t; this.children = []; this._cl = new Set(); this.attrs = {}; this.listeners = {}; this._text = ''; this.value = ''; this.disabled = false; this.title = ''; }
  get classList() { const s = this; return { add: c => s._cl.add(c), remove: c => s._cl.delete(c), contains: c => s._cl.has(c), toggle: (c, f) => { (f === undefined ? !s._cl.has(c) : f) ? s._cl.add(c) : s._cl.delete(c); } }; }
  set className(v) { this._cl = new Set(String(v).split(/\s+/).filter(Boolean)); }
  get className() { return [...this._cl].join(' '); }
  set innerHTML(v) { this.children = []; this._text = ''; }
  set textContent(v) { this._text = String(v); this.children = []; }
  get textContent() { return this._text + this.children.map(c => c.textContent).join(''); }
  appendChild(c) { this.children.push(c); return c; }
  setAttribute(k, v) { this.attrs[k] = v; } getAttribute(k) { return this.attrs[k]; }
  addEventListener(t, f) { (this.listeners[t] = this.listeners[t] || []).push(f); }
  dispatchEvent(ev) { (this.listeners[ev.type] || []).forEach(f => f(ev)); }
  click() { this.dispatchEvent({ type: 'click' }); }
}
function setup() {
  const els = {}; ['lsBox', 'lsChips', 'lsNote', 'lsTitle', 'ledger', 'regularDescription'].forEach(i => els[i] = new El(i)); els.lsBox._cl.add('hidden');
  const timers = [], calls = [], pending = [];
  const run = { withSuccessHandler(f) { this._s = f; return this; }, withFailureHandler(f) { this._f = f; return this; }, suggestLedger(t, d) { pending.push({ ok: this._s, fail: this._f, t, d }); calls.push([t, d]); return this; } };
  const ctx = vm.createContext({ console, el: i => els[i], syncSSLabel() {}, Event: function (t) { this.type = t; }, appToken: 'TOK',
    document: { createElement: t => new El(t), createTextNode: t => { const n = new El('#text'); n._text = t; return n; } },
    google: { script: { get run() { return Object.assign(Object.create(run), {}); } } },
    setTimeout: (f) => { timers.push(f); return timers.length; }, clearTimeout: (id) => { if (id && timers[id - 1]) timers[id - 1] = null; } });
  vm.runInContext(code, ctx);
  return { els, ctx, timers, calls, pending, flush() { const t = timers.splice(0); t.forEach(f => f && f()); } };
}
const R = (tier, sug, hint) => ({ success: true, tier, suggestions: sug, hint: hint || '' });
const sug = (l, v) => ({ ledger: l, pct: 80, why: 'like: sugar', needsVehicle: !!v });

{ const h = setup(); h.els.regularDescription.value = 'ab'; vm.runInContext('lsOnDescInput()', h.ctx); h.flush(); ok(h.calls.length === 0 && h.els.lsBox.classList.contains('hidden'), 'short text: no call, box hidden'); }
{
  const h = setup(); h.els.regularDescription.value = 'sugar 10 kg'; vm.runInContext('lsOnDescInput()', h.ctx); ok(h.calls.length === 0, 'debounced (no call before timer)'); h.flush();
  ok(h.calls.length === 1 && h.calls[0][0] === 'TOK' && h.calls[0][1] === 'sugar 10 kg', 'one call with token and text');
  h.pending[0].ok(R('high', [sug('Pantry Material'), sug('Office Expenses')]));
  ok(!h.els.lsBox.classList.contains('hidden'), 'box shown'); ok(h.els.lsTitle.textContent === 'Suggested ledger', 'high title');
  ok(h.els.lsChips.children.length === 2 && h.els.lsChips.children[0].classList.contains('top') && !h.els.lsChips.children[1].classList.contains('top'), 'top chip highlighted only when high');
  ok(h.els.lsChips.children[0].title === 'like: sugar', 'why shown as tooltip');
  let changes = 0, val = '';
  Object.defineProperty(h.els.ledger, 'value', { get: () => val, set: v => { val = (['Pantry Material', 'Office Expenses'].includes(v) ? v : ''); } });
  h.els.ledger.addEventListener('change', () => changes++); h.els.ledger.addEventListener('change', () => vm.runInContext('lsMarkSelected()', h.ctx));
  h.els.lsChips.children[0].click();
  ok(val === 'Pantry Material' && changes === 1, 'chip click sets ledger and fires change once'); ok(h.els.lsChips.children[0].classList.contains('on'), 'selected chip marked');
  ok(vm.runInContext('_lsClicked', h.ctx) === 'Pantry Material', 'click remembered for logging');
}
{
  const h = setup(); h.els.regularDescription.value = 'first description here'; vm.runInContext('lsOnDescInput()', h.ctx); h.flush();
  h.els.regularDescription.value = 'second description here'; vm.runInContext('lsOnDescInput()', h.ctx); h.flush();
  h.pending[1].ok(R('high', [sug('Tea & Coffee')])); h.pending[0].ok(R('high', [sug('Office Expenses')]));
  ok(h.els.lsChips.children.length === 1 && h.els.lsChips.children[0].getAttribute('data-ledger') === 'Tea & Coffee', 'older response cannot overwrite newer one');
}
{
  const h = setup(); vm.runInContext('lsRender(' + JSON.stringify(R('medium', [sug('Vehicle Fastag', true)], 'transport')) + ')', h.ctx);
  ok(/pick the vehicle/.test(h.els.lsChips.children[0].textContent), 'vehicle hint on chip'); ok(/Transport Expense/.test(h.els.lsNote.textContent), 'transport hint note');
  ok(h.els.lsTitle.textContent === 'Which of these fits best?' && !h.els.lsChips.children[0].classList.contains('top'), 'medium wording, no top highlight');
  vm.runInContext('lsRender(' + JSON.stringify(R('low', [sug('Food Exp')])) + ')', h.ctx); ok(/Ask the Accounts team/.test(h.els.lsNote.textContent), 'low tier asks Accounts');
}
{
  const h = setup(); h.els.regularDescription.value = 'sugar 10 kg'; vm.runInContext('lsOnDescInput()', h.ctx); h.flush(); h.pending[0].fail('boom'); ok(h.els.lsBox.classList.contains('hidden'), 'server failure hides box, no exception');
  const h2 = setup(); h2.els.ledger.disabled = true; vm.runInContext('lsRender(' + JSON.stringify(R('high', [sug('Food Exp')])) + ')', h2.ctx); ok(h2.els.lsBox.classList.contains('hidden'), 'locked ledger: box hidden');
  const h3 = setup(); vm.runInContext('lsRender(' + JSON.stringify(R('none', [])) + ')', h3.ctx); ok(h3.els.lsBox.classList.contains('hidden') && vm.runInContext('_lsState.top', h3.ctx) === '', 'no suggestion: hidden, state recorded as empty');
}
{ const h = setup(); h.els.regularDescription.value = 'sugar 10 kg'; vm.runInContext('lsOnDescInput()', h.ctx); h.flush(); vm.runInContext('lsReset()', h.ctx); h.pending[0].ok(R('high', [sug('Pantry Material')]));
  ok(h.els.lsBox.classList.contains('hidden') && vm.runInContext('_lsState', h.ctx) === null, 'reset: late response ignored, state cleared'); }
{
  const line = js.split('\n').find(l => l.includes('logLedgerSuggestion')); ok(!!line, 'logging line present in submit success handler');
  const got = []; const ctx = vm.createContext({ isT: false, _lsState: { top: 'Pantry Material', tier: 'high', shown: ['Pantry Material', 'Office Expenses'] }, _lsClicked: 'Pantry Material', fd: { ledger: 'Pantry Material' }, r: { voucherId: '777' }, appToken: 'TOK',
    google: { script: { run: { withFailureHandler() { return this; }, logLedgerSuggestion(...a) { got.push(a); } } } } });
  vm.runInContext(line, ctx); const o = JSON.parse(got[0][1]);
  ok(got.length === 1 && got[0][0] === '777' && got[0][2] === 'TOK' && o.top === 'Pantry Material' && o.chosen === 'Pantry Material' && o.clicked === true && o.tier === 'high', 'outcome payload correct');
  got.length = 0; ctx.isT = true; vm.runInContext(line, ctx); ok(got.length === 0, 'not logged for Transport vouchers');
  ctx.isT = false; ctx._lsState = null; vm.runInContext(line, ctx); ok(got.length === 0, 'not logged when no suggestion was ever requested');
  ctx._lsState = { top: 'A', tier: 'low', shown: [] }; ctx._lsClicked = 'B'; ctx.fd.ledger = 'C'; vm.runInContext(line, ctx); ok(JSON.parse(got[0][1]).clicked === false, 'clicked=false when chosen differs from the chip clicked');
}
console.log(`\nclient harness: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
