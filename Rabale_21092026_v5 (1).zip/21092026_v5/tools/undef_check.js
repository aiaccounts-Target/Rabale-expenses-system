// Every identifier used by the server code must be defined somewhere in the project, apart from Apps Script's own globals.
const fs=require('fs'),path=require('path'),{ESLint}=require('eslint');
(async()=>{ const dir=path.join(__dirname,'..'); const files=fs.readdirSync(dir).filter(f=>/\.gs$/i.test(f)).sort();
  const code=files.map(f=>fs.readFileSync(path.join(dir,f),'utf8')).join('\n;\n');
  const eslint=new ESLint({useEslintrc:false,overrideConfig:{root:true,parserOptions:{ecmaVersion:2022,sourceType:'script'},env:{es2021:true},rules:{'no-undef':'error'}}});
  const [res]=await eslint.lintText(code,{filePath:'all.js'});
  const known=new Set(['CacheService','DriveApp','HtmlService','LockService','Logger','MailApp','PropertiesService','ScriptApp','Session','SpreadsheetApp','UrlFetchApp','Utilities','ContentService','GmailApp','CalendarApp','DocumentApp','Charts','Browser']);
  const undef=[...new Set(res.messages.filter(m=>m.ruleId==='no-undef').map(m=>m.message.match(/'(.+)' is not defined/)[1]))];
  const unknown=undef.filter(n=>!known.has(n)); const fatal=res.messages.filter(m=>m.fatal);
  console.log('   identifiers used but not defined anywhere (excluding Apps Script globals):',unknown.length?unknown:'none', fatal.length?('PARSE PROBLEM '+fatal[0].message):'');
  process.exit(unknown.length||fatal.length?1:0); })();
