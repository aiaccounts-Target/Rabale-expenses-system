const fs = require('fs'), vm = require('vm');
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; } else { fail++; console.log('  FAIL:', m); } };

function makeEnv(opts = {}) {
  const sheets = { 'All Vouchers': [], 'Audit Log': [] };
  let sheetReads = 0;
  const mkSheet = (name) => ({
    getLastRow: () => sheets[name].length + 1,
    getRange: (r, c, nr, nc) => ({
      getValues: () => { if (name === 'All Vouchers') sheetReads++; return sheets[name].slice(r - 2, r - 2 + nr).map(row => { const o = []; for (let i = 0; i < nc; i++) o.push(row[c - 1 + i] === undefined ? '' : row[c - 1 + i]); return o; }); },
    }),
    appendRow: (row) => sheets[name].push(row),
  });
  const store = {};
  const cache = {
    get: (k) => (k in store ? store[k] : null),
    put: (k, v) => { if (Buffer.byteLength(String(v), 'utf8') > 100000) throw new Error('cache value too large'); store[k] = String(v); },
    putAll: (o) => { for (const k in o) cache.put(k, o[k]); },
    getAll: (ks) => { const o = {}; ks.forEach(k => { if (k in store) o[k] = store[k]; }); return o; },
    removeAll: (ks) => ks.forEach(k => delete store[k]),
  };
  const ledgers = opts.ledgers || null;
  const ctx = vm.createContext({
    console, Logger: { log() {} }, JSON, Math, Date,
    CacheService: { getScriptCache: () => cache },
    AV: { VOUCHER_ID: 0, EXPENSE_TYPE: 2, STATUS: 7, NOTES: 14 },
    ALL_VOUCHERS_SHEET: 'All Vouchers', AUDIT_LOG_SHEET: 'Audit Log',
    VEHICLE_REQUIRED_LEDGERS: ['Vehicle Operating - Jakat/Toll', 'Vehicle Fastag', 'Vehicle Operating - Petrol'],
    getSheet_: (n) => mkSheet(n), editorOnly_() {},
    validateSession_: (t) => t === 'T-sub' ? { valid: true, role: 'submission', displayName: 'Tester' } : t === 'T-acc' ? { valid: true, role: 'accounts', displayName: 'Acc' } : { valid: false, role: null },
    getLedgers_: () => { if (opts.ledgersThrow) throw new Error('sheet down'); return ledgers || vm.runInContext('LS_SEED_LEDGERS.concat(["Travelling Expenses"])', ctx); },
    logAction_: (a, v, actor, role, notes) => sheets['Audit Log'].push([new Date().toISOString(), a, v, actor, role, notes, '']),
  });
  for (const f of ['Ledger Seed.gs', 'Ledger Suggest.gs']) vm.runInContext(fs.readFileSync(require('path').join(__dirname, '..', f), 'utf8'), ctx, { filename: f });
  return { ctx, sheets, store, reads: () => sheetReads, call: (src) => vm.runInContext(src, ctx) };
}
const wordOf = (n) => { let s = ''; do { s = String.fromCharCode(97 + n % 26) + s; n = Math.floor(n / 26); } while (n > 0); return 'zz' + s; };
const S = (env, text) => env.call(`suggestLedger('T-sub', ${JSON.stringify(text)})`);
const top = (r) => r.suggestions[0] && r.suggestions[0].ledger;

// 1. core behaviour
{
  const e = makeEnv();
  let r = S(e, 'sugar 10 kg'); ok(r.success && top(r) === 'Pantry Material', 'sugar -> Pantry: ' + top(r));
  r = S(e, 'Airoli toll charges vehicle MH43BX7803'); ok(top(r) === 'Vehicle Operating - Jakat/Toll' && r.suggestions[0].needsVehicle === true, 'toll + needsVehicle');
  r = S(e, 'fasttag recharge for MH 04 MH 4896'); ok(top(r) === 'Vehicle Fastag', 'fastag typo variant: ' + top(r));
  r = S(e, 'tyre puncture and fitting MH 43 BX 7803'); ok(top(r) === 'Repairs & Maintenance - MH43 Bx 7803' && r.suggestions[0].needsVehicle === false, 'plate repair -> vehicle ledger: ' + top(r));
  r = S(e, 'new battery for vehicle MH04LQ4041'); ok(top(r) === 'Repairs & Maintenance -MH04LQ4014', 'one-char-off plate: ' + top(r));
  r = S(e, 'porter charges paid to sandeep dheb'); ok(top(r) === 'Transportation Non - GST', 'names ignored: ' + top(r));
  r = S(e, 'brithday cake for staff'); ok(top(r) === 'Birthday Cake & Chocolates', 'typo tolerant: ' + top(r));
  r = S(e, 'tea for cutting machine mechanic'); ok(top(r) === 'Tea & Coffee', 'tea beats machine name: ' + top(r));
  r = S(e, 'return parcel charges LR no 12345'); ok(r.hint === 'transport', 'transport hint');
  r = S(e, 'ok'); ok(r.success && r.tier === 'none' && r.suggestions.length === 0, 'too short -> none');
  r = S(e, 'chai for mechanic'); ok(top(r) === 'Tea & Coffee', 'hinglish chai: ' + top(r));
  r = S(e, 'मशीन मेकॅनिक साठी चहा'); ok(top(r) === 'Tea & Coffee', 'marathi chaha: ' + top(r));
  r = S(e, 'drinking water jar 10 nos'); ok(top(r) === 'Staff Welfare', 'water jar -> welfare: ' + top(r));
  r = S(e, 'sugar 10 kg'); ok(r.tier === 'high', 'clear case is high tier: ' + r.tier);
  ok(r.suggestions.every(s => typeof s.pct === 'number' && s.why.length <= 70), 'shape of suggestions');
}

// 2. safety: role, session, retired ledger, never-suggest, failure isolation
{
  const e = makeEnv();
  ok(e.call(`suggestLedger('T-acc','sugar 10 kg')`).success === false, 'only submission role');
  ok(e.call(`suggestLedger('bad','sugar 10 kg')`).success === false, 'invalid session refused');
  const e2 = makeEnv({ ledgers: ['Office Expenses', 'Pantry Material', 'Conveyance - Others'] });
  let r = S(e2, 'tea charges for visitors'); ok(r.suggestions.every(s => ['Office Expenses', 'Pantry Material', 'Conveyance - Others'].includes(s.ledger)), 'never suggests a ledger missing from Master Data');
  const e3 = makeEnv();
  r = S(e3, 'travelling charges to thane office'); ok(r.suggestions.every(s => s.ledger !== 'Travelling Expenses'), 'Travelling Expenses never suggested');
  const e4 = makeEnv({ ledgersThrow: true });
  let threw = false, r4; try { r4 = S(e4, 'sugar 10 kg'); } catch (x) { threw = true; }
  ok(!threw && r4.success === false, 'server error is contained (no throw)');
}

// 3. live learning from approved vouchers + cache behaviour
{
  const e = makeEnv();
  const row = (id, type, status, notes) => { const r = new Array(15).fill(''); r[0] = id; r[2] = type; r[7] = status; r[14] = notes; return r; };
  let r = S(e, 'wifi router configuration by vendor'); const before = top(r);
  e.sheets['All Vouchers'].push(row('1', 'Office Expenses', 'Approved', 'wifi router configuration by vendor'));
  e.sheets['All Vouchers'].push(row('2', 'Office Expenses', 'Approved', 'wifi router cable and configuration'));
  e.sheets['All Vouchers'].push(row('3', 'Tea & Coffee', 'Pending L1', 'wifi router pending one'));
  e.sheets['All Vouchers'].push(row('4', 'Transport', 'Approved', 'Vendors: X: Rs.100'));
  e.sheets['All Vouchers'].push(row('5', 'Tea & Coffee', 'Rejected', 'wifi router rejected one'));
  e.call('refreshLedgerLearning()');
  r = S(e, 'wifi router configuration by vendor');
  ok(top(r) === 'Office Expenses', 'learns from approved voucher (before: ' + before + ', after: ' + top(r) + ')');
  ok(r.suggestions.every(s => s.ledger !== 'Transport'), 'Transport vouchers are not examples');
  const reads = e.reads(); S(e, 'wifi router configuration by vendor'); S(e, 'sugar 10 kg');
  ok(e.reads() === reads, 'live examples served from cache (no extra sheet reads)');
  // big pool -> chunked cache, each value <= 100KB (mock throws otherwise)
  const e2 = makeEnv();
  for (let i = 0; i < 2500; i++) e2.sheets['All Vouchers'].push(row(String(i), i % 2 ? 'Office Expenses' : 'Packing Material', 'Approved', 'sample description ' + wordOf(i) + ' ' + 'filler text here '.repeat(6)));
  let r2 = S(e2, 'sugar 10 kg'); ok(r2.success, 'big pool works');
  const n = parseInt(e2.store['ls_live_v1_n'], 10); ok(n >= 2, 'chunked into ' + n + ' parts');
  const e3 = makeEnv();
  for (let i = 0; i < 40; i++) e3.sheets['All Vouchers'].push(row(String(i), 'Pantry Material', 'Approved', '10 kg sugar'));
  S(e3, 'sugar 10 kg'); const kept = JSON.parse(e3.store['ls_live_v1_0']); ok(kept.length === 1 && kept[0].w > 1.4, 'repeated descriptions merged into one heavier example: ' + JSON.stringify(kept));
  const t0 = Date.now(); for (let i = 0; i < 5; i++) S(e2, 'monthly dustbin cleaning'); const ms = (Date.now() - t0) / 5;
  ok(ms < 400, 'response time with ~3,000 examples: ' + ms.toFixed(0) + ' ms');
  console.log('  (avg suggestion time with 2,500 live + seed examples: ' + ms.toFixed(0) + ' ms)');
}

// 3b. Marathi/Hindi descriptions (3 bytes per character) must still cache
{
  const e = makeEnv();
  const row = (id, type, status, notes) => { const r = new Array(15).fill(''); r[0] = id; r[2] = type; r[7] = status; r[14] = notes; return r; };
  const dev = 'अ आ इ ई उ ऊ ए ऐ ओ औ क ख ग घ च छ ज झ ट ठ ड ढ त थ द ध न प फ ब भ म य र ल व श ष स ह'.split(' ');
  for (let i = 0; i < 1500; i++) e.sheets['All Vouchers'].push(row(String(i), 'Office Expenses', 'Approved', 'दुरुस्ती ' + dev[i % 40] + dev[Math.floor(i / 40) % 40] + dev[Math.floor(i / 1600) % 40] + 'x' + dev[Math.floor(i / 40) % 40] + ' ' + 'मशीनसाठी सामान खरेदी '.repeat(5)));
  const r = S(e, 'चहा मेकॅनिक साठी');
  ok(r.success && e.store['ls_live_v1_n'] !== undefined, 'Devanagari-heavy pool is cached (byte-safe chunks)');
  const reads = e.reads(); S(e, 'sugar 10 kg'); ok(e.reads() === reads, 'and served from cache afterwards');
}

// 4. outcome logging + report
{
  const e = makeEnv();
  const o = { top: 'Pantry Material', tier: 'high', chosen: 'Pantry Material', clicked: true, shown: ['Pantry Material', 'Office Expenses'] };
  let r = e.call(`logLedgerSuggestion('101', ${JSON.stringify(JSON.stringify(o))}, 'T-sub')`);
  ok(r.success && e.sheets['Audit Log'].length === 1 && e.sheets['Audit Log'][0][1] === 'LEDGER_SUGGESTION' && /match=Y/.test(e.sheets['Audit Log'][0][5]) && /clicked=Y/.test(e.sheets['Audit Log'][0][5]), 'outcome logged');
  ok(e.call(`logLedgerSuggestion('102','{"top":"A","chosen":"B","tier":"medium","shown":[]}','T-sub')`).success, 'second outcome logged');
  ok(e.call(`logLedgerSuggestion('103','{not json','T-sub')`).success === false, 'malformed json contained');
  ok(e.call(`logLedgerSuggestion('104','{}','bad')`).success === false, 'invalid session not logged');
  // approve voucher 101 with the same ledger, 102 with the suggested one
  const row = (id, type, status) => { const r = new Array(15).fill(''); r[0] = id; r[2] = type; r[7] = status; return r; };
  e.sheets['All Vouchers'].push(row('101', 'Pantry Material', 'Approved'), row('102', 'A', 'Approved'));
  const rep = e.call('ledgerSuggestReport()');
  ok(rep.rows === 2 && rep.top1MatchesChosen === 1 && rep.approved === 2 && rep.chosenMatchesFinal === 1 && rep.top1MatchesFinal === 2 && rep.chipUsed === 1, 'report numbers: ' + JSON.stringify(rep));
}

console.log(`\nengine/endpoint harness: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
