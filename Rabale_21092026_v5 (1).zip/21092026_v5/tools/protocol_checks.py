import re,sys,subprocess,json
from bs4 import BeautifulSoup
html=open(sys.argv[1],encoding='utf-8').read()
soup=BeautifulSoup(html,'html.parser')
ids=[t['id'] for t in soup.find_all(id=True)]
dups=sorted({i for i in ids if ids.count(i)>1})
print('DOM: elements with ids:',len(ids),'| duplicate ids:',dups or 'none')
# tag balance for non-void tags
void={'area','base','br','col','embed','hr','img','input','link','meta','source','track','wbr','path','circle','rect','ellipse','line','polyline','polygon','stop','use'}
stack=[];bad=[]
for m in re.finditer(r'<(/?)([a-zA-Z][a-zA-Z0-9]*)\b([^>]*?)(/?)>',re.sub(r'<script[\s\S]*?</script>|<style[\s\S]*?</style>|<!--[\s\S]*?-->','',html)):
    close,tag,_,selfc=m.groups(); tag=tag.lower()
    if tag in void or selfc: continue
    if not close: stack.append(tag)
    else:
        if stack and stack[-1]==tag: stack.pop()
        else: bad.append(tag)
print('DOM: tag balance -> unclosed:',stack[-3:] or 'none','| stray closers:',bad[:3] or 'none')
# scripts
scripts=re.findall(r'<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)</script>',html)
open('/tmp/client.js','w').write('\n'.join(scripts))
r=subprocess.run(['node','--check','/tmp/client.js'],capture_output=True,text=True)
print('client <script> node --check:', 'OK' if r.returncode==0 else r.stderr[:200])
# el("id") cross-reference
calls=set(re.findall(r'\bel\("([A-Za-z0-9_\-]+)"\)',scripts[0]))
missing=sorted(c for c in calls if c not in ids)
print('el("id") calls:',len(calls),'| ids not present in the rendered page:',missing or 'none')
