# Rabale Petty Expense System - changes since 20092026 (v3), this is v5

## v5 - security hardening (21 Sep 2026)   ** DEPLOY ALL 17 CHANGED FILES TOGETHER **
Files: CHANGED every .gs file except `Ledger Seed.gs`. Internal functions were renamed in most files, so a partial paste
(some files new, some old) fails with "X is not defined". Replace them all, then create ONE new deployment version.
No sheet schema change. No manifest / OAuth scope change (no re-authorization). No financial, voucher, TDS, Tally or RDS logic changed.

### 0. The big one: every internal function was callable from any visitor's browser (found while doing the items below)
In Apps Script every top-level function whose name does not end in "_" can be called through google.script.run by anyone who opens
the web app - the login page does not matter. 190 functions with no session check were exposed, among them `createSessionAndLog`
(creates a valid session for ANY role without a password), `getAdminPin` (returns the Admin PIN), `logAction`, `moveVoucherToStage`,
`markVouchersCashReleased`, `updateVendorLedgerBalance`, `updateRabaleDailySync`, `adminDeleteRdsCashGivenEntry`, `clearAllSessionsFromEditor`,
`bootstrapDefaultUsers`, the migrate* helpers. Passwords, lockouts and the Admin second factor below are pointless while that is open.
Fix (tools/harden.js, parser-based): public now means ONLY (a) the 78 functions the pages really call - each already validates the
session itself, except the 8 that are pre-login by design (login steps, password reset, logout, the email-confirm link); (b) `doGet`;
(c) the 4 scheduled-job entry points (see "Known remaining"); (d) 23 editor-run helpers, which now start with `editorOnly_()` and refuse
anyone who is not pressing Run in the Apps Script editor. The other 172 functions were renamed name -> name_ (1,489 edits, strings and
property names untouched; `getEmailWaveBlob` became `getEmailWaveBlobImpl_` because `getEmailWaveBlob_` already existed).
The Admin-tab "repair scheduled triggers" button still works: it sets TRUSTED_SERVER_CALL_ after verifying an Admin session
(a plain editor-only guard would have broken it; covered by a test).
Proof it changed nothing else: the rendered app page is byte-identical before/after the rename; no identifier became undefined
(ESLint no-undef, same 12 Apps Script built-ins before and after); no string literal names a renamed function; every function the
pages call is still public.

### 1. Session tokens and password salts (finding a)
`generateToken()` and `generateSalt()` used Math.random. Now Utilities.getUuid() (secure random): tokens are 64 hex characters, salts 24.
Existing salts/hashes and live sessions keep working. Nothing depended on the old length or alphabet.

### 2. Admin second factor by email (finding f)
Correct Admin PIN -> a 6-digit code is emailed to the ADMIN_EMAIL Script Property -> the code screen -> session. No session exists after the PIN alone.
Code: stored hashed, single use, 10 min, 5 tries per code; every wrong code also spends the shared Admin lockout budget, and the
counter is cleared only after the FULL login, so requesting fresh codes cannot be used to keep guessing. Resend after 30 s. The one-login rule and the
Admin override still work (the override button appears on the code screen and reuses the verified code).
- ADMIN_EMAIL missing/invalid: the Admin login is REFUSED with a clear message (same fail-loudly rule as ADMIN_PIN). Set it BEFORE deploying.
- Emergency switch, no redeploy: Script Property ADMIN_2FA = off (mail down / quota used up). Each such login is audit-logged.
- New Audit Log actions: ADMIN_2FA_CODE_SENT, ADMIN_2FA_OK, ADMIN_2FA_SEND_FAILED, ADMIN_2FA_NOT_CONFIGURED, ADMIN_2FA_OFF.
- Other roles are unchanged.

### 3. Query-aging reminder at 08:15 (finding h)
Config.gs QUERY_REMINDER_HOUR = 8, QUERY_REMINDER_MINUTE = 15; Triggers.gs uses atHour(8).nearMinute(15). Apps Script cannot fire at an exact minute:
this means "some time between 08:00 and 08:30" in the script time zone. The installed trigger keeps its old time until recreated:
RUN `setupQueryReminderTrigger` ONCE from the editor after deploying (or press the Admin-tab repair button).

### 4. Framing / clickjacking (finding b)
doGet no longer sets XFrameOptionsMode.ALLOWALL, so other sites cannot show the app inside their own page. If the app IS deliberately embedded somewhere
(e.g. a Google Site) and breaks, set Script Property ALLOW_EMBEDDING = yes (exactly "yes") - no redeploy.

### 5. Bill file types (finding g)
Bills must be PDF, JPG, PNG, HEIC or WebP, decided from the file's own first bytes, never from its name or the type the browser claims.
Applies to every path that stores an uploaded bill: Submit Voucher (saveVoucherSubmission), the resubmit paths (resubmitVoucher, resubmitVoucherForQueryScope,
resubmitVoucherAndRespondToQuery), the query reply (respondToQuery, Approval.gs) and the new-vendor request (requestNewVendor, Master.gs).
A program renamed "bill.pdf" is refused; a real PDF called "bill.exe" is stored as "bill.pdf" with the real type; names are stripped of paths/control characters.
The file pickers now list only those types; the on-screen hint says "PDF, JPG, PNG, HEIC or WebP only". Files already stored are not touched.
Size and count limits are unchanged.

### 6. Password hashing (finding c) - deliberately NOT changed
Owner delegated "whatever is safest". Iterating the hash is only safe if a login stays fast enough in Apps Script, which cannot be known without measuring,
so nothing was changed. New editor helper `benchmarkPasswordHash()` measures one digest in your runtime and projects the login time for 1,000 / 10,000 / 100,000 rounds.

### Known remaining (not changed on purpose)
The 4 scheduled-job entry points (`sendQueryAgingReminders`, `sendSameDayQueryReminders`, `sendApproverDigests`, `closeRdsDay`) must stay public for the triggers,
so a visitor can still run them on demand: extra reminder emails / use of the daily mail quota. `closeRdsDay` is documented as idempotent. Closing this needs a
test against the real trigger service (private handler names, or a trigger-id check), which cannot be proven offline.

### Verification run for this release (tools/run_all_checks.sh)
node --check on all 18 files; rendered page identical before/after the rename; DOM: 539 ids, none duplicated, tags balanced; client script parses; 409 el("id")
calls all resolve (vdQuerySlot is the known innerHTML false positive); 254 client functions, none duplicated; no newly-undefined identifiers; every public server
function accounted for; test_v5.js 137 checks (2FA, lockout accounting, override, expiry, resend, mail failure, editor guard, private names, tokens, bill types,
reminder trigger, Admin repair button, framing); client_admin_test.js 33 checks on the real emitted login code; earlier ledger-suggestion harnesses 34 + 25 still pass.
The tests were also run against 10 deliberately broken copies of the code; every one was caught.


## v4.1 - wavy line removed (Main.GS only, CSS only)
The flowing wave under the sidebar brand and under every page title (Submit Voucher etc.) is gone, together with the padding that was
reserved for it (page titles now sit 24px above the content, sidebar brand 20px padding). The login page and the emails keep their own
flowing-line motif - only the two in-app waves were removed. No script, HTML structure or server file changed.

Files: NEW `Ledger Seed.gs`, NEW `Ledger Suggest.gs`, CHANGED `Main.GS`. Every other file is byte-identical to v3.
No sheet schema changes. No manifest / OAuth scope changes (no re-authorization needed). No financial or validation logic touched.

## Ledger suggestion on Submit Voucher (Regular Expense)
As the submitter types the Description, a small box under it proposes up to three ledgers as tappable chips.
- SUGGEST-AND-CONFIRM ONLY. Nothing is ever auto-selected. Tapping a chip fills the Ledger box exactly like picking it by hand (same change
  event, so the Vehicle No. rules run as before). validateVoucherCore, the vehicle rules, TDS, Tally export and RDS sync are unchanged.
- Wording follows confidence: "Suggested ledger" (top chip highlighted) / "Which of these fits best?" / "Not sure - best guesses" + "Ask Accounts".
- Chips for Fastag, Toll and Petrol say "(you will pick the vehicle)". Text that looks like a hired vehicle / LR number / return parcel
  shows a note pointing to the Transport Expense button.
- Any failure (server error, expired session, no suggestion) simply hides the box. Submitting is never affected.
- Only ledgers currently in Master Data column M are ever suggested, so a retired ledger cannot appear.
  "Travelling Expenses", the two plain "Repairs & Maintenance" ledgers and "Repairs & Maintenance - MH43 AD 7803" are never suggested
  (still selectable by hand). Edit LS_NEVER_SUGGEST in Ledger Suggest.gs to change that.

## How it decides (and why it is not static)
1. Nearest-neighbour matching on past descriptions (words, word pairs, letter triples - so typos like "brithday" still match). The closest
   examples vote for their ledger. Explainable: hover a chip to see the past description it resembles.
2. It LEARNS: the example pool = seed (Ledger Seed.gs, built from the Apr 2025-Sep 2026 register, aligned to the Ledger Guide's rulings)
   + phrases per ledger (LS_HINTS) + the descriptions of every APPROVED voucher in All Vouchers (final ledger = what Accounts accepted).
   No retraining step: an approved voucher is simply one more example. Repeats are merged into one heavier example. The live examples are
   cached for 6 hours; run refreshLedgerLearning() from the editor to pick up new approvals immediately.
3. Three narrow rules, only where a vehicle is involved: "fastag" -> Vehicle Fastag; "toll/jakat" -> Vehicle Operating - Jakat/Toll;
   a vehicle number + a repair word (and no goods-moving words) -> that vehicle's repair ledger. A plate typed one character off, or with two
   neighbouring characters swapped, still resolves to the one known vehicle it is closest to (LS_PLATE_LEDGER).
4. Input normaliser (LS_ALIAS): spelling variants, Hinglish (chai, khana, rickshaw...) and common Marathi/Hindi words map onto the English words.
   People's names are ignored (LS_STOP) so "tea for Sandeep sir" is about tea, not Sandeep.

## Measuring it: no separate rollout phase needed
Every new Regular voucher writes one Audit Log row, action LEDGER_SUGGESTION: top suggestion, tier, what was shown, what was chosen, whether a
chip was used. From the Apps Script editor run `ledgerSuggestReport()` (result also goes to the log): agreement of suggestion vs chosen,
chip use, and - for vouchers since approved - suggestion vs the ledger that finally stood, per confidence tier. Use it after 2-3 weeks to decide
whether to tighten or relax LS_HIGH_SHARE / LS_HIGH_SIM.

## Test results (real engine code, time-split: trained only on rows BEFORE the cut, tested on rows AFTER)
| cut date | test rows | right ledger = top pick | in top 3 | "high" tier: share of vouchers / accuracy |
| 2026-03-01 | 1,200 | 88.8% | 95.3% | 66% / 97% |
| 2026-01-01 | 1,363 | 87.0% | 95.2% | 65% / 96% |
Caveat: the test text is Accounts-written narrations. Descriptions typed by warehouse staff will differ, so treat these as an upper bound
until ledgerSuggestReport() shows real numbers. Where the history itself is inconsistent (Food/Welfare, Office/Repairs, Transport/Conveyance)
the misses are mostly there.
Harnesses: 34 server checks (mock GAS: sessions, role, cache chunking incl. Devanagari byte limits, learning from approved vouchers, retired
ledgers, failure isolation, logging, report) and 25 client checks (fake DOM against the real emitted code: debounce, stale responses, chip click,
failure, reset, outcome logging). Verification protocol steps 1-7 all pass; vdQuerySlot remains the known el() false positive.

## Maintenance (all in code, per house convention)
- New ledger in Master Data column M: add 2-4 plain phrases for it to LS_HINTS in Ledger Suggest.gs so it works from day one.
- New vehicle: add its number -> repair ledger to LS_PLATE_LEDGER.
- Ledger guide ruling changes: edit the rulings in the seed builder (tools) and regenerate Ledger Seed.gs, or just let approvals re-teach it.

## Deploy checklist
1. Add two new script files: `Ledger Seed.gs`, `Ledger Suggest.gs`. Replace `Main.gs`.
2. Deploy > Manage deployments > New version (Execute as: User deploying - unchanged).
3. Smoke test as a submission user: type "10 kg sugar" in Description -> Pantry Material chip; "airoli toll" -> Toll chip with the vehicle note.
4. Rollback: delete the two new files and restore v3 Main.gs. (Leaving Main.gs in place without the two files is also safe: the box just stays hidden.)

## Not built, on purpose
- No LLM / external call (keeps everything inside Google, no new scope, no data leaving). Can be added later behind the same suggestLedger().
- No two-step "Repairs of: vehicle / machine" picker: the chips already resolve a vehicle number or machine name to the exact ledger, and the
  picker would have needed a change to the vehicle validation, which needs your explicit sign-off.


---- previous release notes (v3) ----

# Rabale Petty Expense System - changes since 20092026 (v2), this is v3

Files changed: Auth.gs, Config.gs, Email template.gs, Logos.gs, Main.GS, Triggers.gs, Users.gs.
All other files (Advances, Approval, Audit log, Auditor, Master, Notification, Sheet utils, Tally Export, Vouchers) are
byte-identical to v2. No sheet schema changes. No manifest / OAuth scope changes. No financial logic touched.
Two OPTIONAL Script Properties: SUPPORT_CONTACT and FAVICON_URL (see "Deploy checklist"). APP_URL is still required.

## 1. New login page (Main.GS)
- Replaces the old login. One glass card: brand area (real logo, product name, Submit > L1 > Accounts > L2 route) joined to the
  form by a flowing edge; three views on the card: Log in / Forgot password (step 1) / New password (step 2).
- Per-field messages ("Enter your username."), generic wrong-password message, Caps Lock hint, show/hide password,
  "Remember my username" (stores the USERNAME only, in this browser; off by default), password rules ticking live.
- The reset page no longer asks for "Confirm new password" (the show/hide toggle covers typos). The server call is unchanged:
  requestPasswordReset(username), confirmPasswordReset(username, code, newPassword).
- Layout follows the card's own width (container query), not the screen: side by side when wide, stacked when narrow. On a 360x640 phone the
  Log in button is fully above the fold. All new CSS is scoped to #loginPage / .lg-*, so no app style is affected.
- The login help line says "Ask your administrator" or, if Script Property SUPPORT_CONTACT is set, "Contact <that text>".

## 2. Logout confirmation (Main.GS)
- The sidebar Log out button and the Log out button on the "voucher submitted" card now open "Log out?" first.
  Default focus is "Stay logged in"; Esc, a click outside, or Stay cancels; Tab stays inside the dialog.
- doLogout() itself still ends the session at once: it is what runs when the server says the session is gone, and it now shows why.

## 3. One login per account (Auth.gs, Users.gs, Config.gs, Main.GS)
- While an account has a live session, a second login with the CORRECT password is refused ("already logged in ... you can log in again
  in about N minutes"). The check happens only after the password is verified, is not counted as a failed attempt, and a wrong password
  looks exactly like any wrong password, so it cannot be used to see who is online.
- "Live" = seen within SESSION_ACTIVE_WINDOW_SECONDS (150). The page pings touchSession every SESSION_HEARTBEAT_SECONDS (45) and when the tab
  becomes visible; every server call also counts. Nothing seen for 150 s (tab closed, laptop asleep) = abandoned: the next correct login
  takes over and the old page is told "logged in again from somewhere else". Audit Log: LOGIN_BLOCKED_ACTIVE_SESSION, SESSION_REPLACED.
- Check + create run under the script lock, so two simultaneous logins cannot both succeed.
- Applies to Admin as well (the Admin PIN is shared). Set SINGLE_SESSION_APPLIES_TO_ADMIN = false in Config.gs to allow two admins at once,
  or SINGLE_SESSION_ENFORCED = false to switch the whole rule off.
- Manage Users: "Online" / "Idle session" chip, and an "End session" button on EVERY row (adminEndUserSession) that logs that person
  out everywhere at once. Audit Log: SESSION_ENDED_BY_ADMIN.

### Admin overrides (fallbacks if session tracking misbehaves)
- End session works even when the app cannot see the person's session (lost cache entry, a bug). Each account has a revocation counter
  (sepoch_<user>); End session raises it, which kills every older session of that account at its next call, tracked or not, including
  sessions created before this version. A login made afterwards is not affected.
- Manage Users > "Sessions (override tools)": "End all user sessions" (every user; the calling Admin stays in) and "Pause the one-login rule"
  / "Turn it back on" (setSingleSessionEnforced; stored as Script Property SINGLE_SESSION=off, so no redeploy). Setting that property by hand
  in Project Settings does the same. Audit Log: SESSIONS_ENDED_ALL_BY_ADMIN, SESSION_RULE_PAUSED, SESSION_RULE_RESUMED.
- Admin login override: if Admin is refused because another Admin session is active, the login page offers "End the other Admin session and
  log in" (verifyLogin third argument, honoured ONLY for Admin and ONLY after the PIN is verified; the other person is logged out at once).
  Audit Log: ADMIN_SESSION_TAKEOVER. Ordinary users are never offered it.
- clearAllSessionsFromEditor() (Apps Script editor) also revokes untracked sessions. Password reset and deactivation revoke them too.
- A session now also ends at once on: logout, password self-reset, admin password reset, deactivation. (Before, a deactivated user stayed
  logged in until the 1-hour expiry.) The page shows the reason on the login screen.
- clearAllSessionsFromEditor(): run from the Apps Script editor if the Admin login itself is stuck; logs everyone out.
- Refresh / reopened tab: the page validates its stored session immediately and goes back to login with a message if it is gone.
- The hard 1-hour expiry is unchanged (the heartbeat does not extend it).

## 4. Emails (Email template.gs, Triggers.gs, Users.gs, Logos.gs)
- All emails and the "confirm your email address" web page use the new look: logo navy headings and button, soft tinted page, rounded card,
  a flowing-line strip under the logo (inline image cid:wave, with a red lead-in), Work Sans where the mail client has it.
  Colours live in EMAIL_C at the top of Email template.gs.
- Query reminder to Submission: I could NOT reproduce a typed-out version in this code: the same-day reminder already used the shared template
  (HTML + logo). If you still receive plain text, look for a stale trigger or an old copy of the function (Apps Script > Triggers).
  Hardening so it cannot happen: sendBrandedEmail_ (the only place that calls MailApp) lays out plain text in the same template when no
  HTML is supplied; notifyRole (the one old plain-text sender, unused) now goes through the template; a template bug now falls back to the
  branded layout instead of bare text.
- The same-day query reminder is now one email per Submission user, greeted by name and position (like the approver digest). Fixed
  "1 query was raised ... still need" grammar in the plain-text part.
- If the wave image cannot be built the header simply has no strip (no broken image).

## 5. App-wide design (Main.GS)
- Palette tokens retargeted to the logo: navy #2E3192 (was #3B5BA5), deep navy, tinted greys, logo red #ED1C24 as a small accent only
  (active sidebar marker, the target bullseye). 125 hard-coded colours (old blue and leftover teal) mapped onto the same palette.
- Font stays Work Sans (weight 800 added for headings) with IBM Plex Mono for figures; tabular numerals on amounts.
- Accessibility: input borders raised from about 1.3:1 to 3.7:1 contrast; muted text from 3.1:1 to 5.6:1 (4.97:1 on the tinted page);
  visible keyboard focus ring on every control.
- Sidebar: translucent, red active marker, flowing-line divider under the brand; page titles get the same divider. Cards and modals use the
  new rounding and shadow; modal backdrops are softly blurred. On narrow screens the sidebar footer icons now stack instead of spilling out.
- Browser-tab icon: the T mark, through HtmlOutput.setFaviconUrl inside try/catch (never blocks the page).

## Assumptions that need sign-off
1. One login per account applies to Admin too, with a 150 s "abandoned" window, and the price is: someone who closes the tab without logging
   out waits up to about 2.5 minutes (an admin can end it sooner).
2. Password reset and deactivation end live sessions.
3. "Remember my username" stores the username in the browser; leave it off on shared computers.
4. The route strip on the login card (Submit > L1 > Accounts > L2) is drawn from the approval chain; confirm it is right for every voucher type.
5. Confirm-password was dropped from the reset page.

## Known limits
- Session tracking lives in CacheService, which is best-effort: if Google evicts an entry, the rule fails OPEN (someone can log in twice),
  it never locks anyone out.
- Sessions that were already logged in when this is deployed are not tracked: for up to an hour after deploy an already-logged-in account could
  still be logged in a second time. Run clearAllSessionsFromEditor() right after deploying to start everyone fresh.
- A second browser TAB has its own session storage, so opening the app in a new tab shows the login page and is refused while the first tab is
  in use. Duplicating a tab shares the session, which is fine.
- Mail clients rarely have Work Sans; they show their Arial-class fallback. Gmail/Outlook ignore web fonts.
- setFaviconUrl with an embedded image is untested against real Apps Script; if it is rejected the tab icon simply stays default (set
  FAVICON_URL to a hosted https image to be sure).

## Verification run before delivery
node --check on all 16 .gs; getAppHTML() in a vm sandbox; DOM duplicate-ID (519 ids) and tag balance (22 tag types); rendered script node --check;
el() cross-reference (only the known vdQuerySlot false positive); duplicate function names (345 gs / 247 browser);
mock-GAS tests: 35 (sessions: block, heartbeat, takeover, admin end, logout, reset, deactivate, expiry, flags),
36 (admin overrides: lost-pointer revocation, legacy sessions, end-all, Admin takeover, pause/resume, editor fallback),
24 (emails: branded query reminders per recipient, no unstyled send, template bug fallback, escaping, every builder themed),
12 (doGet/favicon, SUPPORT_CONTACT escaping, digest, unchanged files byte-identical, CRLF kept);
headless-Chromium tests against the rendered app with a stubbed server: 48 (login states, reset flow, logout confirmation incl. keyboard,
forced logout, remembered username, admin Manage Users incl. Sessions card and Admin override, layouts at 1440 / 390 / 360x640).
NOT tested: real Google Sheets / CacheService / LockService / MailApp, real email delivery and mail clients, Safari and Firefox, a live deployment.

## Deploy checklist
1. Paste the 7 changed files into the Apps Script editor (Main.GS and Logos.gs are large). Save. Deploy a NEW VERSION (Execute as: User deploying, unchanged).
2. Optional Script Properties: SUPPORT_CONTACT (e.g. "Meena Rao, ext. 214"), FAVICON_URL (https image).
3. Run clearAllSessionsFromEditor() once (see Known limits), then Admin > Manage Users > Reinstall Scheduled Reminders.
4. Apps Script > Triggers: delete any trigger whose function is not one of sendQueryAgingReminders, sendSameDayQueryReminders,
   sendApproverDigests, closeRdsDay (a stale one is the likely source of a typed-out reminder).
5. Run previewQueryReminderEmailsToMe and previewApproverDigestsToMe and look at the emails; check on a phone too.
6. Log in as a test user in two browsers: the second must be refused; close the first tab without logging out and confirm the second works after ~2.5 minutes;
   as Admin press End session and confirm the first page returns to login with the reason. Also try "End all user sessions",
   "Pause the one-login rule" (then turn it back on), and the Admin override (log in as Admin in two browsers).
7. Press Log out and confirm you are asked; try Forgot password end to end with a user that has a verified email.


---

# Earlier notes (v2, unchanged)

# Rabale Petty Expense System - changes since 19092026 (v2)

Files changed: Auth.gs, Approval.gs, Config.gs, Notification.gs, Users.gs, Main.GS. All other files are byte-identical.
No sheet schema changes. No manifest/scope changes (uses MailApp already authorised).
**One Script Property is now REQUIRED: APP_URL = the web app's /exec URL** (see "Email confirmation").

## Email confirmation without sharing a code (new in v2)
- Admin sets/changes a user's email (Manage Users) as before. The NEW address is emailed a "Review this request" link to a
  page: "Should this email address be linked to <name (position)>?  [Yes, this is my email address] [No, this is not right]".
  Only Yes writes USR.EMAIL. No (or doing nothing for 24h) discards the change; No is logged so the admin can see the address was wrong.
  The admin never sees or handles a code. The old "Verify Email" prompt is gone; a pending row shows
  "Waiting for <address> to confirm (22h left)" with Resend Email and Cancel Pending.
- Opening the link only DISPLAYS the question (doGet route ?verifyEmail=<token>); it changes nothing, so mail scanners that open
  every link cannot confirm anything. Only the Yes button (google.script.run) writes.
- Token: "<userId>.<60 hex>" = 240 random bits, stored only as a salted hash in the existing Pending Email OTP Hash/Salt columns,
  single use, 24h expiry, format checked before any sheet is read. Resend or a different address invalidates the earlier link.
- The email is sent BEFORE anything is stored (send-before-write). If APP_URL is missing (or only a /dev URL is available)
  the admin gets a clear error and nothing is written or sent.
- The confirm page uses default framing (not ALLOWALL), writes all data with textContent, and embeds the token only if it
  matches the exact format.
- Audit Log actions: USER_EMAIL_VERIFY_SENT / _VERIFIED / _VERIFY_REJECTED / _VERIFY_EXPIRED / _VERIFY_CANCELLED
  (replace the old USER_EMAIL_OTP_* names; old rows stay readable).
- Removed: verifyUserEmailOtp, generateOtp, otpVerificationText_/Html_.
- Any change still pending from the old flow at deploy time is simply invalid; the admin presses Set/Edit Email again.

## Password reset (items 2, 3, 4)
- Login page: "Forgot password?" link. On a lockout the login page also shows a "Locked out?" box:
  reset with an emailed code, or ask the administrator.
- Auth.gs: requestPasswordReset(username), confirmPasswordReset(username, code, newPassword) - callable without a session.
  Code: 6 digits from Utilities.getUuid(), sent ONLY to the verified USR.EMAIL, salted hash in CacheService,
  10-minute expiry, single use. Email is sent before anything is stored.
  Request answers are identical for unknown / inactive / no-email / auditor / admin / throttled accounts.
  Limits: 30s cool-down, 5 requests/user/hour, 40/hour script-wide, keeps the last 20 daily emails for approvals.
  Wrong codes: 5 attempts then a 15-minute lock and the code is discarded.
  Success clears that user's login lockout and emails them a notice. Audit Log: PASSWORD_RESET_OTP_SENT / _SKIPPED /
  _FAILED / _THROTTLED, PASSWORD_RESET_LOCKED, USER_PASSWORD_SELF_RESET.
- verifyLogin lockout responses now carry locked:true and selfReset (true for the 4 working roles, false for Admin).
- Not eligible (contact an administrator): Admin, Auditor, accounts with no verified email, deactivated accounts.

## Submitter sidebar and duplicate button (items 5, 6)
- Removed "+ Submit New Voucher" from the Dashboard and My Vouchers page heads. Sidebar "Submit Voucher" remains.
- New sidebar pages for the submission role: Recent Submissions, Cash Advances (record form, open balances, daily log,
  ledger - same element IDs as before, just moved off the dashboard). L1/Accounts/L2/Auditor keep their own read-only Cash Advances page.

## Submission dashboard (item 7)
- 5 stat boxes kept. New: Cash in hand vs advances outstanding (pie), advances by person (pie, top 5 + Others),
  Needs your attention (open queries + rejected), My vouchers by stage, Advances open the longest,
  Advances given vs vouchers filed - last 7 days.
- Approval.gs: getSubmissionDashboardSummary now also returns stages / attention / attentionCount and up to 25 recent
  vouchers; new getSubmissionCashPosition (read-only, latest RDS Cash in Hand, falls back to previous month tab).
- Fixed: first stat box "N open" counted people with a settled advance too.

## Assumptions that need sign-off
1. "Advances" = open balance (given minus non-rejected vouchers), same as the first stat box. Shown side by side with
   Cash in Hand, NOT subtracted (RDS treats Actual = Cash in Hand - Advance, so advances are part of cash in hand).
2. The submission role can now see the RDS Cash in Hand balance.
3. Admin and Auditor cannot self-reset their password.

## Known limits
- A reset does not end sessions that are already logged in (they expire after 1 hour). Same as the admin reset.
- The confirm link works for whoever holds it (that is the point: the mailbox is the proof). The email says not to forward it.
- If the web app is ever made private, the person clicking the link must be signed in to a Google account that can open it
  (a company account). Personal addresses could not confirm.
- generateToken() (pre-existing) uses Math.random; the new reset code and confirmation token do not.

## Verification run before delivery
node --check on all .gs; getAppHTML() in a vm sandbox; DOM duplicate-ID and tag balance; script node --check;
el() cross-reference (only the known vdQuerySlot false positive); duplicate function names;
mock-GAS tests: 29 (password reset), 24 (email confirmation, incl. doGet routing); mock-sheet tests: 13 (dashboard data);
jsdom tests: 22 (login/reset/sidebar/dashboard), 16 (confirm page + admin users screen).
NOT tested: real Google Sheets/MailApp/CacheService, real email delivery and link scanners, and a live deployment.

## Deploy checklist
1. Project Settings > Script Properties: set APP_URL to the deployed web app's /exec URL (https). Required for the confirmation link.
2. Paste the 6 changed files into the Apps Script editor (Main.GS is the large one). Save. Deploy a NEW VERSION of the web app
   (Execute as: User deploying - unchanged; access can stay "Anyone").
3. Admin > Manage Users > Set Email for a test user using an address you control. Open the email, press the button, press Yes,
   and confirm the Email column updates. Repeat with No, and with Resend Email (the first link should then stop working).
4. Give a test user a verified email, try Forgot password; lock them out with 5 wrong passwords and confirm the "Locked out?" box.
5. Open the submitter dashboard; confirm the Cash in Hand pie (needs RDS_SHEET_ID, as already set).
