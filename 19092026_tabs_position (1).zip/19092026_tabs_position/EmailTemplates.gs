// ============================================================================
// SHARED EMAIL TEMPLATE — one branded look for every email the system sends.
//
// First used by the approver daily digest and the two query reminders
// (Triggers.gs). Every other email in the system (cash-withdrawal request /
// decision, vendor and employee requests, account notices, OTP) can move
// onto this with a few lines each: build the pieces below, pass them to
// buildBrandedEmail_, send with sendBrandedEmail_. Nothing here reads or
// writes any sheet; it only turns already-computed values into HTML.
//
// Design rules, each one learned from a real rendering problem:
//   - Fluid width: 100% of the mail window up to 820px, so it neither leaves
//     a narrow card in a wide window nor overflows a phone.
//   - Identifier / date / amount columns never wrap (white-space:nowrap), so
//     "V-TKZD9BSZO" is never split across two lines. Free-text columns (names,
//     cost centres, query details) wrap normally and set the row height.
//   - Long details go on their own full-width line under the row instead of
//     squeezing a narrow column.
//   - On narrow screens columns marked hideSmall disappear and cell padding
//     shrinks (CSS media query; supported by Gmail web/app and Apple Mail).
//     Keep the always-visible columns short (id, amount, age): on a 390px
//     phone there is room for about four of them. Anything long belongs in
//     the full-width detail line, not in a column.
//   - Free text passes through emailNoAutoLink_, because Gmail turns text like
//     "11 Rabale" (a number followed by a place name) into a Google Maps link.
//   - Everything user-supplied is HTML-escaped. Only the builders in this file
//     produce markup.
// ============================================================================

function emailEsc_(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// emailPlural_(3, 'voucher') -> '3 vouchers'; irregular plurals are passed
// explicitly: emailPlural_(3, 'query', 'queries') -> '3 queries'.
function emailPlural_(count, word, pluralWord) {
  return count + ' ' + (count === 1 ? word : (pluralWord || word + 's'));
}

function emailMoney_(n) {
  var v = Math.round((Number(n) || 0) * 100) / 100;
  try { return v.toLocaleString('en-IN', { minimumFractionDigits: (v % 1 === 0 ? 0 : 2), maximumFractionDigits: 2 }); } catch (e) { return String(v); }
}

// "25-7-2026" -> "25-07-2026". Anything that is not a d-m-yyyy / d/m/yyyy
// string is returned untouched rather than guessed at.
function emailDate_(raw) {
  var m = /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/.exec(String(raw || '').trim());
  if (!m) return String(raw || '');
  return ('0' + m[1]).slice(-2) + '-' + ('0' + m[2]).slice(-2) + '-' + m[3];
}

// Escapes free text AND stops Gmail / Apple Mail from auto-linking it as a
// street address: each word gets its own <span> and a zero-width space
// follows each gap, so no contiguous "11 Rabale" text node exists to detect.
// Looks identical on screen; wraps exactly like normal text.
function emailNoAutoLink_(s) {
  var words = String(s === null || s === undefined ? '' : s).split(/\s+/).filter(function (w) { return w; });
  return words.map(function (w) { return '<span>' + emailEsc_(w) + '</span>'; }).join(' &#8203;');
}

// The logo attachment for cid:logo, or null if it cannot be built (callers
// then fall back to a text header; the email is never blocked by a logo).
function getEmailLogoBlob_() {
  try { return getLogoFullEmailBlob(); } catch (e) { Logger.log('getEmailLogoBlob_: logo unavailable: ' + e); return null; }
}

// columns: [{label, align:'left'|'right', nowrap:bool, hideSmall:bool, mono:bool}]
// rows:    [{cells:[html | {h:html, s:extraStyle, c:className}], detail:html|''}]
// Every cell / detail is HTML that the caller has already escaped.
function emailTable_(columns, rows) {
  var thBase = 'padding:9px 12px;font-size:11px;letter-spacing:.04em;text-transform:uppercase;color:#5B6270;background:#F4F6F9;border-bottom:1px solid #DFE3EA;font-weight:bold;';
  var h = ['<table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="width:100%;border-collapse:separate;border-spacing:0;border:1px solid #DFE3EA;border-radius:6px;"><tr>'];
  columns.forEach(function (c) {
    var al = c.align || 'left';
    h.push('<th' + (c.hideSmall ? ' class="hs"' : '') + ' align="' + al + '" style="' + thBase + 'text-align:' + al + ';' + (c.nowrap ? 'white-space:nowrap;' : '') + '">' + emailEsc_(c.label) + '</th>');
  });
  h.push('</tr>');
  rows.forEach(function (r) {
    var hasDetail = !!r.detail;
    h.push('<tr>');
    r.cells.forEach(function (cell, i) {
      var col = columns[i];
      var al = col.align || 'left';
      var o = (typeof cell === 'string') ? { h: cell } : cell;
      var cls = [o.c || '', col.hideSmall ? 'hs' : ''].join(' ').replace(/^\s+|\s+$/g, '');
      h.push('<td' + (cls ? ' class="' + cls + '"' : '') + ' align="' + al + '" valign="top" style="padding:' + (hasDetail ? '10px 12px 3px' : '10px 12px') +
        ';font-size:13px;line-height:1.4;color:#1D2330;text-align:' + al + ';' + (hasDetail ? '' : 'border-bottom:1px solid #EAEDF2;') +
        (col.nowrap ? 'white-space:nowrap;' : '') + (col.mono ? 'font-family:Consolas,Menlo,monospace;' : '') + (o.s || '') + '">' + o.h + '</td>');
    });
    h.push('</tr>');
    if (hasDetail) {
      h.push('<tr><td colspan="' + columns.length + '" style="padding:0 12px 10px;font-size:12.5px;line-height:1.4;color:#5B6270;border-bottom:1px solid #EAEDF2;">' + r.detail + '</td></tr>');
    }
  });
  h.push('</table>');
  return h.join('');
}

// kind: 'warn' | 'ok' | 'danger' | 'info'
function emailNotice_(kind, html) {
  var c = {
    warn:   ['#FBF0DE', '#EBCF97', '#8A5A17'],
    ok:     ['#E6F4ED', '#B9DEC9', '#1F5B45'],
    danger: ['#FBEAE9', '#E7BAB8', '#8B3330'],
    info:   ['#EAEFF9', '#C7D2EC', '#2C4680']
  }[kind] || ['#EAEFF9', '#C7D2EC', '#2C4680'];
  return '<div style="padding:10px 12px;background:' + c[0] + ';border:1px solid ' + c[1] + ';border-radius:6px;font-size:12.5px;line-height:1.45;color:' + c[2] + ';">' + html + '</div>';
}

// Label / value pairs (values already escaped) for request-style emails.
function emailKeyValues_(pairs) {
  var h = ['<table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="width:100%;border:1px solid #DFE3EA;border-radius:6px;border-collapse:separate;border-spacing:0;">'];
  pairs.forEach(function (p, i) {
    var last = i === pairs.length - 1;
    h.push('<tr><td valign="top" style="padding:8px 12px;width:32%;font-size:12.5px;font-weight:bold;color:#5B6270;background:#F4F6F9;' + (last ? '' : 'border-bottom:1px solid #EAEDF2;') + '">' + emailEsc_(p[0]) +
      '</td><td valign="top" style="padding:8px 12px;font-size:13px;color:#1D2330;' + (last ? '' : 'border-bottom:1px solid #EAEDF2;') + '">' + p[1] + '</td></tr>');
  });
  h.push('</table>');
  return h.join('');
}

// Highlighted headline figure, e.g. the total of a withdrawal request.
function emailTotalBox_(label, valueText) {
  return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%;background:#EAEFF9;border:1px solid #C7D2EC;border-radius:8px;"><tr>' +
    '<td style="padding:14px 18px;font-size:13px;font-weight:bold;color:#2C4680;">' + emailEsc_(label) + '</td>' +
    '<td align="right" style="padding:14px 18px;font-family:Consolas,Menlo,monospace;font-size:22px;font-weight:bold;color:#2C4680;white-space:nowrap;">' + emailEsc_(valueText) + '</td></tr></table>';
}

// A one-time code shown large and centred (verification emails). The spacing
// between digits is CSS letter-spacing only, so copy-paste gives the bare code.
function emailCodeBox_(label, code) {
  return '<div style="text-align:center;padding:18px 12px;background:#EAEFF9;border:1px solid #C7D2EC;border-radius:8px;">' +
    '<div style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;font-weight:bold;color:#5B6270;">' + emailEsc_(label) + '</div>' +
    '<div style="margin-top:8px;font-family:Consolas,Menlo,monospace;font-size:32px;line-height:1.1;font-weight:bold;letter-spacing:8px;color:#2C4680;">' + emailEsc_(code) + '</div></div>';
}

// Plain text -> escaped paragraphs (blank line = new paragraph, newline = <br>).
function emailParagraph_(text) {
  return '<p style="margin:0;font-size:14px;line-height:1.55;color:#1D2330;">' + emailEsc_(text).replace(/\r?\n/g, '<br>') + '</p>';
}

// o: {title, subtitle, preheader, blocks:[html], ctaLabel, ctaUrl, footer, hasLogo}
// ctaUrl is only rendered when it is an https URL.
function buildBrandedEmail_(o) {
  var h = [];
  h.push('<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no"><meta name="x-apple-disable-message-reformatting">' +
    '<style>@media only screen and (max-width:600px){.hs{display:none!important}.px{padding-left:16px!important;padding-right:16px!important}.wrap{padding:8px!important}.wrap th,.wrap td{padding-left:8px!important;padding-right:8px!important}}</style></head>');
  h.push('<body style="margin:0;padding:0;background:#F4F6F9;">');
  if (o.preheader) h.push('<div style="display:none;max-height:0;overflow:hidden;opacity:0;font-size:1px;line-height:1px;">' + emailEsc_(o.preheader) + '</div>');
  h.push('<div class="wrap" style="background:#F4F6F9;padding:24px 12px;font-family:Arial,Helvetica,sans-serif;">');
  h.push('<div style="width:100%;max-width:820px;margin:0 auto;background:#FFFFFF;border:1px solid #DFE3EA;border-radius:10px;overflow:hidden;">');
  h.push('<div class="px" style="padding:22px 28px 14px;border-bottom:1px solid #EAEDF2;">' + (o.hasLogo
    ? '<img src="cid:logo" alt="Target Learning Ventures Pvt. Ltd." width="280" style="display:block;width:280px;max-width:100%;height:auto;border:0;">'
    : '<div style="font-size:16px;font-weight:bold;color:#2E3192;">Target Learning Ventures Pvt. Ltd.</div>') + '</div>');
  h.push('<div class="px" style="padding:20px 28px 4px;"><div style="font-size:18px;font-weight:bold;color:#1D2330;">' + emailEsc_(o.title) + '</div>' +
    (o.subtitle ? '<div style="font-size:13px;color:#5B6270;margin-top:4px;">' + emailNoAutoLink_(o.subtitle) + '</div>' : '') + '</div>');
  (o.blocks || []).forEach(function (b) { if (b) h.push('<div class="px" style="padding:12px 28px 0;">' + b + '</div>'); });
  if (o.ctaUrl && /^https:\/\//i.test(o.ctaUrl)) {
    h.push('<div class="px" style="padding:20px 28px 6px;"><a href="' + emailEsc_(o.ctaUrl) + '" style="display:inline-block;background:#3B5BA5;color:#FFFFFF;text-decoration:none;font-weight:bold;font-size:14px;padding:10px 20px;border-radius:6px;">' +
      emailEsc_(o.ctaLabel || 'Open the app') + '</a></div>');
  }
  h.push('<div class="px" style="padding:18px 28px 22px;font-size:11.5px;color:#8A93A3;">' + emailEsc_(o.footer || 'Sent automatically by the Rabale Petty Expense System.') + '</div>');
  h.push('</div></div></body></html>');
  return h.join('');
}

// One message. Throws on failure (callers decide what a failure means).
// o: {to, cc, subject, body, htmlBody, logo (Blob|null), name}
function sendBrandedEmail_(o) {
  var opts = { to: o.to, subject: o.subject, body: o.body, name: o.name || 'Rabale Petty Expense System' };
  if (o.htmlBody) opts.htmlBody = o.htmlBody;
  if (o.cc) opts.cc = o.cc;
  if (o.logo) opts.inlineImages = { logo: o.logo };
  if (o.attachments && o.attachments.length) opts.attachments = o.attachments;
  MailApp.sendEmail(opts);
}

// The safe way to send any system notification. buildHtml(hasLogo) returns
// the HTML body. If building it throws for ANY reason, the plain-text
// version is sent instead: a bug in a template must never be able to stop a
// withdrawal request, a lock-out notice or a vendor request from going out.
// Send failures still throw, exactly as a bare MailApp.sendEmail would, so
// every caller's existing error handling keeps working unchanged.
// o: {to, cc, subject, body (plain text), attachments}
function sendNotification_(o, buildHtml) {
  var logo = getEmailLogoBlob_();
  var html = null;
  try { html = buildHtml(!!logo); } catch (buildErr) { Logger.log('sendNotification_: HTML build failed, sending plain text instead: ' + buildErr); }
  sendBrandedEmail_({ to: o.to, cc: o.cc, subject: o.subject, body: o.body, htmlBody: html, logo: html ? logo : null, attachments: o.attachments });
}

// One email per active user in a role (same semantics as notifyRole in
// Users.gs: nobody sees a colleague's address, one bad address cannot stop
// the rest). Returns the number actually sent.
function notifyRoleBranded_(role, subject, plainBody, htmlBody, logo) {
  var emails = getActiveUserEmailsForRole(role);
  if (emails.length === 0) {
    Logger.log('notifyRoleBranded_: no active user with an email configured for role "' + role + '" \u2014 skipped: ' + subject);
    return 0;
  }
  var sent = 0;
  emails.forEach(function (email) {
    try {
      sendBrandedEmail_({ to: email, subject: subject, body: plainBody, htmlBody: htmlBody, logo: logo });
      sent++;
    } catch (mailErr) {
      Logger.log('notifyRoleBranded_: failed to email ' + email + ': ' + mailErr);
    }
  });
  return sent;
}
