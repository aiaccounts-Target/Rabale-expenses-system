// ============================================================================
// AUTH — login, sessions, logout
// ============================================================================
// REVISED (Day 5): 'admin' still logs in with a single shared PIN (sourced
// from Script Properties now, not hardcoded — see getAdminPin() in
// Config.gs). The 4 MULTI_USER_ROLES (submission, L1, accounts, L2) now
// log in with an individual username + password (Users sheet, see
// Users.gs) instead of one shared PIN per role — so the Audit Log can
// attribute actions to a real person, not just a role. Permissions are
// UNCHANGED: they are still keyed on role only, so anyone active in a
// given role can act on any voucher at that stage (deliberate — covers
// for someone being out).
//
// Brute-force lockout is now keyed by IDENTITY, not role: for admin,
// that's still the role itself ('admin'); for the 4 multi-user roles,
// it's the typed username, so one person's mistyped password can't lock
// out their whole team, and a lockout can't be used to fingerprint which
// usernames are valid (the counter increments under the typed username
// whether or not that username actually exists).

function generateToken() {
  var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var token = '';
  for (var i = 0; i < 40; i++) token += chars.charAt(Math.floor(Math.random() * chars.length));
  return token;
}

function isLocked(identityKey) {
  return !!CacheService.getScriptCache().get('lock_' + identityKey);
}

function registerFailedAttempt(identityKey) {
  var cache = CacheService.getScriptCache();
  var attKey = 'att_' + identityKey;
  var attempts = parseInt(cache.get(attKey) || '0') + 1;
  if (attempts >= MAX_LOGIN_ATTEMPTS) {
    cache.put('lock_' + identityKey, '1', LOCKOUT_SECONDS);
    cache.remove(attKey);
    return { locked: true, attemptsLeft: 0 };
  }
  cache.put(attKey, String(attempts), LOCKOUT_SECONDS);
  return { locked: false, attemptsLeft: MAX_LOGIN_ATTEMPTS - attempts };
}

function clearFailedAttempts(identityKey) {
  var cache = CacheService.getScriptCache();
  cache.remove('att_' + identityKey);
}

// Admin-specific counterpart to registerFailedAttempt() above — kept as a
// near-duplicate rather than a shared/parameterized function so that
// registerFailedAttempt()'s signature and thresholds stay exactly as they
// are for the 4 multi-user roles. Uses ADMIN_MAX_LOGIN_ATTEMPTS /
// ADMIN_LOCKOUT_SECONDS (Config.gs) instead of MAX_LOGIN_ATTEMPTS /
// LOCKOUT_SECONDS. isLocked() and clearFailedAttempts() above are
// identity-key-generic and already work unchanged for the 'admin' key.
function registerAdminFailedAttempt(identityKey) {
  var cache = CacheService.getScriptCache();
  var attKey = 'att_' + identityKey;
  var attempts = parseInt(cache.get(attKey) || '0') + 1;
  if (attempts >= ADMIN_MAX_LOGIN_ATTEMPTS) {
    cache.put('lock_' + identityKey, '1', ADMIN_LOCKOUT_SECONDS);
    cache.remove(attKey);
    return { locked: true, attemptsLeft: 0 };
  }
  cache.put(attKey, String(attempts), ADMIN_LOCKOUT_SECONDS);
  return { locked: false, attemptsLeft: ADMIN_MAX_LOGIN_ATTEMPTS - attempts };
}

function createSessionAndLog(role, userId, displayName) {
  var token = generateToken();
  CacheService.getScriptCache().put(
    'sess_' + token,
    JSON.stringify({ role: role, userId: userId, displayName: displayName, expires: Date.now() + SESSION_EXPIRY_SECONDS * 1000 }),
    SESSION_EXPIRY_SECONDS
  );
  logAction('LOGIN', '', displayName, role, 'Logged in');
  return token;
}

// REVISED — role dropdown removed from the login page per explicit
// instruction. Role is now inferred purely from WHICH identity the
// username resolves to: the reserved ADMIN_USERNAME constant for Admin,
// or whatever role is stored against that username in the Users sheet
// for everyone else. This works safely because usernames are already
// enforced globally unique at creation time (createUser/seedDefaultUsers,
// via findUserByUsername) — there was never a legitimate case where the
// same username needed a role picker to disambiguate; the old
// `storedRole === role` check this replaces was really only rejecting a
// mismatched dropdown selection, not adding real security.
function verifyLogin(username, secret) {
  try {
    if (!username || !secret) return { success: false, error: 'All fields are required.' };

    var enteredUsername = String(username || '').trim();

    if (enteredUsername.toLowerCase() === ADMIN_USERNAME.toLowerCase()) {
      // Admin now has its own lockout — a documented risk-acceptance
      // trade-off (unlimited PIN guesses) has been reconsidered now that
      // every other role has account-level lockout. Keyed on the literal
      // string 'admin' (not the typed username) since Admin is one shared
      // identity, unlike the other 4 roles where the identity key is the
      // person's own username. Threshold is higher and the window shorter
      // than the multi-user roles (ADMIN_MAX_LOGIN_ATTEMPTS /
      // ADMIN_LOCKOUT_SECONDS, Config.gs) via a separate
      // registerAdminFailedAttempt(), not the shared registerFailedAttempt()
      // (which hardcodes MAX_LOGIN_ATTEMPTS/LOCKOUT_SECONDS internally).
      if (isLocked('admin')) return { success: false, error: 'This account is locked. Try again in 5 minutes.' };

      var correctPin = getAdminPin();
      var pinOk = String(secret).trim() === String(correctPin).trim();
      if (!pinOk) {
        logAction('LOGIN_FAILED', '', enteredUsername, 'admin', 'Incorrect admin PIN');
        var adminAttResult = registerAdminFailedAttempt('admin');
        if (adminAttResult.locked) {
          logAction('LOGIN_LOCKED', '', enteredUsername, 'admin', 'Too many failed attempts');
          return { success: false, error: 'Account locked. Too many incorrect attempts. Try again in 5 minutes.' };
        }
        return { success: false, error: 'Incorrect username or password.' };
      }
      clearFailedAttempts('admin');
      var token = createSessionAndLog('admin', 'admin', 'Admin');
      return { success: true, token: token, role: 'admin', displayName: 'Admin' };
    }

    // Lockout key stays lowercased (rate-limiting bucket, not an identity
    // match) — deliberately so, otherwise typing a wrong-case variant of
    // a real username would count against a SEPARATE lockout counter,
    // giving an attacker unlimited attempts by just cycling case. Login
    // matching itself (findUserByUsername below) is now case-sensitive;
    // this key is only about not letting case-cycling reset the clock.
    var uKey = enteredUsername.toLowerCase();
    if (isLocked(uKey)) return { success: false, error: 'This account is locked. Try again in 15 minutes.' };

    var found = findUserByUsername(enteredUsername, true);
    var valid = false;
    var storedRole = null;
    if (found) {
      storedRole = safe(found.rowValues[USR.ROLE]);
      var active = safe(found.rowValues[USR.ACTIVE]) === 'Yes';
      var storedHash = safe(found.rowValues[USR.PASSWORD_HASH]);
      var storedSalt = safe(found.rowValues[USR.SALT]);
      if (MULTI_USER_ROLES.indexOf(storedRole) !== -1 && active && verifyPassword(secret, storedSalt, storedHash)) {
        valid = true;
      }
    }

    if (!valid) {
      // Deliberately generic — never reveals whether the username exists,
      // whether the account is inactive, or the password is wrong; all
      // three look identical from outside, and all three still count
      // against the lockout.
      var attResult = registerFailedAttempt(uKey);
      if (attResult.locked) {
        logAction('LOGIN_LOCKED', '', enteredUsername, storedRole || 'unknown', 'Too many failed attempts');
        // ADDED (item 15): only notify when the typed username actually
        // matched a real account (`found` truthy) — a nonexistent username
        // can still trip this same lockout key (see the comment above uKey)
        // and there is nobody to email in that case.
        if (found) {
          notifyUserOfAccountEvent(found.rowValues, 'USER_LOCKED_OUT',
            'Rabale Petty Expense System \u2014 your account has been locked',
            'Hello ' + safe(found.rowValues[USR.DISPLAY_NAME]) + ',\n\nYour account on the Rabale Petty Expense System has been locked ' +
            'after too many incorrect password attempts. It will automatically unlock in 15 minutes, or an administrator can unlock it sooner.\n\n' +
            'If this wasn\u2019t you, please let your administrator know.');
        }
        return { success: false, error: 'Account locked. Too many incorrect attempts. Try again in 15 minutes.' };
      }
      return { success: false, error: 'Incorrect username or password. ' + attResult.attemptsLeft + ' attempt(s) remaining.' };
    }

    clearFailedAttempts(uKey);
    try { found.sheet.getRange(found.rowIndex, USR.LAST_LOGIN + 1).setValue(new Date().toLocaleString('en-IN')); } catch (e) { /* non-blocking */ }

    var displayName = safe(found.rowValues[USR.DISPLAY_NAME]);
    var userId = safe(found.rowValues[USR.USER_ID]);
    var sessToken = createSessionAndLog(storedRole, userId, displayName);
    return { success: true, token: sessToken, role: storedRole, displayName: displayName };
  } catch (err) {
    Logger.log('verifyLogin error: ' + err);
    return { success: false, error: 'Authentication error. Please try again.' };
  }
}

function validateSession(token) {
  if (!token) return { valid: false, role: null };
  try {
    var raw = CacheService.getScriptCache().get('sess_' + token);
    if (!raw) return { valid: false, role: null };
    var s = JSON.parse(raw);
    if (!s.role) return { valid: false, role: null };
    if (Date.now() > s.expires) { CacheService.getScriptCache().remove('sess_' + token); return { valid: false, role: null }; }
    return { valid: true, role: s.role, userId: s.userId || null, displayName: s.displayName || s.role };
  } catch (e) { return { valid: false, role: null }; }
}

function logout(token) {
  try {
    if (token) {
      var raw = CacheService.getScriptCache().get('sess_' + token);
      if (raw) {
        try {
          var s = JSON.parse(raw);
          if (s.role) logAction('LOGOUT', '', s.displayName || s.role, s.role, 'Logged out');
        } catch (e) {}
      }
      CacheService.getScriptCache().remove('sess_' + token);
    }
  } catch (e) {}
  return { success: true };
}