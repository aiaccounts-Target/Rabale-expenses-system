// ============================================================================
// AUDIT LOG
// ============================================================================
// Unchanged from v8.2.

function logAction(action, voucherId, actor, role, notes) {
  try {
    var s = getSheet(AUDIT_LOG_SHEET);
    if (!s) {
      Logger.log('WARNING: Audit log sheet "' + AUDIT_LOG_SHEET + '" not found. Event not logged: ' + action);
      return;
    }
    s.appendRow([new Date().toLocaleString('en-IN'), action, voucherId || '', actor || '', role || '', notes || '']);
  } catch (e) {
    Logger.log('CRITICAL: logAction failed: ' + e);
  }
}

// ADDED (bugfix round, #10) — records when a bill file is opened, from
// the voucher detail modal. Fire-and-forget from the client (no
// withSuccessHandler awaited before the file opens \u2014 see viewDetail,
// Main.gs), so this never delays or blocks the actual file open. No
// permission narrowing beyond a valid session: every role that can view
// a voucher's bills can already see who's viewing them in the Audit Log.
function logBillViewed(voucherId, fileLabel, token) {
  try {
    var session = validateSession(token);
    if (!session.valid || !session.role) return { success: false };
    logAction('BILL_VIEWED', voucherId, session.displayName || session.role, session.role, fileLabel || '');
    return { success: true };
  } catch (err) {
    Logger.log('logBillViewed error: ' + err);
    return { success: false };
  }
}