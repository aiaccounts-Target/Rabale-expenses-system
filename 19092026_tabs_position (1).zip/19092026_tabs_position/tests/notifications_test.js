const fs=require('fs'),vm=require('vm'),path=require('path');
const D=path.join(__dirname,'..');
let pass=0,fail=0;
function ok(c,m){if(c){pass++}else{fail++;console.log('FAIL:',m)}}
const FILES=['Config.gs','Sheet Utlis.gs','Logos.gs','EmailTemplates.gs','Notifications.gs','Users.gs','Master data.gs','Approval.gs'];

function makeEnv(o){
  o=o||{};
  const events=[],mails=[],logs=[],audit=[];
  const props=Object.assign({},o.props||{});
  const ctx={
    Logger:{log:m=>logs.push(String(m))},
    Session:{getScriptTimeZone:()=> 'Asia/Kolkata',getEffectiveUser:()=>({getEmail:()=> 'deployer@target.test'})},
    PropertiesService:{getScriptProperties:()=>({getProperty:k=>props[k]===undefined?null:props[k]})},
    Utilities:{formatDate:d=>('0'+d.getDate()).slice(-2)+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+d.getFullYear(),
      base64Decode:s=>{if(o.badLogo)throw new Error('decode fail');return Array.from(Buffer.from(s,'base64'))},
      newBlob:(bytes,mime,name)=>({bytes,mime,name})},
    MailApp:{sendEmail:x=>{events.push('send');if(o.mailFails)throw new Error('quota or address problem');mails.push(x)},
      getRemainingDailyQuota:()=>o.quota===undefined?90:o.quota},
    ScriptApp:{getService:()=>({getUrl:()=> 'https://script.google.com/macros/s/TEST/dev'})},
    LockService:{getScriptLock:()=>({waitLock(){},releaseLock(){}})},
    CacheService:{getScriptCache:()=>({get(){return null},put(){},remove(){}})},
    console};
  vm.createContext(ctx);
  for(const f of FILES)vm.runInContext(fs.readFileSync(path.join(D,f),'utf8'),ctx,{filename:f});
  ctx.logAction=(a,v,who,role,n)=>audit.push({a,v,who,role,n});
  ctx.getActiveUserEmailsForRole=r=>(o.recipients||{})[r]||[];
  ctx.validateSession=()=>o.session||{valid:true,role:'admin',displayName:'Admin User'};
  return {ctx,events,mails,logs,audit,props};
}
// ---- fake sheet that records the order of writes relative to sends
function fakeSheet(env,rows){
  const data=rows;
  return {data,writes:[],
    getDataRange:()=>({getValues:()=>data.map(r=>r.slice())}),
    getRange:(r,c)=>({setValue:v=>{env.events.push('write');data[r-1][c-1]=v}}),
    appendRow:row=>{env.events.push('write');data.push(row)}};
}
const boot=makeEnv({});const C=boot.ctx;const WB=C.WB,AV=C.AV,USR=C.USR;
const html=m=>m.htmlBody||'';

// =============================================================== golden plain text
// The original bodies, copied from the code before this change. Plain text
// must be identical apart from the two deliberate wording fixes.
function origVendorBody(name,by,date,notes){return 'A new vendor has been requested for the Rabale Petty Expense System.\n\n'+'Vendor name: '+name+'\n'+'Requested by: '+by+'\n'+'Date: '+date+'\n'+(notes?'\nNotes: '+notes+'\n':'')+'\nThe vendor\u2019s bill is attached. Please review and add the vendor (with TDS applicability and rate) via the Admin > Vendors panel.'}
for(const notes of ['','Bill attached, GST registered']){
  const got=C.vendorRequestText_({vendorName:'Arco Transport',requestedBy:'Suresh Patil',dateText:'19/9/2026, 10:00:00 am',notes});
  ok(got===origVendorBody('Arco Transport','Suresh Patil','19/9/2026, 10:00:00 am',notes).replace('Admin > Vendors panel','Admin > Vendor Addition tab'),'vendor plain text identical to before except the corrected tab name (notes='+notes+')');
}
function origEmployeeBody(name,by,date,notes,sheet){return 'A new employee has been requested, to be added to the Submitted By list in the Rabale Petty Expense System.\n\n'+'Employee name: '+name+'\n'+'Requested by: '+by+'\n'+'Date: '+date+'\n'+(notes?'\nNotes: '+notes+'\n':'')+'\nTo add: open the "'+sheet+'" sheet and type the name in column A, in the first empty row directly under the last employee '+'(leave no blank rows between names \u2014 the list stops reading at the first blank). It shows up in Submitted By the next time Submit Voucher is opened.'}
for(const notes of ['','New joiner, Rabale plant']){
  ok(C.employeeRequestText_({employeeName:'Anil Rao',requestedBy:'Suresh Patil',dateText:'19-09-2026',notes,sheetName:'Master Data'})===origEmployeeBody('Anil Rao','Suresh Patil','19-09-2026',notes,'Master Data'),'employee plain text identical to the previous version (notes='+notes+')');
}
const reqO={withdrawalId:'WD-1',batchIds:['B-2026-09-15','B-2026-09-16'],periodFrom:'15-09-2026',periodTo:'16-09-2026',voucherCount:12,totalAmount:53619,missingVoucherIds:[]};
function origReqBody(o,replyLine){const l=['Accounts is requesting approval to withdraw cash from the bank to replenish the petty cash float.','','Withdrawal ID: '+o.withdrawalId,'Batch(es): '+o.batchIds.join(', '),'Period: '+o.periodFrom+' to '+o.periodTo,'Voucher count: '+o.voucherCount,'Total amount: Rs. '+o.totalAmount.toLocaleString('en-IN'),'','The attached Excel sheet is the full Rabale Daily Sync detail (through Cash in Hand) for exactly these vouchers.','',replyLine];
  if(o.missingVoucherIds.length)l.push('','Note: '+o.missingVoucherIds.length+' voucher(s) could not be matched in Rabale Daily Sync and are excluded from this request (excluded from both the total above and the attachment): '+o.missingVoucherIds.join(', ')+'. These remain eligible for a future request.');return l.join('\n')}
const newReply=C.withdrawalRequestActionText_();
ok(C.withdrawalRequestText_(reqO)===origReqBody(reqO,newReply),'request plain text: identical to before except the one decision-instruction line');
const reqM=Object.assign({},reqO,{missingVoucherIds:['V9','V8']});
ok(C.withdrawalRequestText_(reqM)===origReqBody(reqM,newReply),'request plain text with excluded vouchers identical to before');
ok(/approve or reject this request in the app/.test(newReply)&&/Cash Withdrawal Approval \(Bank Replenishment\)/.test(newReply)&&/reply to this email and Admin will record/.test(newReply),'instruction points to the real in-app panel name and keeps the reply fallback');
function origDecBody(o){const l=['Cash withdrawal request '+o.withdrawalId+' has been '+(o.approved?'APPROVED':'REJECTED')+'.','','Decision: '+o.decision,'Decided by: '+o.decidedBy+' ('+o.decidedByRole+')','Decided on: '+o.decidedOn,'','Withdrawal ID: '+o.withdrawalId,'Batch(es): '+o.batchIds,'Period: '+o.periodFrom+' to '+o.periodTo,'Voucher count: '+o.voucherCount,'Total amount: Rs. '+o.totalAmount.toLocaleString('en-IN')];
  if(o.notes)l.push('','Notes: '+o.notes);l.push('',o.approved?'Accounts can now withdraw the cash and release it against these vouchers in the app.':'No cash is to be released against these vouchers. Every voucher in this request is unbundled again and can be included in a corrected request.');return l.join('\n')}
for(const approved of [true,false])for(const notes of ['','Bank holiday, resend Monday']){
  const o={withdrawalId:'WD-1',decision:approved?'Approved':'Rejected',approved,decidedBy:'Rajesh Mehta',decidedByRole:'L2',decidedOn:'19/9/2026, 9:15:00 am',batchIds:'B-2026-09-15, B-2026-09-16',periodFrom:'15-09-2026',periodTo:'16-09-2026',voucherCount:12,totalAmount:53619,notes};
  ok(C.withdrawalDecisionText_(o)===origDecBody(o),'decision plain text identical to before (approved='+approved+', notes='+!!notes+')');
}

// =============================================================== HTML content
let h=C.withdrawalRequestHtml_(reqM,'https://script.google.com/macros/s/PROD/exec',true);
ok(/Rs\. 53,619/.test(h)&&/Cash withdrawal approval required/.test(h)&&/B-2026-09-15, B-2026-09-16/.test(h),'request html: total, title, batches');
ok(/href="https:\/\/script\.google\.com\/macros\/s\/PROD\/exec"/.test(h)&&/Open the Approval Queue/.test(h)&&/cid:logo/.test(h),'request html: /exec button and logo');
ok(/could not be matched/.test(h)&&/V9, V8/.test(h),'request html: excluded vouchers shown as a warning');
ok(!/could not be matched/.test(C.withdrawalRequestHtml_(reqO,'',false)),'request html: no warning when nothing excluded');
ok(!/href=/.test(C.withdrawalRequestHtml_(reqO,'',false))&&!/cid:logo/.test(C.withdrawalRequestHtml_(reqO,'',false)),'request html: no link and no logo when unavailable');
const decO=id=>({withdrawalId:id,decision:'Rejected',approved:false,decidedBy:'<b>Raj</b>',decidedByRole:'Admin, on L2\u2019s behalf',decidedOn:'now',batchIds:'B-1',periodFrom:'a',periodTo:'b',voucherCount:1,totalAmount:100,notes:'<script>alert(1)</script>'});
h=C.withdrawalDecisionHtml_(decO('WD-9'),'',false);
ok(!/<script>|<b>Raj<\/b>/.test(h)&&/&lt;script&gt;/.test(h)&&/&lt;b&gt;Raj/.test(h),'decision html: notes and names escaped');
ok(/rejected/i.test(h)&&/#FBEAE9/.test(h),'decision html: rejection uses the red notice');
ok(/#E6F4ED/.test(C.withdrawalDecisionHtml_(Object.assign(decO('W'),{approved:true,decision:'Approved',notes:''}),'',false)),'decision html: approval uses the green notice');
h=C.vendorRequestHtml_({vendorName:'<i>Evil</i> Co',requestedBy:'11 Rabale Team',dateText:'d',notes:'n & m'},'https://x.test/exec',false);
ok(!/<i>Evil/.test(h)&&/&lt;i&gt;Evil/.test(h)&&/n &amp; m/.test(h)&&/Vendor Addition/.test(h),'vendor html: escaped, points at Vendor Addition');
ok(!h.includes('11 Rabale Team')&&h.includes('<span>11</span>'),'vendor html: requester name cannot auto-link as an address');
h=C.employeeRequestHtml_({employeeName:'Anil Rao',requestedBy:'S',dateText:'d',notes:'',sheetName:'Master Data'},'https://docs.google.com/spreadsheets/d/X/edit#gid=5',false);
ok(/Open the Master Data sheet/.test(h)&&/#gid=5/.test(h)&&/column A/.test(h),'employee html: sheet button and instructions');
ok(!/href=/.test(C.employeeRequestHtml_({employeeName:'A',requestedBy:'S',dateText:'d',notes:'',sheetName:'Master Data'},'',false)),'employee html: no button when sheet link unavailable');

// =============================================================== sendNotification_
let E=makeEnv({});
E.ctx.sendNotification_({to:'a@t.test',cc:'c@t.test',subject:'S',body:'plain',attachments:[{n:1}]},hasLogo=>'<p>html '+hasLogo+'</p>');
let m=E.mails[0];
ok(m.htmlBody==='<p>html true</p>'&&m.body==='plain'&&m.cc==='c@t.test'&&m.attachments.length===1&&m.inlineImages&&m.inlineImages.logo,'sendNotification_: html + logo + cc + attachments all passed');
E=makeEnv({});E.ctx.sendNotification_({to:'a@t.test',subject:'S',body:'plain'},()=>{throw new Error('template bug')});
m=E.mails[0];ok(E.mails.length===1&&m.body==='plain'&&!('htmlBody' in m)&&!('inlineImages' in m),'sendNotification_: a throwing template still sends the plain text');
ok(E.logs.some(x=>/HTML build failed/.test(x)),'sendNotification_: the fallback is logged');
E=makeEnv({mailFails:true});let threw=false;try{E.ctx.sendNotification_({to:'a@t.test',subject:'S',body:'p'},()=>'<p/>')}catch(e){threw=true}
ok(threw,'sendNotification_: a real send failure still throws (callers keep their error handling)');
E=makeEnv({badLogo:true});E.ctx.sendNotification_({to:'a@t.test',subject:'S',body:'p'},hasLogo=>'<p>'+hasLogo+'</p>');
ok(E.mails[0].htmlBody==='<p>false</p>'&&!E.mails[0].inlineImages,'sendNotification_: logo failure => html without logo, mail still sent');

// =============================================================== decide flow (real code, mocked sheets)
function decideEnv(o){
  o=o||{};
  const env=makeEnv({recipients:{accounts:['acc1@t.test','acc2@t.test'],L2:['l2@t.test']},session:o.session||{valid:true,role:'L2',displayName:'Rajesh Mehta'},mailFails:o.mailFails,quota:o.quota,badLogo:o.badLogo});
  const c=env.ctx;
  const wbRow=new Array(20).fill('');
  wbRow[WB.WITHDRAWAL_ID]='WD-77';wbRow[WB.STATUS]=o.status||c.WITHDRAWAL_STATUS_PENDING;wbRow[WB.TOTAL_AMOUNT]=53619;wbRow[WB.PERIOD_FROM]='15-09-2026';wbRow[WB.PERIOD_TO]='16-09-2026';
  wbRow[WB.BATCH_IDS]='B-2026-09-15, B-2026-09-16';wbRow[WB.VOUCHER_COUNT]=12;
  if(o.storedSubject!==null)wbRow[WB.EMAIL_SUBJECT]=o.storedSubject||'Cash Withdrawal Approval Required \u2014 Rs. 53,619 (15-09-2026 to 16-09-2026)';
  if(o.decidedBy){wbRow[WB.DECIDED_BY]=o.decidedBy;wbRow[WB.DECIDED_DATE]='18-09-2026'}
  const wb=fakeSheet(env,[['hdr'],wbRow]);
  const avRow=id=>{const r=new Array(30).fill('');r[AV.VOUCHER_ID]=id;r[AV.WITHDRAWAL_BATCH_ID]=id.startsWith('V')?'WD-77':'';return r};
  const av=fakeSheet(env,[['hdr'],avRow('V1'),avRow('V2'),avRow('X3')]);
  c.getOrCreateCashWithdrawalBatchesSheet=()=>wb;
  const origGetSheet=c.getSheet;c.getSheet=n=>n===c.ALL_VOUCHERS_SHEET?av:origGetSheet(n);
  if(o.htmlThrows)c.withdrawalDecisionHtml_=()=>{throw new Error('boom')};
  return {env,c,wb,av};
}
let T=decideEnv();
let r=T.c.decideCashWithdrawalBatch('WD-77','Approved','',  'tok');
m=T.env.mails[0];
ok(r.success===true,'decide/approve: success '+JSON.stringify(r).slice(0,120));
ok(T.env.mails.length===1&&m.subject==='Re: Cash Withdrawal Approval Required \u2014 Rs. 53,619 (15-09-2026 to 16-09-2026)','decide: subject is exactly "Re: " + the stored request subject (threading preserved): '+m.subject);
ok(m.to==='acc1@t.test,acc2@t.test'&&m.cc==='l2@t.test','decide: to Accounts, cc L2 unchanged');
ok(/has been APPROVED\./.test(m.body)&&/Decided by: Rajesh Mehta \(L2\)/.test(m.body)&&/Total amount: Rs\. 53,619/.test(m.body),'decide: plain body intact');
ok(/Cash withdrawal request approved/.test(m.htmlBody)&&m.inlineImages&&/#E6F4ED/.test(m.htmlBody),'decide: branded html with logo');
ok(T.env.events[0]==='send'&&T.env.events.slice(1).every(e=>e==='write'),'decide: SEND happens before ANY sheet write (send-before-write preserved)');
ok(T.wb.data[1][WB.STATUS]==='Approved'&&T.wb.data[1][WB.DECIDED_VIA]===T.c.WITHDRAWAL_DECIDED_VIA_APP,'decide: status Approved, decided via app');
// rejection: notes + unbundling
T=decideEnv();r=T.c.decideCashWithdrawalBatch('WD-77','Rejected','Bank holiday, resend Monday','tok');m=T.env.mails[0];
ok(r.success&&/Notes: Bank holiday/.test(m.body)&&/Bank holiday, resend Monday/.test(m.htmlBody)&&/#FBEAE9/.test(m.htmlBody),'decide/reject: notes shown, red styling');
ok(T.av.data[1][AV.WITHDRAWAL_BATCH_ID]===''&&T.av.data[2][AV.WITHDRAWAL_BATCH_ID]===''&&/2 voucher/.test(r.message),'decide/reject: vouchers still unbundled exactly as before');
// admin on behalf
T=decideEnv({session:{valid:true,role:'admin',displayName:'Admin User'}});T.c.decideCashWithdrawalBatch('WD-77','Approved','','tok');
ok(/Decided by: Admin User \(Admin, on L2\u2019s behalf\)/.test(T.env.mails[0].body)&&T.wb.data[1][WB.DECIDED_VIA]===T.c.WITHDRAWAL_DECIDED_VIA_ADMIN,'decide/admin: on-behalf wording and decided-via unchanged');
// legacy row with no stored subject
T=decideEnv({storedSubject:null});T.c.decideCashWithdrawalBatch('WD-77','Approved','','tok');
ok(T.env.mails[0].subject==='Re: '+T.c.withdrawalRequestSubject_(53619,'15-09-2026','16-09-2026'),'decide/legacy row: subject rebuilt identically');
// send failure: nothing written, request left pending
T=decideEnv({mailFails:true});r=T.c.decideCashWithdrawalBatch('WD-77','Approved','','tok');
ok(r.success===false&&!T.env.events.includes('write')&&T.wb.data[1][WB.STATUS]==='Pending L2 Approval'&&T.env.audit.some(a=>a.a==='CASH_WITHDRAWAL_DECISION_SEND_FAILED'),'decide/send failure: NO writes, still Pending, failure audited (unchanged)');
// template bug: mail still goes as plain text, decision still recorded
T=decideEnv({htmlThrows:true});r=T.c.decideCashWithdrawalBatch('WD-77','Approved','','tok');
ok(r.success===true&&T.env.mails.length===1&&!('htmlBody' in T.env.mails[0])&&/has been APPROVED/.test(T.env.mails[0].body)&&T.wb.data[1][WB.STATUS]==='Approved','decide/template bug: plain-text email sent, decision recorded normally');
// already decided: no mail, no writes
T=decideEnv({status:'Approved',decidedBy:'Rajesh Mehta'});r=T.c.decideCashWithdrawalBatch('WD-77','Approved','','tok');
ok(r.alreadyDecided&&T.env.mails.length===0&&!T.env.events.includes('write'),'decide/already decided: no second email, nothing changed');
// quota exhausted
T=decideEnv({quota:0});r=T.c.decideCashWithdrawalBatch('WD-77','Approved','','tok');
ok(r.success===false&&/quota/.test(r.error)&&T.env.mails.length===0,'decide/quota exhausted: clear error, nothing sent');

// =============================================================== request flow (real code, mocked sheets/extract)
function requestEnv(o){
  o=o||{};
  const env=makeEnv({recipients:{accounts:['acc1@t.test'],L2:['l2a@t.test','l2b@t.test']},session:{valid:true,role:'accounts',displayName:'Accounts User'},mailFails:o.mailFails,quota:o.quota,props:{APP_URL:'https://script.google.com/macros/s/PROD/exec'}});
  const c=env.ctx;
  c.computeWithdrawalBatchEligibility=()=>[{batchId:'B-2026-09-15',selectable:true,eligibleVoucherIds:['V1','V2'],eligibleAmount:3000},{batchId:'B-2026-09-16',selectable:true,eligibleVoucherIds:['V3'],eligibleAmount:2000.5}];
  const blob={name:'WD.xlsx',id:'blob'};
  c.buildCashWithdrawalExtractXlsx=()=>({blob,url:'https://docs.test/x',missingVoucherIds:o.missing||[]});
  c.findVoucherRow=id=>({rowValues:(()=>{const r=new Array(30).fill('');r[AV.AMOUNT]=o.missingAmount||0;return r})()});
  const avRow=id=>{const r=new Array(30).fill('');r[AV.VOUCHER_ID]=id;return r};
  const av=fakeSheet(env,[['hdr'],avRow('V1'),avRow('V2'),avRow('V3')]);
  const wb=fakeSheet(env,[['hdr']]);
  c.getOrCreateCashWithdrawalBatchesSheet=()=>wb;
  const og=c.getSheet;c.getSheet=n=>n===c.ALL_VOUCHERS_SHEET?av:og(n);
  if(o.htmlThrows)c.withdrawalRequestHtml_=()=>{throw new Error('boom')};
  return {env,c,av,wb,blob};
}
let Q=requestEnv();
r=Q.c.triggerCashWithdrawalRequest(JSON.stringify(['B-2026-09-15','B-2026-09-16']),'tok');m=Q.env.mails[0];
ok(r.success===true&&Q.env.mails.length===1,'request: success '+JSON.stringify(r).slice(0,140));
ok(m.to==='l2a@t.test,l2b@t.test'&&m.cc==='acc1@t.test','request: to L2, cc Accounts unchanged');
ok(m.subject===Q.c.withdrawalRequestSubject_(5000.5,'15-09-2026','16-09-2026')&&/^Cash Withdrawal Approval Required/.test(m.subject),'request: subject unchanged: '+m.subject);
ok(m.attachments&&m.attachments.length===1&&m.attachments[0]===Q.blob,'request: the Excel attachment is still attached');
ok(/Total amount: Rs\. 5,000\.5/.test(m.body)&&/approve or reject this request in the app/.test(m.body)&&!/Please reply to this email to approve/.test(m.body),'request: plain body has the corrected instruction');
ok(/Rs\. 5,000\.50/.test(m.htmlBody)&&/href="https:\/\/script\.google\.com\/macros\/s\/PROD\/exec"/.test(m.htmlBody)&&m.inlineImages,'request: branded html, /exec link, logo');
ok(Q.env.events[0]==='send'&&Q.env.events.slice(1).every(e=>e==='write'),'request: SEND before any write (send-before-write preserved)');
ok(Q.av.data[1][AV.WITHDRAWAL_BATCH_ID]===r.withdrawalId&&Q.wb.data[1][WB.EMAIL_SUBJECT]===m.subject&&Q.wb.data[1][WB.STATUS]===Q.c.WITHDRAWAL_STATUS_PENDING,'request: vouchers tagged, request row stores the exact subject used (needed for threading)');
// excluded vouchers
Q=requestEnv({missing:['V3'],missingAmount:2000.5});r=Q.c.triggerCashWithdrawalRequest(JSON.stringify(['B-2026-09-15','B-2026-09-16']),'tok');m=Q.env.mails[0];
ok(/Note: 1 voucher\(s\) could not be matched/.test(m.body)&&/could not be matched/.test(m.htmlBody)&&/Rs\. 3,000/.test(m.htmlBody),'request/excluded voucher: total reduced, warning in both versions');
// send failure
Q=requestEnv({mailFails:true});r=Q.c.triggerCashWithdrawalRequest(JSON.stringify(['B-2026-09-15']),'tok');
ok(r.success===false&&!Q.env.events.includes('write')&&Q.env.audit.some(a=>a.a==='CASH_WITHDRAWAL_SEND_FAILED'),'request/send failure: nothing tagged or recorded, failure audited (unchanged)');
// template bug
Q=requestEnv({htmlThrows:true});r=Q.c.triggerCashWithdrawalRequest(JSON.stringify(['B-2026-09-15']),'tok');m=Q.env.mails[0];
ok(r.success===true&&Q.env.mails.length===1&&!('htmlBody' in m)&&m.attachments.length===1&&/Total amount: Rs\./.test(m.body),'request/template bug: plain-text email + attachment still sent, request recorded');
Q=requestEnv({quota:0});r=Q.c.triggerCashWithdrawalRequest(JSON.stringify(['B-2026-09-15']),'tok');
ok(r.success===false&&/quota/.test(r.error)&&Q.env.mails.length===0,'request/quota exhausted: clear error, nothing sent');

// =============================================================== vendor + employee (real code)
function sub(o){o=o||{};const env=makeEnv({recipients:{},session:{valid:true,role:'submission',displayName:'Suresh Patil'},mailFails:o.mailFails,props:Object.assign({VENDOR_REQUEST_EMAIL:'vendors@t.test',EMPLOYEE_REQUEST_EMAIL:'hr@t.test,hr2@t.test',APP_URL:'https://script.google.com/macros/s/PROD/exec'},o.props||{})});
  env.ctx.getVendorsWithTDS=()=>({});env.ctx.getEmployees=()=>['Existing Person'];
  env.ctx.getSheet=n=>({getParent:()=>({getUrl:()=> 'https://docs.google.com/spreadsheets/d/SHEET'}),getSheetId:()=>4242});
  if(o.htmlThrows){env.ctx.vendorRequestHtml_=env.ctx.employeeRequestHtml_=()=>{throw new Error('boom')}}
  return env}
let S=sub();const file=JSON.stringify({data:Buffer.from('%PDF-bill').toString('base64'),mimeType:'application/pdf',name:'bill.pdf'});
r=S.ctx.requestNewVendor('Arco Transport',file,'GST registered','tok');m=S.mails[0];
ok(r.success&&m.to==='vendors@t.test'&&m.subject==='New Vendor Request: Arco Transport','vendor: sent to configured address, subject unchanged');
ok(m.attachments.length===1&&m.attachments[0].name==='bill.pdf'&&m.attachments[0].bytes.length>0,'vendor: bill still attached');
ok(/Vendor Addition/.test(m.body)&&/Vendor Addition/.test(m.htmlBody)&&/New vendor request/.test(m.htmlBody)&&m.inlineImages,'vendor: plain + branded html, corrected tab name');
S=sub({htmlThrows:true});r=S.ctx.requestNewVendor('Arco Transport',file,'','tok');
ok(r.success&&S.mails.length===1&&!('htmlBody' in S.mails[0])&&S.mails[0].attachments.length===1,'vendor/template bug: plain text + attachment still sent');
S=sub({mailFails:true});r=S.ctx.requestNewVendor('Arco Transport',file,'','tok');ok(r.success===false&&/Failed to send the vendor request email/.test(r.error),'vendor/send failure: same error as before');
S=sub();r=S.ctx.requestNewEmployee('Anil Rao','New joiner','tok');m=S.mails[0];
ok(r.success&&m.to==='hr@t.test,hr2@t.test'&&m.subject==='New Employee Request: Anil Rao','employee: comma-separated recipients and subject unchanged');
ok(/Open the Master Data sheet/.test(m.htmlBody)&&/#gid=4242/.test(m.htmlBody)&&/column A/.test(m.body),'employee: deep link to the Master Data tab + instructions');
S=sub();S.ctx.getSheet=()=>{throw new Error('no sheet')};r=S.ctx.requestNewEmployee('Anil Rao','','tok');
ok(r.success&&S.mails.length===1&&!/Open the Master Data sheet/.test(S.mails[0].htmlBody),'employee: unresolvable sheet link => no button, email still sent');
S=sub({htmlThrows:true});r=S.ctx.requestNewEmployee('Anil Rao','','tok');ok(r.success&&!('htmlBody' in S.mails[0]),'employee/template bug: plain text still sent');
S=sub({props:{EMPLOYEE_REQUEST_EMAIL:''}});r=S.ctx.requestNewEmployee('Anil Rao','','tok');ok(r.success===false&&/not configured/.test(r.error),'employee: unset recipient still reported as before');

// =============================================================== account notices (real code)
const NAME='Meena Rao';
const EVENTS={
 USER_LOCKED_OUT:['Rabale Petty Expense System \u2014 your account has been locked','Hello '+NAME+',\n\nYour account on the Rabale Petty Expense System has been locked after too many incorrect password attempts. It will automatically unlock in 15 minutes, or an administrator can unlock it sooner.\n\nIf this wasn\u2019t you, please let your administrator know.'],
 USER_UNLOCKED:['Rabale Petty Expense System \u2014 your account has been unlocked','Hello '+NAME+',\n\nYour account on the Rabale Petty Expense System has been unlocked by an administrator. You can log in again now.'],
 USER_DEACTIVATE:['Rabale Petty Expense System \u2014 your account has been deactivated','Hello '+NAME+',\n\nYour account on the Rabale Petty Expense System has been deactivated by an administrator. You will not be able to log in until it is reactivated.\n\nIf you believe this is a mistake, please contact your administrator.'],
 USER_PASSWORD_RESET:['Rabale Petty Expense System \u2014 your password was reset','Hello '+NAME+',\n\nYour password on the Rabale Petty Expense System was just reset by an administrator. If you did not expect this, please contact your administrator immediately.'],
 USER_PASSWORD_CHANGE:['Rabale Petty Expense System \u2014 your password was changed','Hello '+NAME+',\n\nYour password on the Rabale Petty Expense System was just changed. If you did not make this change, please contact your administrator immediately.']};
const userRow=(role,email)=>{const r=new Array(20).fill('');r[USR.ROLE]=role;r[USR.EMAIL]=email;r[USR.DISPLAY_NAME]=NAME;return r};
for(const [ev,[subject,body]] of Object.entries(EVENTS)){
  const A=makeEnv({props:{APP_URL:'https://script.google.com/macros/s/PROD/exec'}});
  A.ctx.notifyUserOfAccountEvent(userRow('submission','meena@t.test'),ev,subject,body);
  const x=A.mails[0];
  ok(A.mails.length===1&&x.to==='meena@t.test'&&x.subject===subject&&x.body===body,ev+': recipient, subject and plain-text body unchanged');
  ok(/<span>account<\/span> &#8203;<span>notice<\/span>/.test(x.htmlBody)&&x.htmlBody.includes(NAME)&&/>When</.test(x.htmlBody),ev+': branded html with account + time');
  const hasLink=/href="https:\/\/script\.google\.com/.test(x.htmlBody);
  ok(hasLink===(ev==='USER_UNLOCKED'),ev+': login link '+(ev==='USER_UNLOCKED'?'present (unlocked only)':'ABSENT on security notice'));
  ok(A.audit.some(a=>a.a===ev+'_EMAIL_SENT'),ev+': audit entry unchanged');
  if(/\nIf /.test(body)&&body.split('\n\n').length>2)ok(/border:1px solid #(E7BAB8|EBCF97|C7D2EC)[^>]*>If /.test(x.htmlBody),ev+': final "If ..." advice boxed');
}
let A=makeEnv({});A.ctx.notifyUserOfAccountEvent(userRow('auditor','aud@t.test'),'USER_PASSWORD_RESET','s','Hello x,\n\nbody');ok(A.mails.length===0,'account notice: auditors still never emailed');
A=makeEnv({});A.ctx.notifyUserOfAccountEvent(userRow('submission',''),'USER_PASSWORD_RESET','s','Hello x,\n\nbody');ok(A.mails.length===0&&A.audit[0].a==='USER_PASSWORD_RESET_EMAIL_SKIPPED','account notice: no email on file => skipped and audited, as before');
A=makeEnv({mailFails:true});A.ctx.notifyUserOfAccountEvent(userRow('submission','m@t.test'),'USER_PASSWORD_RESET','s','Hello x,\n\nbody');ok(A.audit[0].a==='USER_PASSWORD_RESET_EMAIL_FAILED','account notice: send failure audited, never thrown, as before');
A=makeEnv({});A.ctx.buildAccountEventEmail_=()=>{throw new Error('boom')};A.ctx.notifyUserOfAccountEvent(userRow('submission','m@t.test'),'USER_LOCKED_OUT','s','Hello x,\n\nbody');
ok(A.mails.length===1&&!('htmlBody' in A.mails[0])&&A.mails[0].body==='Hello x,\n\nbody'&&A.audit[0].a==='USER_LOCKED_OUT_EMAIL_SENT','account notice/template bug: plain text still delivered and audited as sent');
A=makeEnv({});A.ctx.notifyUserOfAccountEvent(userRow('submission','m@t.test'),'USER_PASSWORD_RESET','s','Hello <b>x</b>,\n\n<script>1</script>');
ok(!/<script>/.test(A.mails[0].htmlBody)&&/&lt;script&gt;/.test(A.mails[0].htmlBody),'account notice: body text escaped in html');
A=makeEnv({});A.ctx.notifyUserOfAccountEvent(userRow('submission','m@t.test'),'SOME_NEW_EVENT','Custom subject','Hello x,\n\nSomething happened.');
ok(/Custom subject/.test(A.mails[0].htmlBody),'account notice: an unknown future event still renders (falls back to the subject as title)');

console.log(`notification tests: ${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
