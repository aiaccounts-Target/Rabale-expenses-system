const fs=require('fs'),vm=require('vm'),path=require('path');
const D=path.join(__dirname,'..');
let pass=0,fail=0;
function ok(c,m){if(c){pass++}else{fail++;console.log('FAIL:',m)}}
const pad=n=>('0'+n).slice(-2);
const isoLocal=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())+'T'+pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds());

function makeEnv(o){
  o=o||{};
  const mails=[],logs=[],audit=[],triggers=[];
  const props=Object.assign({},o.props||{});
  const svcUrl=(o.svcUrl===undefined)?'https://script.google.com/macros/s/TEST/exec':o.svcUrl;
  const ctx={
    Logger:{log:m=>logs.push(String(m))},
    Session:{getScriptTimeZone:()=>'Asia/Kolkata',getEffectiveUser:()=>({getEmail:()=>'admin@target.test'})},
    PropertiesService:{getScriptProperties:()=>({getProperty:k=>props[k]===undefined?null:props[k]})},
    Utilities:{formatDate:d=>pad(d.getDate())+'-'+pad(d.getMonth()+1)+'-'+d.getFullYear(),
      base64Decode:s=>{if(o.badLogo)throw new Error('decode fail');return Array.from(Buffer.from(s,'base64'))},
      newBlob:(bytes,mime,name)=>({bytes,mime,name})},
    MailApp:{sendEmail:x=>{if(o.failFor&&x.to===o.failFor)throw new Error('bad address');mails.push(x)}},
    ScriptApp:{getService:()=>({getUrl:()=>svcUrl}),
      getProjectTriggers:()=>triggers.slice(),deleteTrigger:t=>{const i=triggers.indexOf(t);if(i>=0)triggers.splice(i,1)},
      newTrigger:fn=>{const t={fn,hour:null,getHandlerFunction(){return fn}};const b={timeBased:()=>b,everyDays:()=>b,atHour:h=>{t.hour=h;return b},create:()=>{triggers.push(t);return t}};return b}},
    console};
  vm.createContext(ctx);
  for(const f of ['Config.gs','Sheet Utlis.gs','Logos.gs','EmailTemplates.gs','Triggers.gs'])vm.runInContext(fs.readFileSync(path.join(D,f),'utf8'),ctx,{filename:f});
  const today=new Date();today.setHours(12,0,0,0);
  const dmy=n=>{const d=new Date(today);d.setDate(d.getDate()-n);return pad(d.getDate())+'-'+pad(d.getMonth()+1)+'-'+d.getFullYear()};
  ctx.getSheet=name=>{
    if(name===ctx.QUERY_THREAD_SHEET) return {getDataRange:()=>({getValues:()=>[['hdr']].concat((o.qrows||[]).map(f=>f(ctx)))})};
    return {getDataRange:()=>({getValues:()=>[['hdr']].concat((o.rows||[]).map(f=>f(dmy,ctx)))})};
  };
  ctx.getActiveUserEmailsForRole=r=>(o.recipients||{})[r]||[];
  ctx.logAction=(a,v,who,role,n)=>audit.push({a,n});
  return {ctx,mails,logs,audit,triggers};
}
const boot=makeEnv({});const AV=boot.ctx.AV,QT=boot.ctx.QT;
const V=o=>(dmy,ctx)=>{const r=new Array(30).fill('');r[AV.VOUCHER_ID]=o.id;r[AV.DATE]=(o.dateVal!==undefined)?o.dateVal:dmy(o.age||0);r[AV.SUBMITTED_BY]=o.by||'Suresh Patil';r[AV.COST_CENTRE]=o.cc||'Rabale Plant';r[AV.AMOUNT]=o.amt||100;r[AV.STATUS]=o.status;r[AV.QUERY_STATUS]=o.q===undefined?'No Query':o.q;return r};
const Q=o=>ctx=>{const r=new Array(10).fill('');const d=new Date();d.setTime(d.getTime()-(o.hoursAgo||0)*3600000);r[QT.VOUCHER_ID]=o.id;r[QT.QUERY_TYPE]=o.type||'Missing bill';r[QT.RAISED_BY]=o.by||'Anita Kulkarni';r[QT.RAISED_DATE]=isoLocal(d);r[QT.QUERY_DETAILS]=o.details===undefined?'Please attach the fuel bill':o.details;r[QT.STATUS]=o.status||'Open';return r};

// ================= getAppUrl
let E=makeEnv({props:{APP_URL:'https://script.google.com/macros/s/PROD/exec'},svcUrl:'https://script.google.com/macros/s/TEST/dev'});
ok(E.ctx.getAppUrl()==='https://script.google.com/macros/s/PROD/exec','APP_URL property wins over a /dev service URL');
E=makeEnv({props:{APP_URL:'  https://script.google.com/macros/s/PROD/exec  '}});ok(E.ctx.getAppUrl()==='https://script.google.com/macros/s/PROD/exec','APP_URL trimmed');
E=makeEnv({props:{APP_URL:'javascript:alert(1)'}});ok(E.ctx.getAppUrl()==='','non-https APP_URL rejected');
E=makeEnv({props:{APP_URL:'http://script.google.com/x/exec'}});ok(E.ctx.getAppUrl()==='','plain http APP_URL rejected');
E=makeEnv({svcUrl:'https://script.google.com/macros/s/TEST/exec'});ok(E.ctx.getAppUrl()==='https://script.google.com/macros/s/TEST/exec','service /exec URL accepted when no property');
E=makeEnv({svcUrl:'https://script.google.com/macros/s/TEST/dev'});ok(E.ctx.getAppUrl()==='','service /dev URL never used');
ok(E.logs.some(m=>/APP_URL/.test(m)),'/dev case tells the admin to set APP_URL');
E=makeEnv({svcUrl:'https://script.google.com/a/macros/target.test/s/X/dev'});ok(E.ctx.getAppUrl()==='','Workspace-style /dev URL also refused');

// ================= template primitives
E=makeEnv({});ok(E.ctx.emailPlural_(1,'query','queries')==='1 query'&&E.ctx.emailPlural_(3,'query','queries')==='3 queries'&&E.ctx.emailPlural_(0,'voucher')==='0 vouchers'&&E.ctx.emailPlural_(2,'day')==='2 days','emailPlural_ regular and irregular plurals');
E=makeEnv({});const c=E.ctx;
ok(c.emailDate_('25-7-2026')==='25-07-2026'&&c.emailDate_('5/9/2026')==='05-09-2026'&&c.emailDate_('garbage')==='garbage'&&c.emailDate_('')==='','emailDate_ pads valid dates, leaves others alone');
ok(c.emailMoney_(53619)==='53,619'&&c.emailMoney_(18250.5)==='18,250.50'&&c.emailMoney_(0)==='0','emailMoney_ Indian grouping, 2dp only when needed: '+c.emailMoney_(18250.5));
const nl=c.emailNoAutoLink_('11 Rabale');
ok(!nl.includes('11 Rabale')&&nl.includes('<span>11</span>')&&nl.includes('&#8203;')&&nl.includes('<span>Rabale</span>'),'auto-link defeated: '+nl);
ok(c.emailNoAutoLink_('<script>x</script> & Co').indexOf('<script>')===-1,'emailNoAutoLink_ escapes markup');
const table=c.emailTable_([{label:'A',nowrap:true},{label:'B',hideSmall:true}],[{cells:['x','y'],detail:'DETAIL'}]);
ok(/<th class="hs"/.test(table)&&/<td class="hs"/.test(table)&&/colspan="2"/.test(table)&&table.includes('DETAIL'),'table: hideSmall on th+td, detail row spans all columns');
const html=c.buildBrandedEmail_({title:'T',blocks:['<p>b</p>'],ctaUrl:'javascript:alert(1)',hasLogo:false});
ok(!/href=/.test(html),'non-https CTA never rendered');
ok(/^<!DOCTYPE html>/.test(html)&&/format-detection/.test(html)&&/max-width:820px/.test(html)&&/@media only screen and \(max-width:600px\)/.test(html),'full document, format-detection meta, fluid 820px card, mobile media query');

// ================= approver digest
const rows=[
  V({id:'20202',dateVal:'25-7-2026',amt:5000,status:'Pending L1',by:'Amit Sharma',cc:'Project/BMC/JP - Gyanpeti/02'}),
  V({id:'V-TKZD9BSZO',age:56,amt:3015,status:'Pending L1',by:'IOU - Uday Hedulkar',cc:'11 Rabale'}),
  V({id:'V-Q',age:5,status:'Pending L1',q:'Query - Open'}),
  V({id:'ACC',age:1,amt:2500.5,status:'Pending Accounts',by:'<b>Evil</b> & Co'}),
];
E=makeEnv({rows,recipients:{L1:['a@t.test'],accounts:['c@t.test']},props:{APP_URL:'https://script.google.com/macros/s/PROD/exec'}});
E.ctx.sendApproverDigests();
const l1=E.mails.find(m=>m.to==='a@t.test'),acc=E.mails.find(m=>m.to==='c@t.test');
ok(E.mails.length===2,'digest: one per recipient');
ok(!l1.htmlBody.includes('11 Rabale')&&l1.htmlBody.includes('<span>11</span>'),'digest: "11 Rabale" not auto-linkable');
ok(/<td class="vid"[^>]*white-space:nowrap/.test(l1.htmlBody),'digest: voucher ID cells never wrap');
ok(/white-space:nowrap[^>]*>\d+d<\/td>/.test(l1.htmlBody)&&/font-family:Consolas/.test(l1.htmlBody),'digest: age and amount cells nowrap/mono');
ok(l1.htmlBody.includes('25-07-2026'),'digest: date normalised to dd-mm-yyyy');
ok(l1.htmlBody.includes('href="https://script.google.com/macros/s/PROD/exec"')&&l1.htmlBody.includes('/exec'),'digest: button uses the /exec APP_URL, not /dev');
ok(!/\/dev/.test(l1.htmlBody+l1.body),'digest: no /dev link anywhere');
ok(acc.htmlBody.includes('&lt;b&gt;Evil&lt;/b&gt;')&&!acc.htmlBody.includes('<b>Evil</b>'),'digest: submitter name escaped');
ok((l1.htmlBody.match(/class="vid"/g)||[]).length===2,'digest: 2 actionable rows (queried one excluded)');
ok((l1.htmlBody.match(/class="overdue"/g)||[]).length===2,'digest: both old rows flagged overdue');
ok(/on hold because a query is open/.test(l1.htmlBody)&&/V-Q/.test(l1.htmlBody),'digest: queried voucher noted as on hold');
ok(l1.inlineImages&&l1.inlineImages.logo.bytes.slice(0,4).join()==='137,80,78,71'&&l1.htmlBody.includes('cid:logo'),'digest: PNG logo inlined');
ok(/Oldest|oldest/.test(l1.subject)&&/2 vouchers awaiting/.test(l1.subject),'digest: subject '+l1.subject);
// no link when only /dev is known
E=makeEnv({rows:[V({id:'A',age:1,status:'Pending L1'})],recipients:{L1:['a@t.test']},svcUrl:'https://script.google.com/macros/s/T/dev'});
E.ctx.sendApproverDigests();
ok(E.mails.length===1&&!/href=/.test(E.mails[0].htmlBody)&&!/Open the app/.test(E.mails[0].body),'digest: with only a /dev URL known, the button is omitted (mail still sent)');
// cap
E=makeEnv({rows:Array.from({length:40},(_,i)=>V({id:'V'+i,age:i%7,amt:10,status:'Pending L1'})),recipients:{L1:['a@t.test']}});E.ctx.sendApproverDigests();
ok((E.mails[0].htmlBody.match(/class="vid"/g)||[]).length===25&&/\+ 15 more/.test(E.mails[0].htmlBody),'digest: capped at 25 rows with +15 more');
// nothing to send
E=makeEnv({rows:[V({id:'X',age:3,status:'Approved'})],recipients:{L1:['a@t.test']}});E.ctx.sendApproverDigests();
ok(E.mails.length===0&&E.audit.length===0,'digest: silent when nothing awaiting');
// gap recorded
E=makeEnv({rows:[V({id:'A',age:1,status:'Pending L2'})],recipients:{}});E.ctx.sendApproverDigests();
ok(E.mails.length===0&&/L2: 1 awaiting but NO active user/.test(E.audit[0].n),'digest: recipient gap written to audit log');
// logo failure, mail failure
E=makeEnv({rows:[V({id:'A',age:1,status:'Pending L1'})],recipients:{L1:['bad@t.test','good@t.test']},failFor:'bad@t.test',badLogo:true});E.ctx.sendApproverDigests();
ok(E.mails.length===1&&E.mails[0].to==='good@t.test'&&!E.mails[0].inlineImages&&!E.mails[0].htmlBody.includes('cid:logo'),'digest: bad address skipped, logo failure degrades to text header');
// preview
E=makeEnv({rows:[V({id:'A',age:1,status:'Pending L1'}),V({id:'B',age:1,status:'Pending L2'})],recipients:{L1:['a@t.test'],L2:['l@t.test']}});E.ctx.previewApproverDigestsToMe();
ok(E.mails.length===2&&E.mails.every(m=>m.to==='admin@target.test'&&/^\[PREVIEW/.test(m.subject)),'digest preview: only the runner receives');
// triggers
E=makeEnv({});E.ctx.setupAllScheduledTriggers();E.ctx.setupAllScheduledTriggers();
ok(JSON.stringify(E.triggers.map(t=>t.fn).sort())===JSON.stringify(['closeRdsDay','sendApproverDigests','sendQueryAgingReminders','sendSameDayQueryReminders']),'triggers: 4, no duplicates');

// ================= same-day query reminder (submitter email)
const avRows=[V({id:'6779',status:'Pending L1',by:'Suresh Patil',amt:1850,q:'Query - Open'}),V({id:'6780',status:'Pending L1',by:'Meena Rao',amt:640,q:'Query - Open'})];
E=makeEnv({rows:avRows,recipients:{submission:['s1@t.test','s2@t.test'],L1:['a@t.test']},props:{APP_URL:'https://script.google.com/macros/s/PROD/exec'},
  qrows:[Q({id:'6779',hoursAgo:0,details:'Missing bill for fuel expense'}),Q({id:'6780',hoursAgo:0,type:'Ledger / Vendor',by:'Rajesh Mehta'}),Q({id:'OLD',hoursAgo:72}),Q({id:'CLOSED',hoursAgo:0,status:'Closed'})]});
E.ctx.sendSameDayQueryReminders();
ok(JSON.stringify(E.mails.map(m=>m.to).sort())==='["s1@t.test","s2@t.test"]','same-day: goes to submission users only');
const sd=E.mails[0];
ok(/2 queries raised today, still open/.test(sd.htmlBody)&&!/querys/.test(sd.htmlBody),'same-day: title says "queries", never "querys"');
ok(sd.subject==='2 voucher queries from today still open','same-day: subject unchanged from before: '+sd.subject);
ok(/2 queries were raised today and still need a response:/.test(sd.body)&&/Missing bill for fuel expense/.test(sd.body)&&!/OLD|CLOSED/.test(sd.body),'same-day: plain-text body unchanged in substance, only today\'s open queries');
ok(sd.htmlBody.includes('Suresh Patil'.split(' ')[0])&&sd.htmlBody.includes('1,850')&&sd.htmlBody.includes('640'),'same-day: employee and amount looked up from the voucher');
ok(sd.htmlBody.includes('\u201cMissing bill for fuel expense\u201d')&&/colspan="4"/.test(sd.htmlBody)&&sd.htmlBody.includes('Missing bill')&&/raised by/.test(sd.htmlBody),'same-day: type, raised-by and details on one full-width line under the row');
ok((sd.htmlBody.match(/class="vid"/g)||[]).length===2&&!/OLD|CLOSED/.test(sd.htmlBody),'same-day: 2 rows, old and closed excluded');
ok(sd.htmlBody.includes('cid:logo')&&sd.htmlBody.includes('href="https://script.google.com/macros/s/PROD/exec"')&&sd.htmlBody.includes('Open My Vouchers'),'same-day: logo + /exec link');
ok(/Today/.test(sd.htmlBody)&&!/class="overdue"/.test(sd.htmlBody),'same-day: shows "Today", no overdue styling');
ok(/SAME_DAY_QUERY_REMINDER_SENT/.test(E.audit[0].a)&&/emailed to 2 submission/.test(E.audit[0].n),'same-day: audit entry unchanged');
// unknown voucher + long/hostile details
E=makeEnv({rows:[],recipients:{submission:['s1@t.test']},qrows:[Q({id:'GHOST',hoursAgo:0,details:'<img src=x onerror=1> '+'x'.repeat(300)})]});
E.ctx.sendSameDayQueryReminders();
ok(E.mails.length===1&&E.mails[0].htmlBody.includes('\u2014')&&!E.mails[0].htmlBody.includes('<img src=x'),'same-day: unknown voucher shows dashes, hostile details escaped');
ok(!/x{151}/.test(E.mails[0].htmlBody)&&!/x{151}/.test(E.mails[0].body),'same-day: details truncated to 150 chars in html and text');
// nothing today
E=makeEnv({rows:[],recipients:{submission:['s1@t.test']},qrows:[Q({id:'OLD',hoursAgo:72})]});E.ctx.sendSameDayQueryReminders();
ok(E.mails.length===0&&E.audit.length===0,'same-day: silent when nothing raised today');
// cap
E=makeEnv({rows:[],recipients:{submission:['s@t.test']},qrows:Array.from({length:30},(_,i)=>Q({id:'Q'+i,hoursAgo:0}))});E.ctx.sendSameDayQueryReminders();
ok((E.mails[0].htmlBody.match(/class="vid"/g)||[]).length===25&&/\+ 5 more/.test(E.mails[0].htmlBody),'same-day: capped at 25 rows with +5 more');

// ================= aging reminder (admin address)
E=makeEnv({rows:avRows,props:{QUERY_REMINDER_EMAIL:'boss@t.test'},qrows:[Q({id:'6779',hoursAgo:24*3}),Q({id:'6780',hoursAgo:24*5}),Q({id:'FRESH',hoursAgo:5})]});
E.ctx.sendQueryAgingReminders();
ok(E.mails.length===1&&E.mails[0].to==='boss@t.test','aging: to QUERY_REMINDER_EMAIL');
ok(E.mails[0].subject==='2 voucher queries overdue for a response','aging: subject unchanged: '+E.mails[0].subject);
ok(/2 queries overdue for a response/.test(E.mails[0].htmlBody)&&!/querys/.test(E.mails[0].htmlBody),'aging: title plural');
ok(/2 queries have been open 2\+ days and need a response:/.test(E.mails[0].body)&&/open 5 day\(s\)/.test(E.mails[0].body)&&!/FRESH/.test(E.mails[0].body),'aging: plain text unchanged, fresh query excluded');
ok(E.mails[0].htmlBody.indexOf('6780')<E.mails[0].htmlBody.indexOf('6779'),'aging: oldest first');
ok((E.mails[0].htmlBody.match(/class="overdue"/g)||[]).length===1,'aging: only the 5-day query (>= 2x threshold) is red');
ok(E.audit[0].a==='QUERY_REMINDER_SENT','aging: audit entry unchanged');
E=makeEnv({rows:[],qrows:[Q({id:'A',hoursAgo:24*9})]});E.ctx.sendQueryAgingReminders();
ok(E.mails.length===0,'aging: no email when QUERY_REMINDER_EMAIL unset');
// preview
E=makeEnv({rows:avRows,qrows:[Q({id:'6779',hoursAgo:1}),Q({id:'6780',hoursAgo:100})],recipients:{submission:['s@t.test']},props:{QUERY_REMINDER_EMAIL:'boss@t.test'}});E.ctx.previewQueryReminderEmailsToMe();
ok(E.mails.length===2&&E.mails.every(m=>m.to==='admin@target.test'&&/^\[PREVIEW /.test(m.subject)),'query preview: both layouts, to the runner only');
E=makeEnv({rows:[],qrows:[]});E.ctx.previewQueryReminderEmailsToMe();ok(E.mails.length===0,'query preview: nothing sent when no open queries');

// ================= assets
const tb=Buffer.from(boot.ctx.getLogoTDataUri().split(',')[1],'base64'),fb=Buffer.from(boot.ctx.getLogoFullDataUri().split(',')[1],'base64');
ok(tb.slice(0,4).toString('hex')==='89504e47','T logo PNG');
ok(fb.slice(0,4).toString()==='RIFF'&&fs.readFileSync('/mnt/user-data/uploads/Full_logo.webp').equals(fb),'full logo is the supplied WebP, byte-identical');
console.log(`email tests: ${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
