const fs=require('fs'),vm=require('vm'),path=require('path');
const D=path.join(__dirname,'..');
let pass=0,fail=0;
function ok(c,m){if(c){pass++}else{fail++;console.log('FAIL:',m)}}
const FILES=['Config.gs','Sheet Utlis.gs','Logos.gs','EmailTemplates.gs','Notifications.gs','Users.gs','Master data.gs'];

// ---------- tiny Drive tree
function makeDrive(o){
  o=o||{};const log=[];
  function Folder(name){this.name=name;this.folders={};this.files=[];this.sharing=null;this.trashed=false}
  Folder.prototype.getFoldersByName=function(n){const f=this.folders[n];let done=!f;return {hasNext:()=>!done,next:()=>{done=true;return f}}};
  Folder.prototype.createFolder=function(n){log.push('createFolder:'+n);const f=new Folder(n);this.folders[n]=f;return f};
  Folder.prototype.setSharing=function(a,p){if(o.shareFails)throw new Error('sharing not allowed');this.sharing=[a,p]};
  Folder.prototype.getUrl=function(){return 'https://drive.google.com/drive/folders/'+encodeURIComponent(this.name)};
  Folder.prototype.createFile=function(blob){if(o.createFails)throw new Error('Drive quota exceeded');const self=this;const f={name:blob.name,blob,trashed:false,getUrl:()=> 'https://drive.google.com/file/d/'+encodeURIComponent(blob.name)+'/view',setTrashed:v=>{if(o.trashFails)throw new Error('trash failed');f.trashed=v}};this.files.push(f);log.push('createFile:'+blob.name);return f};
  const root=new Folder('root');
  return {root,log,DriveApp:{getRootFolder:()=>root,Access:{DOMAIN_WITH_LINK:'DOMAIN_WITH_LINK'},Permission:{VIEW:'VIEW'}}};
}
function makeEnv(o){
  o=o||{};
  const mails=[],logs=[],audit=[];
  const props=Object.assign({},o.props||{});
  const drive=makeDrive(o.drive);
  const ctx={
    Logger:{log:m=>logs.push(String(m))},
    Session:{getScriptTimeZone:()=> 'Asia/Kolkata',getEffectiveUser:()=>({getEmail:()=> 'deployer@target.test'})},
    PropertiesService:{getScriptProperties:()=>({getProperty:k=>props[k]===undefined?null:props[k]})},
    Utilities:{formatDate:d=>('0'+d.getDate()).slice(-2)+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+d.getFullYear(),
      base64Decode:s=>Array.from(Buffer.from(s,'base64')),newBlob:(bytes,mime,name)=>({bytes,mime,name}),
      getUuid:()=> 'abcdef12-0000-0000-0000-000000000000',
      computeDigest:(alg,val)=>Array.from(require('crypto').createHash('sha256').update(String(val)).digest()).map(x=>x>127?x-256:x),
      DigestAlgorithm:{SHA_256:'SHA_256'},Charset:{UTF_8:'UTF_8'}},
    MailApp:{sendEmail:x=>{if(o.mailFails)throw new Error('address rejected');mails.push(x)}},
    ScriptApp:{getService:()=>({getUrl:()=> ''})},
    LockService:{getScriptLock:()=>({waitLock(){},releaseLock(){}})},
    CacheService:{getScriptCache:()=>({get(){return null},put(){},remove(){}})},
    DriveApp:drive.DriveApp,console};
  vm.createContext(ctx);
  for(const f of FILES)vm.runInContext(fs.readFileSync(path.join(D,f),'utf8'),ctx,{filename:f});
  ctx.logAction=(a,v,who,role,n)=>audit.push({a,v,who,role,n});
  ctx.validateSession=()=>o.session||{valid:true,role:'admin',displayName:'Admin User'};
  return {ctx,mails,logs,audit,drive};
}
// ---------- fake users sheet
function usersSheet(env,rows){
  const s={data:rows,writes:[],
    getDataRange:()=>({getValues:()=>s.data.map(r=>r.slice())}),
    getRange:(r,c)=>({setValue:v=>{s.writes.push([r,c,v]);while(s.data.length<r)s.data.push([]);s.data[r-1][c-1]=v},getValue:()=>((s.data[r-1]||[])[c-1])}),
    appendRow:row=>{s.writes.push(['append']);s.data.push(row)},getLastRow:()=>s.data.length};
  return s;
}
const boot=makeEnv({});const C=boot.ctx,USR=C.USR;
const urow=(o)=>{const r=new Array(15).fill('');r[USR.USER_ID]=o.id||'U-1';r[USR.DISPLAY_NAME]=o.name||'Meena Rao';r[USR.USERNAME]=o.username||'meena';r[USR.ROLE]=o.role||'submission';r[USR.ACTIVE]='Yes';r[USR.EMAIL]=o.email||'';if(o.designation!==undefined)r[USR.DESIGNATION]=o.designation;return r};

// ====================================================== schema
ok(USR.DESIGNATION===14&&C.EXPECTED_USER_HEADERS[14]==='Designation'&&C.EXPECTED_USER_HEADERS.length===15,'Designation is the 15th column, appended after every existing one (nothing shifted)');
ok(USR.PENDING_EMAIL_OTP_EXPIRY===13&&C.EXPECTED_USER_HEADERS[13]==='Pending Email OTP Expiry','existing columns unchanged');

// ====================================================== validateDesignation
const vd=C.validateDesignation;
ok(vd('  Warehouse   Manager ').designation==='Warehouse Manager','collapses whitespace');
ok(vd('').valid&&vd('').designation===''&&vd(null).designation===''&&vd(undefined).designation==='','blank / null is valid = not set');
ok(vd('Head <b>of</b> Finance').designation==='Head b of /b Finance'||!/[<>]/.test(vd('Head <b>of</b> Finance').designation),'angle brackets removed');
ok(!/[\u0000-\u001f]/.test(vd('Mgr\u0000\u0007\nOps').designation)&&vd('Mgr\nOps').designation==='Mgr Ops','control characters and newlines removed');
ok(vd('a'.repeat(80)).valid&&!vd('a'.repeat(81)).valid&&/too long/.test(vd('a'.repeat(81)).error),'80 characters allowed, 81 rejected');
ok(vd('Manager \u2013 Operations (Rabale)').designation==='Manager \u2013 Operations (Rabale)','punctuation and unicode preserved');

// ====================================================== header self-heal
let E=makeEnv({});let sh=usersSheet(E,[['User ID']]);
E.ctx.ensureUsersDesignationHeader_(sh);
ok(sh.writes.length===1&&sh.writes[0][0]===1&&sh.writes[0][1]===15&&sh.writes[0][2]==='Designation','existing sheet: header cell added at column 15');
E.ctx.ensureUsersDesignationHeader_(sh);ok(sh.writes.length===1,'idempotent: second call writes nothing');
E=makeEnv({});E.ctx.ensureUsersDesignationHeader_({getRange:()=>{throw new Error('sheet gone')}});ok(E.logs.some(m=>/ensureUsersDesignationHeader_/.test(m)),'a failure is logged, never thrown');
// getOrCreateUsersSheet wiring
E=makeEnv({});sh=usersSheet(E,[['User ID']]);E.ctx.getSpreadsheet=()=>({getSheetByName:()=>sh});E.ctx.getOrCreateUsersSheet();
ok(sh.writes.some(w=>w[1]===15&&w[2]==='Designation'),'getOrCreateUsersSheet heals an existing sheet automatically');

// ====================================================== listUsers / setUserDesignation
function adminEnv(rows,o){o=o||{};const env=makeEnv(o);const s=usersSheet(env,[['hdr']].concat(rows));env.ctx.getOrCreateUsersSheet=()=>s;
  env.ctx.findUserById=id=>{for(let i=1;i<s.data.length;i++)if(s.data[i][USR.USER_ID]===id)return {sheet:s,rowIndex:i+1,rowValues:s.data[i]};return null};
  env.ctx.findUserByUsername=()=>null;return {env,s,c:env.ctx}}
let A=adminEnv([urow({id:'U-1',name:'Meena Rao',designation:'Warehouse Manager'}),urow({id:'U-2',name:'Anil Rao'})]);
let r=A.c.listUsers('tok');
ok(r.success&&r.users.find(u=>u.userId==='U-1').designation==='Warehouse Manager'&&r.users.find(u=>u.userId==='U-2').designation==='','listUsers: position returned; users without one get ""');
const short=new Array(14).fill('');short[USR.USER_ID]='U-9';short[USR.DISPLAY_NAME]='Old Row';short[USR.ROLE]='L1';short[USR.ACTIVE]='Yes';
A=adminEnv([short]);r=A.c.listUsers('tok');ok(r.success&&r.users[0].designation==='','a row written before the column existed (14 cells) reads as "not set", no crash');
A=adminEnv([urow({id:'U-1',designation:'Warehouse Manager'})]);
r=A.c.setUserDesignation('U-1','  Head of Finance ','tok');
ok(r.success&&A.s.data[1][USR.DESIGNATION]==='Head of Finance'&&/set to "Head of Finance"/.test(r.message),'setUserDesignation: saved, normalised');
ok(A.env.audit[0].a==='USER_DESIGNATION_SET'&&/"Warehouse Manager" \u2192 "Head of Finance"/.test(A.env.audit[0].n),'audit entry records before and after: '+A.env.audit[0].n);
r=A.c.setUserDesignation('U-1','','tok');ok(r.success&&A.s.data[1][USR.DESIGNATION]===''&&/cleared/.test(r.message)&&/\(cleared\)/.test(A.env.audit[1].n),'blank clears it (and says so)');
r=A.c.setUserDesignation('U-404','x','tok');ok(!r.success&&/not found/.test(r.error),'unknown user');
r=A.c.setUserDesignation('U-1','a'.repeat(81),'tok');ok(!r.success&&/too long/.test(r.error)&&A.s.data[1][USR.DESIGNATION]==='','too long rejected, nothing written');
A=adminEnv([urow({id:'U-1'})],{session:{valid:true,role:'submission',displayName:'Suresh'}});r=A.c.setUserDesignation('U-1','CEO','tok');
ok(!r.success&&/permission/.test(r.error)&&A.s.writes.length===0,'non-admin cannot set anyone\'s position (server-side check)');
A=adminEnv([urow({id:'U-1'})],{session:{valid:false}});r=A.c.setUserDesignation('U-1','CEO','tok');ok(!r.success&&A.s.writes.length===0,'invalid session refused');

// ====================================================== createUser
A=adminEnv([]);
r=A.c.createUser('Priya Sharma','L1','priya.s','Passw0rdX','', ' Warehouse  Manager ','tok');
const nr=A.s.data[1];
ok(r.success&&nr[USR.DESIGNATION]==='Warehouse Manager'&&nr[USR.ROLE]==='L1'&&nr[USR.DISPLAY_NAME]==='Priya Sharma','createUser: position stored (normalised) alongside the role');
ok(/position: Warehouse Manager/.test(A.env.audit.find(a=>a.a==='USER_CREATE').n),'createUser: position in the audit note');
A=adminEnv([]);r=A.c.createUser('Priya Sharma','L1','priya.s','Passw0rdX','','','tok');ok(r.success&&A.s.data[1][USR.DESIGNATION]==='','createUser: position optional');
A=adminEnv([]);r=A.c.createUser('Priya Sharma','L1','priya.s','Passw0rdX','','x'.repeat(81),'tok');ok(!r.success&&A.s.data.length===1,'createUser: over-long position rejected before any row is written');
A=adminEnv([]);r=A.c.createUser('Priya Sharma','bogus','priya.s','Passw0rdX','','CEO','tok');ok(!r.success&&/Invalid role/.test(r.error),'createUser: role validation unchanged');
A=adminEnv([]);r=A.c.createUser('Priya Sharma','L1','priya.s','Passw0rdX','priya@t.test','Warehouse Manager','tok');
ok(r.success&&/verification code was sent to priya@t\.test/.test(r.message)&&A.env.mails.length===1,'createUser with an email still starts the OTP flow');
ok(/\(Warehouse Manager\)/.test(A.env.mails[0].body)&&/Warehouse Manager/.test(A.env.mails[0].htmlBody),'createUser: the OTP email already names the new user\'s position');

// ====================================================== OTP email
// golden: the ORIGINAL wording, which must be unchanged when no position is set
function origOtp(name,otp,mins){return 'Hello,\n\nA request was made to set this email address on the account for "'+name+'" on the Rabale Petty Expense System.\n\n'+'Verification code: '+otp+'\n\n'+'This code expires in '+mins+' minutes. Give it to your administrator to confirm the change.\n\n'+'If you did not expect this, you can ignore this email \u2014 no change will be made without the code above.'}
ok(C.otpVerificationText_({displayName:'Meena Rao',designation:'',otp:'482913',expiryMinutes:10})===origOtp('Meena Rao','482913',10),'OTP plain text without a position is byte-identical to the previous wording');
ok(C.otpVerificationText_({displayName:'Meena Rao',designation:'Warehouse Manager',otp:'482913',expiryMinutes:10})===origOtp('Meena Rao','482913',10).replace('"Meena Rao" on','"Meena Rao" (Warehouse Manager) on'),'with a position it is added after the name, nothing else changes');
let h=C.otpVerificationHtml_({displayName:'Meena Rao',designation:'Warehouse Manager',otp:'482913',expiryMinutes:10},true);
ok(/482913/.test(h)&&/letter-spacing:8px/.test(h)&&/Warehouse Manager/.test(h)&&/Meena Rao/.test(h)&&/10 minutes/.test(h)&&/cid:logo/.test(h),'OTP html: code, name, position, expiry, logo');
ok(!/<a /.test(h)&&!/href=/.test(h),'OTP html: NO links or buttons (a code email must not invite clicking)');
h=C.otpVerificationHtml_({displayName:'<b>X</b>',designation:'<i>Mgr</i>',otp:'123456',expiryMinutes:10},false);
ok(!/<b>X|<i>Mgr/.test(h)&&/&lt;b&gt;X/.test(h),'OTP html: name and position escaped');
ok(!/Position/.test(C.otpVerificationHtml_({displayName:'Meena Rao',designation:'',otp:'1',expiryMinutes:10},false)),'OTP html: no Position row when none is set');
// end-to-end through the real beginPendingEmailChange
function otpEnv(o){o=o||{};const env=makeEnv(o);const s=usersSheet(env,[['hdr'],urow({id:'U-1',name:'Meena Rao',designation:o.designation})]);
  return {env,s,found:{sheet:s,rowIndex:2,rowValues:s.data[1]},c:env.ctx}}
let O=otpEnv({designation:'Warehouse Manager'});
O.c.beginPendingEmailChange(O.found,'meena@t.test',{displayName:'Admin User',role:'admin'});
let m=O.env.mails[0];
ok(m.to==='meena@t.test'&&m.subject==='Rabale Petty Expense System \u2014 verify this email address','OTP: recipient and subject unchanged');
ok(/for "Meena Rao" \(Warehouse Manager\)/.test(m.body)&&m.htmlBody&&m.inlineImages,'OTP: plain text names the position, branded html + logo attached');
const code=/Verification code: (\d{6})/.exec(m.body)[1];
ok(new RegExp('>'+code+'<').test(m.htmlBody),'OTP: the html shows exactly the same code as the plain text');
ok(O.c.verifyPassword(code,O.s.data[1][USR.PENDING_EMAIL_OTP_SALT],O.s.data[1][USR.PENDING_EMAIL_OTP_HASH]),'OTP: the emailed code verifies against the stored salted hash (verification flow unaffected)');
ok(O.s.data[1][USR.PENDING_EMAIL]==='meena@t.test'&&!JSON.stringify(O.s.data).includes(code),'OTP: pending email stored; the code itself is never stored in plaintext');
ok(!O.env.audit.some(a=>(a.n||'').includes(code))&&!O.env.logs.some(l=>l.includes(code)),'OTP: the code never appears in the audit log or logs');
// template failure => plain text still delivers a working code
O=otpEnv({designation:'Warehouse Manager'});O.c.otpVerificationHtml_=()=>{throw new Error('boom')};
O.c.beginPendingEmailChange(O.found,'meena@t.test',{displayName:'Admin User',role:'admin'});m=O.env.mails[0];
const code2=/Verification code: (\d{6})/.exec(m.body)[1];
ok(O.env.mails.length===1&&!('htmlBody' in m)&&O.c.verifyPassword(code2,O.s.data[1][USR.PENDING_EMAIL_OTP_SALT],O.s.data[1][USR.PENDING_EMAIL_OTP_HASH]),'OTP/template bug: plain-text code still sent and still verifies');
// send failure => pending write rolled back, error surfaced (unchanged behaviour)
O=otpEnv({mailFails:true});let threw=null;try{O.c.beginPendingEmailChange(O.found,'meena@t.test',{displayName:'Admin User',role:'admin'})}catch(e){threw=e}
ok(threw&&/could not send to meena@t\.test/.test(threw.message),'OTP/send failure: same error as before');
ok(O.s.data[1][USR.PENDING_EMAIL]===''&&O.s.data[1][USR.PENDING_EMAIL_OTP_HASH]==='','OTP/send failure: pending columns rolled back, nothing half-set');
O=otpEnv({});O.c.beginPendingEmailChange(O.found,'meena@t.test',{displayName:'Admin User',role:'admin'});
ok(!/\(/.test(/for "Meena Rao"[^\n]*/.exec(O.env.mails[0].body)[0].replace('on the Rabale Petty Expense System','')),'OTP: a user with no position is described exactly as before');

// ====================================================== vendor request bill -> Drive
function vendorEnv(o){o=o||{};const env=makeEnv(Object.assign({},o,{session:{valid:true,role:'submission',displayName:'Suresh Patil'},props:{VENDOR_REQUEST_EMAIL:'vendors@t.test'}}));
  env.ctx.getVendorsWithTDS=()=>({});return env}
const file=(name)=>JSON.stringify({data:Buffer.from('%PDF-bill').toString('base64'),mimeType:'application/pdf',name:name||'bill.pdf'});
let V=vendorEnv();let res=V.ctx.requestNewVendor('Arco Transport',file(),'GST registered','tok');
const exp=V.drive.root.folders['Rabale Expense System'],vr=exp&&exp.folders['Vendor Requests'];
const today=V.ctx.Utilities.formatDate(new Date());
const vf=vr&&vr.folders['Arco Transport ('+today+')'];
ok(res.success&&vf&&vf.files.length===1&&vf.files[0].name==='bill.pdf','vendor: bill saved to Rabale Expense System / Vendor Requests / <vendor> (<date>) / <file>');
ok(vf.sharing&&vf.sharing[0]==='DOMAIN_WITH_LINK'&&vf.sharing[1]==='VIEW','vendor: shared to the domain only (view), same as voucher bills');
m=V.mails[0];
ok(V.mails.length===1&&m.attachments.length===1&&m.attachments[0].name==='bill.pdf','vendor: the email still goes out with the bill attached');
ok(m.body.includes('A copy of the bill is also saved in Google Drive: https://drive.google.com/file/d/bill.pdf/view')&&/Saved copy/.test(m.htmlBody)&&/href="https:\/\/drive\.google\.com\/file\/d\/bill\.pdf\/view"/.test(m.htmlBody),'vendor: the Drive link is in both the plain-text and the html email');
ok(V.audit.find(a=>a.a==='VENDOR_REQUEST').n.includes('bill saved to Drive: https://drive.google.com'),'vendor: the audit entry records the Drive link');
ok(res.message==='Request for "Arco Transport" sent.','vendor: success message unchanged when Drive worked');
// second request same day reuses folders
const before=V.drive.log.filter(x=>x.startsWith('createFolder')).length;
V.ctx.requestNewVendor('Arco Transport',file('bill2.pdf'),'','tok');
ok(V.drive.log.filter(x=>x.startsWith('createFolder')).length===before&&vf.files.length===2,'vendor: same vendor/day reuses the folders (no duplicates), file added');
// hostile / awkward names
V=vendorEnv();V.ctx.requestNewVendor('Shree/Gurudev: Transport*? <Co>|',file(),'','tok');
const names=Object.keys(V.drive.root.folders['Rabale Expense System'].folders['Vendor Requests'].folders);
ok(names.length===1&&!/[\\\/:*?"<>|]/.test(names[0].replace(/\(\d{2}-\d{2}-\d{4}\)$/,'')),'vendor: unsafe characters stripped from the Drive folder name: '+names[0]);
V=vendorEnv();V.ctx.requestNewVendor('///',file(),'','tok');ok(Object.keys(V.drive.root.folders['Rabale Expense System'].folders['Vendor Requests'].folders)[0].startsWith('Vendor ('),'vendor: a name that sanitises to nothing falls back to "Vendor"');
V=vendorEnv();V.ctx.requestNewVendor('V'.repeat(100),file(),'','tok');ok(Object.keys(V.drive.root.folders['Rabale Expense System'].folders['Vendor Requests'].folders)[0].length<=93,'vendor: longest allowed name (100 chars) is capped to 80 in the folder name');
V=vendorEnv();res=V.ctx.requestNewVendor('V'.repeat(101),file(),'','tok');ok(!res.success&&/too long/.test(res.error)&&!V.drive.root.folders['Rabale Expense System'],'vendor: over-100-character name still rejected before anything is created in Drive');
// email failure => Drive copy trashed, no orphan
V=vendorEnv({mailFails:true});res=V.ctx.requestNewVendor('Arco Transport',file(),'','tok');
const vf2=V.drive.root.folders['Rabale Expense System'].folders['Vendor Requests'].folders['Arco Transport ('+today+')'];
ok(!res.success&&/Failed to send the vendor request email/.test(res.error)&&vf2.files.length===1&&vf2.files[0].trashed===true,'vendor/send failure: same error as before AND the just-saved Drive copy is trashed (no orphan, retry cannot duplicate)');
ok(!V.audit.some(a=>a.a==='VENDOR_REQUEST'),'vendor/send failure: no "request sent" audit entry');
V=vendorEnv({mailFails:true,drive:{trashFails:true}});res=V.ctx.requestNewVendor('Arco Transport',file(),'','tok');ok(!res.success&&V.logs.some(l=>/could not trash/.test(l)),'vendor/send failure: even if the trash itself fails, the original error is returned and the problem is logged');
// Drive failure => email still goes
V=vendorEnv({drive:{createFails:true}});res=V.ctx.requestNewVendor('Arco Transport',file(),'','tok');
ok(res.success&&V.mails.length===1&&V.mails[0].attachments.length===1,'vendor/Drive failure: the request email is still sent with the bill attached');
ok(!/Google Drive/.test(V.mails[0].body)&&!/Saved copy/.test(V.mails[0].htmlBody),'vendor/Drive failure: the email does not claim a Drive copy exists');
ok(/could not be saved to Drive/.test(res.message)&&V.audit.some(a=>a.a==='VENDOR_REQUEST_DRIVE_SAVE_FAILED'&&/Drive quota exceeded/.test(a.n)),'vendor/Drive failure: submitter is told, and the failure is written to the audit log');
ok(/could NOT be saved to Drive/.test(V.audit.find(a=>a.a==='VENDOR_REQUEST').n),'vendor/Drive failure: the main audit entry says so too');
// sharing failure is non-fatal
V=vendorEnv({drive:{shareFails:true}});res=V.ctx.requestNewVendor('Arco Transport',file(),'','tok');
ok(res.success&&/Google Drive/.test(V.mails[0].body)&&V.logs.some(l=>/could not set domain sharing/.test(l)),'vendor/sharing failure: file still saved and linked, problem logged');
// template failure
V=vendorEnv();V.ctx.vendorRequestHtml_=()=>{throw new Error('boom')};res=V.ctx.requestNewVendor('Arco Transport',file(),'','tok');
ok(res.success&&!('htmlBody' in V.mails[0])&&/Google Drive/.test(V.mails[0].body)&&V.mails[0].attachments.length===1,'vendor/template bug: plain-text email (with the Drive link) + attachment still sent');
// validation unchanged
V=vendorEnv();res=V.ctx.requestNewVendor('Arco Transport','', '', 'tok');ok(!res.success&&/attach/.test(res.error)&&!V.drive.root.folders['Rabale Expense System'],'vendor: no bill => rejected, nothing created in Drive');
// plain text unchanged when there is no Drive link
ok(C.vendorRequestText_({vendorName:'A',requestedBy:'B',dateText:'d',notes:''}).endsWith('via the Admin > Vendor Addition tab.'),'vendor plain text unchanged when no Drive link');
ok(!/href=/.test(C.vendorRequestHtml_({vendorName:'A',requestedBy:'B',dateText:'d',notes:'',driveUrl:'javascript:alert(1)'},'',false)),'vendor html: a non-https Drive link is never rendered');

console.log(`users/drive tests: ${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
