// ============================================================================
// USERS — Day 5. Individual logins for the 4 MULTI_USER_ROLES (submission,
// L1, accounts, L2), admin-managed. Replaces the old shared-PIN-per-role
// model for these 4 roles with named accounts, so 2-3 people sharing a
// dashboard are each individually accountable in the Audit Log, while
// permissions stay exactly role-based (anyone active in 'submission' can
// still act on ANY submission voucher — this is deliberate, so people can
// cover a query for each other when someone's out; it is NOT per-user
// ownership/restriction).
//
// ONE-TIME SETUP after deploying this version:
//   1. Set the ADMIN_PIN Script Property (see Config.gs comment).
//   2. From the Apps Script editor, select bootstrapDefaultUsers from the
//      function dropdown and click Run once. This seeds ONE starter
//      account per multi-user role so you're not locked out:
//        submission / sub.starter / Rabale@2026
//        L1         / l1.starter  / Rabale@2026
//        accounts   / acc.starter / Rabale@2026
//        L2         / l2.starter  / Rabale@2026
//      Log in as one of these, then use Admin > Manage Users to create
//      real named accounts and deactivate the starter ones.
// ============================================================================

// ----------------------------------------------------------------------------
// Password hashing — SHA-256(salt + ':' + password), salted per user.
// Apps Script has no bcrypt/scrypt available natively; salted SHA-256 is a
// real improvement over the previous plaintext-PIN-in-source model and is
// adequate for a small internal team tool, but it is NOT the same strength
// as a proper slow hash. Worth knowing, not worth blocking on for this
// deadline.
// ----------------------------------------------------------------------------
function generateSalt() {
  var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var s = '';
  for (var i = 0; i < 24; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
  return s;
}

function hashPassword(password, salt) {
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + ':' + password);
  return bytes.map(function (b) {
    var v = (b < 0) ? b + 256 : b;
    return ('0' + v.toString(16)).slice(-2);
  }).join('');
}

function verifyPassword(password, salt, expectedHash) {
  return hashPassword(password, salt) === expectedHash;
}

// Minimum bar so admin can't accidentally create a trivially-guessable
// account ("1234", "password") for a system that hands out cash. Not
// enterprise-grade policy, just a sane floor for an internal tool.
function validatePasswordStrength(password) {
  if (!password || String(password).length < 8) {
    return 'Password must be at least 8 characters.';
  }
  if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
    return 'Password must include at least one letter and one number.';
  }
  return null;
}

function validateUsername(username) {
  var u = String(username || '').trim();
  if (!/^[a-zA-Z0-9._]{3,30}$/.test(u)) {
    return { valid: false, error: 'Username must be 3-30 characters: letters, numbers, dot, underscore only.' };
  }
  return { valid: true, username: u };
}

// Email is OPTIONAL (a user with none simply never receives notifyRole
// emails — see below), but if one IS supplied it must look like an email.
// Loose format check only — this isn't a verification system, just a
// typo guard (unlike the vendor PAN field in Master Data, which IS
// strictly format-validated — see validatePAN, Master data.gs — because
// PAN has one fixed, well-known structure and email addresses don't).
function validateOptionalEmail(email) {
  var e = String(email || '').trim();
  if (!e) return { valid: true, email: '' };
  if (e.length > 200 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) {
    return { valid: false, error: 'That doesn\u2019t look like a valid email address.' };
  }
  return { valid: true, email: e };
}

// ----------------------------------------------------------------------------
// Sheet access
// ----------------------------------------------------------------------------
function getOrCreateUsersSheet() {
  var ss = getSpreadsheet();
  var sheet = ss.getSheetByName(USERS_SHEET);
  if (!sheet) {
    sheet = ss.insertSheet(USERS_SHEET);
    sheet.getRange(1, 1, 1, EXPECTED_USER_HEADERS.length).setValues([EXPECTED_USER_HEADERS]);
    sheet.setFrozenRows(1);
    autoFitSheetColumns(sheet, []); // READABILITY (per explicit instruction)
  } else {
    ensureUsersDesignationHeader_(sheet);
  }
  return sheet;
}

// A Users sheet created before the Designation column existed only lacks its
// header cell — every user's cell there is simply blank, meaning "not set".
// Adds the header the first time the sheet is touched. Idempotent, one cell
// read; never blocks the caller.
function ensureUsersDesignationHeader_(sheet) {
  try {
    var cell = sheet.getRange(1, USR.DESIGNATION + 1);
    if (!safe(cell.getValue())) cell.setValue(EXPECTED_USER_HEADERS[USR.DESIGNATION]);
  } catch (err) {
    Logger.log('ensureUsersDesignationHeader_: ' + err);
  }
}

// A position title: trimmed, whitespace collapsed, control characters and
// angle brackets removed, at most DESIGNATION_MAX_LENGTH characters. Blank is
// valid and means "not set" (screens fall back to the app-role wording).
function validateDesignation(raw) {
  var d = String(raw === null || raw === undefined ? '' : raw).replace(/[\u0000-\u001f<>]/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
  if (d.length > DESIGNATION_MAX_LENGTH) return { valid: false, error: 'Position is too long (maximum ' + DESIGNATION_MAX_LENGTH + ' characters).' };
  return { valid: true, designation: d };
}

// Username lookup. Case-insensitive by default (used for uniqueness
// checks at creation — usernames are unique across ALL roles, not just
// within one role, and staying case-insensitive here prevents someone
// creating a confusable near-duplicate like "john" alongside "John").
// Pass exactCase=true for LOGIN specifically (24 Aug 2026, per explicit
// instruction — usernames are now case-sensitive at login): a typed
// username must match the stored one byte-for-byte, not just
// case-folded, so "Rakesh" and "rakesh" are treated as different login
// attempts even though they can never both exist as separate accounts
// (the case-insensitive uniqueness check above already prevents that).
function findUserByUsername(username, exactCase) {
  var sheet = getOrCreateUsersSheet();
  var data = sheet.getDataRange().getValues();
  var needle = String(username || '').trim();
  if (!exactCase) needle = needle.toLowerCase();
  for (var i = 1; i < data.length; i++) {
    var stored = String(data[i][USR.USERNAME]).trim();
    var match = exactCase ? (stored === needle) : (stored.toLowerCase() === needle);
    if (match) {
      return { sheet: sheet, rowIndex: i + 1, rowValues: data[i] };
    }
  }
  return null;
}

function findUserById(userId) {
  var sheet = getOrCreateUsersSheet();
  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][USR.USER_ID]).trim() === String(userId).trim()) {
      return { sheet: sheet, rowIndex: i + 1, rowValues: data[i] };
    }
  }
  return null;
}

// ----------------------------------------------------------------------------
// Admin-facing RPCs
// ----------------------------------------------------------------------------

// Returns every user (all roles) minus password/salt — admin's Manage
// Users panel. Not locked (read-only).
function listUsers(token) {
  try {
    var session = validateSession(token);
    if (!session.valid || session.role !== 'admin') return { success: false, error: 'You do not have permission to do this.' };
    var sheet = getOrCreateUsersSheet();
    var data = sheet.getDataRange().getValues();
    var users = [];
    for (var i = 1; i < data.length; i++) {
      var row = data[i];
      if (!safe(row[USR.USER_ID])) continue;

      // Lazy self-cleanup (item 14): a pending email whose OTP has expired
      // is discarded right here, the same as on any other read/write path
      // that touches it \u2014 so a stale pending row can never surface as
      // "still pending" in the admin panel just because nobody happened to
      // call verify/cancel on it.
      var pendingEmail = safe(row[USR.PENDING_EMAIL]);
      var pendingEmailMinutesLeft = null;
      if (pendingEmail) {
        if (discardExpiredPendingEmail({ sheet: sheet, rowIndex: i + 1, rowValues: row })) {
          pendingEmail = '';
        } else {
          var expiryRaw = row[USR.PENDING_EMAIL_OTP_EXPIRY];
          var expiryDate = (expiryRaw instanceof Date) ? expiryRaw : new Date(expiryRaw);
          pendingEmailMinutesLeft = Math.max(1, Math.ceil((expiryDate.getTime() - Date.now()) / 60000));
        }
      }

      users.push({
        userId: safe(row[USR.USER_ID]),
        displayName: safe(row[USR.DISPLAY_NAME]),
        username: safe(row[USR.USERNAME]),
        role: safe(row[USR.ROLE]),
        active: safe(row[USR.ACTIVE]) === 'Yes',
        createdAt: safe(row[USR.CREATED_AT]),
        lastLogin: safe(row[USR.LAST_LOGIN]),
        email: safe(row[USR.EMAIL]),
        designation: safe(row[USR.DESIGNATION]),
        pendingEmail: pendingEmail,
        pendingEmailMinutesLeft: pendingEmailMinutesLeft
      });
    }
    users.sort(function (a, b) {
      if (a.role !== b.role) return a.role < b.role ? -1 : 1;
      return a.displayName.localeCompare(b.displayName);
    });
    return { success: true, users: users };
  } catch (err) {
    Logger.log('listUsers error: ' + err);
    return { success: false, error: 'Failed to load users: ' + err.toString() };
  }
}

function createUser(displayName, role, username, password, email, designation, token) {
  var lock = LockService.getScriptLock();
  try {
    var session = validateSession(token);
    if (!session.valid || session.role !== 'admin') return { success: false, error: 'You do not have permission to do this.' };

    displayName = String(displayName || '').trim();
    if (!displayName) return { success: false, error: 'Display name is required.' };
    if (MULTI_USER_ROLES.indexOf(role) === -1) return { success: false, error: 'Invalid role.' };

    var uv = validateUsername(username);
    if (!uv.valid) return { success: false, error: uv.error };

    var pwError = validatePasswordStrength(password);
    if (pwError) return { success: false, error: pwError };

    var ev = validateOptionalEmail(email);
    if (!ev.valid) return { success: false, error: ev.error };

    var dv = validateDesignation(designation);
    if (!dv.valid) return { success: false, error: dv.error };

    try { lock.waitLock(15000); } catch (lockErr) {
      return { success: false, error: 'System is busy. Please try again in a few seconds.' };
    }

    if (findUserByUsername(uv.username)) {
      return { success: false, error: 'Username "' + uv.username + '" is already taken.' };
    }

    var sheet = getOrCreateUsersSheet();
    var userId = 'U-' + Utilities.getUuid().slice(0, 8);
    var salt = generateSalt();
    var hash = hashPassword(password, salt);
    var newRow = new Array(EXPECTED_USER_HEADERS.length).fill('');
    newRow[USR.USER_ID]       = userId;
    newRow[USR.DISPLAY_NAME]  = displayName;
    newRow[USR.USERNAME]      = uv.username;
    newRow[USR.ROLE]          = role;
    newRow[USR.PASSWORD_HASH] = hash;
    newRow[USR.SALT]          = salt;
    newRow[USR.ACTIVE]        = 'Yes';
    newRow[USR.CREATED_AT]    = new Date().toLocaleString('en-IN');
    newRow[USR.LAST_LOGIN]    = '';
    newRow[USR.DESIGNATION]   = dv.designation;
    // CHANGED (item 14): email is NEVER written directly to USR.EMAIL here
    // anymore \u2014 it's the hard OTP gate applying to account creation too,
    // same as an edit. newRow[USR.EMAIL] stays blank; if an email was
    // supplied it goes to Pending Email + an OTP is sent to IT (not
    // written anywhere final) immediately below, once the row exists.
    sheet.appendRow(newRow);

    var pendingNote = '';
    if (ev.email) {
      try {
        beginPendingEmailChange({ sheet: sheet, rowIndex: sheet.getLastRow(), rowValues: newRow }, ev.email, session);
        pendingNote = ' A verification code was sent to ' + ev.email + ' \u2014 enter it via Set Email to activate.';
      } catch (otpErr) {
        pendingNote = ' Note: the verification email failed to send (' + otpErr.message + ') \u2014 use Set Email to retry.';
      }
    }

    logAction('USER_CREATE', '', session.displayName, session.role, 'Created user "' + displayName + '" (' + uv.username + ', role: ' + role + (dv.designation ? ', position: ' + dv.designation : '') + ')' + (ev.email ? ', pending email: ' + ev.email : ''));
    return { success: true, userId: userId, message: 'User "' + displayName + '" created.' + pendingNote };
  } catch (err) {
    Logger.log('createUser error: ' + err);
    return { success: false, error: 'Failed to create user: ' + err.toString() };
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

// ----------------------------------------------------------------------------
// EMAIL OTP VERIFICATION (item 14, 25 Aug 2026) — shared helpers used by
// createUser (above), setUserEmail, verifyUserEmailOtp, cancelPendingEmailChange,
// and listUsers' lazy self-cleanup.
// ----------------------------------------------------------------------------
function generateOtp() {
  var digits = '0123456789';
  var otp = '';
  for (var i = 0; i < OTP_LENGTH; i++) otp += digits.charAt(Math.floor(Math.random() * digits.length));
  return otp;
}

function clearPendingEmailColumns(found) {
  found.sheet.getRange(found.rowIndex, USR.PENDING_EMAIL + 1).setValue('');
  found.sheet.getRange(found.rowIndex, USR.PENDING_EMAIL_OTP_HASH + 1).setValue('');
  found.sheet.getRange(found.rowIndex, USR.PENDING_EMAIL_OTP_SALT + 1).setValue('');
  found.sheet.getRange(found.rowIndex, USR.PENDING_EMAIL_OTP_EXPIRY + 1).setValue('');
}

// Discards a pending email change if its OTP has expired, run lazily on
// every read/write path that touches pending-email state (setUserEmail,
// verifyUserEmailOtp, listUsers) instead of a time-based trigger \u2014 per
// the confirmed design (expires, discarded, admin redoes it), and there is
// no other reason for this codebase to poll every user row on a timer.
// Returns true if it discarded something.
function discardExpiredPendingEmail(found) {
  var pending = safe(found.rowValues[USR.PENDING_EMAIL]);
  var expiryRaw = found.rowValues[USR.PENDING_EMAIL_OTP_EXPIRY];
  if (!pending || !expiryRaw) return false;
  var expiryDate = (expiryRaw instanceof Date) ? expiryRaw : new Date(expiryRaw);
  if (isNaN(expiryDate.getTime()) || expiryDate.getTime() > Date.now()) return false;
  clearPendingEmailColumns(found);
  logAction('USER_EMAIL_OTP_EXPIRED', '', 'system', 'system', 'Pending email verification expired for "' + safe(found.rowValues[USR.DISPLAY_NAME]) + '"');
  return true;
}

// Generates and sends the OTP, writing Pending Email + salted-hashed OTP +
// expiry (same hashPassword/generateSalt convention as PASSWORD_HASH/SALT
// \u2014 never stored in plaintext). Throws (caller decides how to handle) if
// the send itself fails, and rolls its own pending write back on that path
// so nothing is left half-set for verifyUserEmailOtp to find.
function beginPendingEmailChange(found, newEmail, session) {
  var otp = generateOtp();
  var salt = generateSalt();
  var hash = hashPassword(otp, salt);
  var expiry = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60000);
  found.sheet.getRange(found.rowIndex, USR.PENDING_EMAIL + 1).setValue(newEmail);
  found.sheet.getRange(found.rowIndex, USR.PENDING_EMAIL_OTP_HASH + 1).setValue(hash);
  found.sheet.getRange(found.rowIndex, USR.PENDING_EMAIL_OTP_SALT + 1).setValue(salt);
  found.sheet.getRange(found.rowIndex, USR.PENDING_EMAIL_OTP_EXPIRY + 1).setValue(expiry);

  var displayName = safe(found.rowValues[USR.DISPLAY_NAME]);
  var otpMail = { displayName: displayName, designation: safe(found.rowValues[USR.DESIGNATION]), otp: otp, expiryMinutes: OTP_EXPIRY_MINUTES };
  try {
    // Plain text is built here (Notifications.gs); the branded HTML is built
    // inside sendNotification_ and falls back to this plain text if it fails.
    sendNotification_({
      to: newEmail,
      subject: 'Rabale Petty Expense System \u2014 verify this email address',
      body: otpVerificationText_(otpMail)
    }, function (hasLogo) { return otpVerificationHtml_(otpMail, hasLogo); });
  } catch (mailErr) {
    Logger.log('beginPendingEmailChange: failed to send OTP to ' + newEmail + ': ' + mailErr);
    clearPendingEmailColumns(found);
    throw new Error('could not send to ' + newEmail + ' (' + mailErr + ')');
  }
  logAction('USER_EMAIL_OTP_SENT', '', session.displayName, session.role, 'OTP sent to ' + newEmail + ' for "' + displayName + '"');
}

// Admin sets/updates a user's email address \u2014 separate RPC rather than
// folded into createUser's edit path, since there is no general "edit
// user" RPC today (display name/role/username are immutable after
// creation by design, same as everywhere else in this file); email is
// the one field that plausibly needs correcting after the fact.
//
// CHANGED (item 14): this no longer writes USR.EMAIL directly for a
// non-blank address \u2014 it starts (or restarts) the pending-email OTP flow
// instead; verifyUserEmailOtp is what actually finalizes it. Clearing an
// email (blank) still applies immediately \u2014 removing an address needs no
// reachability confirmation, only adding/changing to a new one does.
function setUserEmail(userId, email, token) {
  var lock = LockService.getScriptLock();
  try {
    var session = validateSession(token);
    if (!session.valid || session.role !== 'admin') return { success: false, error: 'You do not have permission to do this.' };

    var ev = validateOptionalEmail(email);
    if (!ev.valid) return { success: false, error: ev.error };

    try { lock.waitLock(15000); } catch (lockErr) {
      return { success: false, error: 'System is busy. Please try again in a few seconds.' };
    }

    var found = findUserById(userId);
    if (!found) return { success: false, error: 'User not found.' };

    if (!ev.email) {
      found.sheet.getRange(found.rowIndex, USR.EMAIL + 1).setValue('');
      clearPendingEmailColumns(found);
      clearFailedAttempts('otpatt_' + userId);
      var clearedName = safe(found.rowValues[USR.DISPLAY_NAME]);
      logAction('USER_EMAIL_SET', '', session.displayName, session.role, 'Email for "' + clearedName + '" cleared');
      return { success: true, message: 'Email cleared.' };
    }

    if (ev.email === safe(found.rowValues[USR.EMAIL])) {
      return { success: false, error: 'That is already this user\u2019s verified email.' };
    }

    var resendKey = 'otpresend_' + userId;
    if (isLocked(resendKey)) {
      return { success: false, error: 'Please wait a few seconds before requesting another code.' };
    }
    CacheService.getScriptCache().put('lock_' + resendKey, '1', OTP_RESEND_COOLDOWN_SECONDS);
    clearFailedAttempts('otpatt_' + userId); // a fresh code gets a fresh attempt budget

    try {
      beginPendingEmailChange(found, ev.email, session);
    } catch (otpErr) {
      return { success: false, error: 'Failed to send verification code: ' + otpErr.message };
    }
    return { success: true, pending: true, message: 'Verification code sent to ' + ev.email + '. Enter it to confirm.' };
  } catch (err) {
    Logger.log('setUserEmail error: ' + err);
    return { success: false, error: 'Failed to update email: ' + err.toString() };
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

// Confirms a pending email change \u2014 the only path that ever writes
// USR.EMAIL for a non-blank address. Attempt-limiting reuses Auth.gs's
// registerFailedAttempt/isLocked/clearFailedAttempts AS-IS, under an
// 'otpatt_' key distinct from real login lockout keys, per explicit
// instruction to reuse rather than duplicate that mechanism.
function verifyUserEmailOtp(userId, otpCode, token) {
  var lock = LockService.getScriptLock();
  try {
    var session = validateSession(token);
    if (!session.valid || session.role !== 'admin') return { success: false, error: 'You do not have permission to do this.' };

    try { lock.waitLock(15000); } catch (lockErr) {
      return { success: false, error: 'System is busy. Please try again in a few seconds.' };
    }

    var found = findUserById(userId);
    if (!found) return { success: false, error: 'User not found.' };

    if (discardExpiredPendingEmail(found)) {
      return { success: false, error: 'That code has expired. Use Set Email to request a new one.' };
    }

    var pendingEmail = safe(found.rowValues[USR.PENDING_EMAIL]);
    if (!pendingEmail) return { success: false, error: 'There is no pending email change for this user.' };

    var attKey = 'otpatt_' + userId;
    if (isLocked(attKey)) {
      clearPendingEmailColumns(found);
      logAction('USER_EMAIL_OTP_LOCKED', '', session.displayName, session.role, 'Too many incorrect codes for "' + safe(found.rowValues[USR.DISPLAY_NAME]) + '" \u2014 pending change discarded');
      return { success: false, error: 'Too many incorrect codes. The pending change was discarded \u2014 use Set Email to start over.' };
    }

    var storedHash = safe(found.rowValues[USR.PENDING_EMAIL_OTP_HASH]);
    var storedSalt = safe(found.rowValues[USR.PENDING_EMAIL_OTP_SALT]);
    var typed = String(otpCode || '').trim();
    if (!typed || !verifyPassword(typed, storedSalt, storedHash)) {
      var attResult = registerFailedAttempt(attKey);
      if (attResult.locked) {
        clearPendingEmailColumns(found);
        logAction('USER_EMAIL_OTP_LOCKED', '', session.displayName, session.role, 'Too many incorrect codes for "' + safe(found.rowValues[USR.DISPLAY_NAME]) + '" \u2014 pending change discarded');
        return { success: false, error: 'Too many incorrect codes. The pending change was discarded \u2014 use Set Email to start over.' };
      }
      return { success: false, error: 'Incorrect code. ' + attResult.attemptsLeft + ' attempt(s) remaining.' };
    }

    clearFailedAttempts(attKey);
    found.sheet.getRange(found.rowIndex, USR.EMAIL + 1).setValue(pendingEmail);
    clearPendingEmailColumns(found);
    var displayName = safe(found.rowValues[USR.DISPLAY_NAME]);
    logAction('USER_EMAIL_VERIFIED', '', session.displayName, session.role, 'Email for "' + displayName + '" verified and set to ' + pendingEmail);
    return { success: true, message: 'Email verified and set to ' + pendingEmail + '.' };
  } catch (err) {
    Logger.log('verifyUserEmailOtp error: ' + err);
    return { success: false, error: 'Failed to verify code: ' + err.toString() };
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

// Lets admin abandon a pending change without waiting for it to expire
// (e.g. typo'd the new address) \u2014 no OTP required to cancel, only to
// confirm.
function cancelPendingEmailChange(userId, token) {
  try {
    var session = validateSession(token);
    if (!session.valid || session.role !== 'admin') return { success: false, error: 'You do not have permission to do this.' };

    var found = findUserById(userId);
    if (!found) return { success: false, error: 'User not found.' };
    if (!safe(found.rowValues[USR.PENDING_EMAIL])) return { success: false, error: 'No pending email change to cancel.' };

    clearPendingEmailColumns(found);
    clearFailedAttempts('otpatt_' + userId);
    logAction('USER_EMAIL_OTP_CANCELLED', '', session.displayName, session.role, 'Pending email change cancelled for "' + safe(found.rowValues[USR.DISPLAY_NAME]) + '"');
    return { success: true, message: 'Pending email change cancelled.' };
  } catch (err) {
    Logger.log('cancelPendingEmailChange error: ' + err);
    return { success: false, error: 'Failed to cancel: ' + err.toString() };
  }
}

// ----------------------------------------------------------------------------
// Role-level email notification (bugfix round) — the actual replacement
// for the removed notification bell. Roles here are shared logins ("anyone
// active in L1 can act on any voucher" — see this file's header comment),
// so there is no single correct recipient for "notify L1"; every active
// user in that role with an email on file gets emailed. A role with nobody
// configured is a silent no-op (Logger.log only), same graceful-degradation
// convention as VENDOR_REQUEST_EMAIL/QUERY_REMINDER_EMAIL — a missing
// config value should never throw up through a caller that's usually
// mid-transaction (e.g. raiseVoucherQuery).
// ----------------------------------------------------------------------------
function getActiveUserEmailsForRole(role) {
  var sheet = getOrCreateUsersSheet();
  var data = sheet.getDataRange().getValues();
  var emails = [];
  for (var i = 1; i < data.length; i++) {
    var row = data[i];
    if (safe(row[USR.ROLE]) !== role) continue;
    if (safe(row[USR.ACTIVE]) !== 'Yes') continue;
    var email = safe(row[USR.EMAIL]);
    if (email && emails.indexOf(email) === -1) emails.push(email);
  }
  return emails;
}

// Sends one email per recipient (not one email with everyone in "to") so
// nobody sees a colleague's address, and so a bad address on one account
// (MailApp throws per-send) doesn't stop the others from going out.
// Returns the count actually sent — callers use this only for logging,
// never to decide whether to fail the caller's own operation.
function notifyRole(role, subject, body) {
  var emails = getActiveUserEmailsForRole(role);
  if (emails.length === 0) {
    Logger.log('notifyRole: no active user with an email configured for role "' + role + '" \u2014 skipped: ' + subject);
    return 0;
  }
  var sent = 0;
  emails.forEach(function (email) {
    try {
      MailApp.sendEmail({ to: email, subject: subject, body: body });
      sent++;
    } catch (mailErr) {
      Logger.log('notifyRole: failed to email ' + email + ': ' + mailErr);
    }
  });
  return sent;
}

// ----------------------------------------------------------------------------
// SINGLE-USER ACCOUNT-EVENT NOTIFICATION (item 15, 25 Aug 2026) — the
// one-specific-person counterpart to notifyRole() above, for password
// reset / deactivation / lockout / lockout-cleared. notifyRole broadcasts
// to every active user in a role, which is wrong for these four events:
// each one is about exactly the one account it happened to, so this takes
// a user row (from findUserById/findUserByUsername) directly rather than
// a role.
//
// Auditor exclusion: CONFIRMED (not assumed) that Auditor is a normal
// MULTI_USER_ROLES member that can have USR.EMAIL populated exactly like
// every other role (createUser/setUserEmail don't special-case it) — so
// "no email on file" does NOT already cover the exclusion for free, and
// this checks role === 'auditor' explicitly rather than relying on that.
//
// Same graceful-degradation posture as every other MailApp call site in
// this codebase: a missing email is a skip, a send failure is caught and
// logged, and NEITHER ever throws back to the caller — none of these four
// operations (password reset, deactivation, lockout, unlock) may fail or
// be blocked because a notification email didn't go out.
function notifyUserOfAccountEvent(userRow, eventLogAction, subject, body) {
  try {
    if (!userRow) return;
    var role = safe(userRow[USR.ROLE]);
    if (role === 'auditor') {
      Logger.log('notifyUserOfAccountEvent: skipped (' + eventLogAction + ') \u2014 Auditor accounts never receive these emails.');
      return;
    }
    var email = safe(userRow[USR.EMAIL]);
    var displayName = safe(userRow[USR.DISPLAY_NAME]);
    if (!email) {
      Logger.log('notifyUserOfAccountEvent: skipped (' + eventLogAction + ') for "' + displayName + '" \u2014 no email on file.');
      logAction(eventLogAction + '_EMAIL_SKIPPED', '', 'system', 'system', 'No email on file for "' + displayName + '".');
      return;
    }
    try {
      // HTML version built from the same plain-text `body` (Notifications.gs,
      // buildAccountEventEmail_); if that ever fails the plain text still goes.
      sendNotification_({ to: email, subject: subject, body: body }, function (hasLogo) {
        return buildAccountEventEmail_(eventLogAction, displayName, subject, body, new Date().toLocaleString('en-IN'), getAppUrl(), hasLogo);
      });
      logAction(eventLogAction + '_EMAIL_SENT', '', 'system', 'system', 'Notified "' + displayName + '" at ' + email + '.');
    } catch (mailErr) {
      Logger.log('notifyUserOfAccountEvent: failed to email ' + email + ': ' + mailErr);
      logAction(eventLogAction + '_EMAIL_FAILED', '', 'system', 'system', 'Failed to email "' + displayName + '" at ' + email + ': ' + mailErr);
    }
  } catch (err) {
    // Belt-and-braces: this whole function is fire-and-forget from every
    // caller's perspective, so even an unexpected error here (e.g. a
    // malformed userRow) must never propagate up into a password
    // reset/deactivation/lockout and block it.
    Logger.log('notifyUserOfAccountEvent unexpected error: ' + err);
  }
}

// Admin sets or clears a user's position in the company. Position is display
// text only — it has no effect on what the user can do (that is ROLE) — so
// it can be corrected at any time. Blank clears it.
function setUserDesignation(userId, designation, token) {
  var lock = LockService.getScriptLock();
  try {
    var session = validateSession(token);
    if (!session.valid || session.role !== 'admin') return { success: false, error: 'You do not have permission to do this.' };
    var dv = validateDesignation(designation);
    if (!dv.valid) return { success: false, error: dv.error };
    try { lock.waitLock(15000); } catch (lockErr) {
      return { success: false, error: 'System is busy. Please try again in a few seconds.' };
    }
    var found = findUserById(userId);
    if (!found) return { success: false, error: 'User not found.' };
    var displayName = safe(found.rowValues[USR.DISPLAY_NAME]);
    var previous = safe(found.rowValues[USR.DESIGNATION]);
    found.sheet.getRange(found.rowIndex, USR.DESIGNATION + 1).setValue(dv.designation);
    logAction('USER_DESIGNATION_SET', '', session.displayName, session.role,
      'Position for "' + displayName + '": ' + (previous ? '"' + previous + '"' : '(not set)') + ' \u2192 ' + (dv.designation ? '"' + dv.designation + '"' : '(cleared)'));
    return { success: true, designation: dv.designation, message: dv.designation ? 'Position for "' + displayName + '" set to "' + dv.designation + '".' : 'Position for "' + displayName + '" cleared.' };
  } catch (err) {
    Logger.log('setUserDesignation error: ' + err);
    return { success: false, error: 'Failed to update position: ' + err.toString() };
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

function setUserActive(userId, active, token) {
  var lock = LockService.getScriptLock();
  try {
    var session = validateSession(token);
    if (!session.valid || session.role !== 'admin') return { success: false, error: 'You do not have permission to do this.' };

    try { lock.waitLock(15000); } catch (lockErr) {
      return { success: false, error: 'System is busy. Please try again in a few seconds.' };
    }

    var found = findUserById(userId);
    if (!found) return { success: false, error: 'User not found.' };

    found.sheet.getRange(found.rowIndex, USR.ACTIVE + 1).setValue(active ? 'Yes' : 'No');
    var displayName = safe(found.rowValues[USR.DISPLAY_NAME]);
    logAction(active ? 'USER_ACTIVATE' : 'USER_DEACTIVATE', '', session.displayName, session.role, 'User "' + displayName + '"');
    // ADDED (item 15): notify on deactivation only, per spec — activation
    // (re-enabling) isn't an event the user needs alerted about.
    if (!active) {
      notifyUserOfAccountEvent(found.rowValues, 'USER_DEACTIVATE',
        'Rabale Petty Expense System \u2014 your account has been deactivated',
        'Hello ' + displayName + ',\n\nYour account on the Rabale Petty Expense System has been deactivated by an administrator. ' +
        'You will not be able to log in until it is reactivated.\n\nIf you believe this is a mistake, please contact your administrator.');
    }
    return { success: true };
  } catch (err) {
    Logger.log('setUserActive error: ' + err);
    return { success: false, error: 'Failed to update user: ' + err.toString() };
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

// Admin sets someone's password directly (lost/forgotten password path).
function resetUserPassword(userId, newPassword, token) {
  var lock = LockService.getScriptLock();
  try {
    var session = validateSession(token);
    if (!session.valid || session.role !== 'admin') return { success: false, error: 'You do not have permission to do this.' };

    var pwError = validatePasswordStrength(newPassword);
    if (pwError) return { success: false, error: pwError };

    try { lock.waitLock(15000); } catch (lockErr) {
      return { success: false, error: 'System is busy. Please try again in a few seconds.' };
    }

    var found = findUserById(userId);
    if (!found) return { success: false, error: 'User not found.' };

    var salt = generateSalt();
    var hash = hashPassword(newPassword, salt);
    found.sheet.getRange(found.rowIndex, USR.PASSWORD_HASH + 1).setValue(hash);
    found.sheet.getRange(found.rowIndex, USR.SALT + 1).setValue(salt);

    var displayName = safe(found.rowValues[USR.DISPLAY_NAME]);
    logAction('USER_PASSWORD_RESET', '', session.displayName, session.role, 'Password reset for "' + displayName + '" by admin');
    notifyUserOfAccountEvent(found.rowValues, 'USER_PASSWORD_RESET',
      'Rabale Petty Expense System \u2014 your password was reset',
      'Hello ' + displayName + ',\n\nYour password on the Rabale Petty Expense System was just reset by an administrator. ' +
      'If you did not expect this, please contact your administrator immediately.');
    return { success: true };
  } catch (err) {
    Logger.log('resetUserPassword error: ' + err);
    return { success: false, error: 'Failed to reset password: ' + err.toString() };
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

// Self-service — any logged-in multi-user-role person changes their own
// password from inside their own dashboard. Requires the current password,
// same as any normal "change password" flow.
function changeOwnPassword(oldPassword, newPassword, token) {
  var lock = LockService.getScriptLock();
  try {
    var session = validateSession(token);
    if (!session.valid || !session.userId || MULTI_USER_ROLES.indexOf(session.role) === -1) {
      return { success: false, error: 'This account type does not use a password change here.' };
    }

    var pwError = validatePasswordStrength(newPassword);
    if (pwError) return { success: false, error: pwError };

    try { lock.waitLock(15000); } catch (lockErr) {
      return { success: false, error: 'System is busy. Please try again in a few seconds.' };
    }

    var found = findUserById(session.userId);
    if (!found) return { success: false, error: 'Account not found. Please log in again.' };

    var storedHash = safe(found.rowValues[USR.PASSWORD_HASH]);
    var storedSalt = safe(found.rowValues[USR.SALT]);
    if (!verifyPassword(oldPassword, storedSalt, storedHash)) {
      return { success: false, error: 'Current password is incorrect.' };
    }

    var newSalt = generateSalt();
    var newHash = hashPassword(newPassword, newSalt);
    found.sheet.getRange(found.rowIndex, USR.PASSWORD_HASH + 1).setValue(newHash);
    found.sheet.getRange(found.rowIndex, USR.SALT + 1).setValue(newSalt);

    logAction('USER_PASSWORD_CHANGE', '', session.displayName, session.role, 'Self-service password change');
    notifyUserOfAccountEvent(found.rowValues, 'USER_PASSWORD_CHANGE',
      'Rabale Petty Expense System \u2014 your password was changed',
      'Hello ' + safe(found.rowValues[USR.DISPLAY_NAME]) + ',\n\nYour password on the Rabale Petty Expense System was just changed. ' +
      'If you did not make this change, please contact your administrator immediately.');
    return { success: true };
  } catch (err) {
    Logger.log('changeOwnPassword error: ' + err);
    return { success: false, error: 'Failed to change password: ' + err.toString() };
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
}

// ----------------------------------------------------------------------------
// One-time manual setup — run ONCE from the Apps Script editor (select this
// function in the dropdown, click Run). Safe to re-run: skips any username
// that already exists rather than creating duplicates. Starter passwords
// are intentionally simple/known so you can log in immediately and create
// real accounts — deactivate these once real accounts exist.
// ----------------------------------------------------------------------------
function bootstrapDefaultUsers() {
  var starters = [
    { displayName: 'Submission Starter', role: 'submission', username: 'sub.starter' },
    { displayName: 'L1 Starter',         role: 'L1',         username: 'l1.starter' },
    { displayName: 'Accounts Starter',   role: 'accounts',   username: 'acc.starter' },
    { displayName: 'L2 Starter',         role: 'L2',         username: 'l2.starter' }
  ];
  var starterPassword = 'Rabale@2026';
  var sheet = getOrCreateUsersSheet();
  var created = [];
  starters.forEach(function (s) {
    if (findUserByUsername(s.username)) { return; }
    var userId = 'U-' + Utilities.getUuid().slice(0, 8);
    var salt = generateSalt();
    var hash = hashPassword(starterPassword, salt);
    var newRow = new Array(EXPECTED_USER_HEADERS.length).fill('');
    newRow[USR.USER_ID]       = userId;
    newRow[USR.DISPLAY_NAME]  = s.displayName;
    newRow[USR.USERNAME]      = s.username;
    newRow[USR.ROLE]          = s.role;
    newRow[USR.PASSWORD_HASH] = hash;
    newRow[USR.SALT]          = salt;
    newRow[USR.ACTIVE]        = 'Yes';
    newRow[USR.CREATED_AT]    = new Date().toLocaleString('en-IN');
    newRow[USR.LAST_LOGIN]    = '';
    sheet.appendRow(newRow);
    created.push(s.username);
  });
  Logger.log('bootstrapDefaultUsers: created ' + created.length + ' starter account(s): ' + created.join(', ') + '. Starter password for all: ' + starterPassword);
  return created;
}